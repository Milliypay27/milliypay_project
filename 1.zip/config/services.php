<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'unired-mts' => [
        'base_url' => env('UNIRED_MTS_BASE_URL'),
        'login' => env('UNIRED_MTS_LOGIN'),
        'password' => env('UNIRED_MTS_PASSWORD')
    ],

    'sms_ru' => [
        'url' => env('SMS_RU_CALL_API_URL'),
        'api_id' => env('SMS_RU_CALL_API_ID')
    ],

    'ofd' => [
        'test' => [
            'url' => 'https://test.ofd.uz/emp/receipt',
            'crt' => storage_path('ofd/EZ000000000240.crt'),
            'key' => storage_path('ofd/milliypay.key'),
            'spic' => '11199008007000000',
            'units' => 25,
            'VATPercent' => 0
        ],

        'prod' => [
            'url' => 'https://emp.soliq.uz/emp/receipt',
            'crt' => storage_path('ofd/prod/EP000000000201.crt'),
            'key' => storage_path('ofd/prod/milliypay-prod.key'),
            'spic' => '11199008007000000',
            'units' => 25,
            'VATPercent' => 0
        ]
    ]
];
