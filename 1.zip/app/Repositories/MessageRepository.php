<?php

namespace App\Repositories;

use App\Models\User;
use App\Models\Message;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class MessageRepository
{


    public function findByUserIdForWeb($user_id): LengthAwarePaginator
    {
        return $this->query()->where('user_id', '=', $user_id)->join('users', 'user_id', '=', 'users.id')
            ->select('messages.*', 'users.full_name', 'users.avatar', 'messages.created_at')
            ->latest()
            ->paginate(10);
    }

    public function prepareChatRooms()
    {
        return User::query()
            ->select('users.id as user_id', 'users.activity_at as user_activity_at', 'users.phone', 'messages.created_at as last_activity_date', 'messages.text as last_message_text', 'messages.is_file as is_file', 'users.avatar')
            ->addSelect(['unread_count' => Message::query()
                ->selectRaw('count(messages.id)')
                ->whereColumn('user_id', 'users.id')
                ->where('is_admin_message', false)
                ->where('status', Message::STATUS_UNREAD)])
            ->join('messages', function ($query) {
                $query->on('users.id', '=', 'messages.user_id')
                    ->whereRaw('messages.id IN (select MAX(m2.id) from messages as m2 join users as u2 on u2.id = m2.user_id group by u2.id)');
            })->orderByDesc('last_activity_date')
            ->get();
    }

    public function setReadMessages($user_id, bool $is_admin_message): int
    {
        return $this->query()
            ->where('user_id', $user_id)
            ->where('status', Message::STATUS_UNREAD)
            ->where('is_admin_message', $is_admin_message)
            ->update(['status' => Message::STATUS_READ]);
    }

    public function unreadCountForApi($user_id): int
    {
        return Message::query()->where('user_id', $user_id)->where('is_admin_message', true)->where('status', Message::STATUS_UNREAD)->count();
    }
}
