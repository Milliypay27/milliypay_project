<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\HttpLog
 *
 * @property int $id
 * @property \Illuminate\Support\Carbon|null $start
 * @property \Illuminate\Support\Carbon|null $end
 * @property int|null $duration
 * @property string|null $url
 * @property string|null $method
 * @property string|null $ip
 * @property string|null $status
 * @property string|null $body
 * @property string|null $response
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog newQuery()
 * @method static \Illuminate\Database\Query\Builder|HttpLog onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog query()
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereBody($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereDuration($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereEnd($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereIp($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereMethod($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereResponse($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereStart($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereUrl($value)
 * @method static \Illuminate\Database\Query\Builder|HttpLog withTrashed()
 * @method static \Illuminate\Database\Query\Builder|HttpLog withoutTrashed()
 * @mixin \Eloquent
 * @property string|null $head
 * @method static \Illuminate\Database\Eloquent\Builder|HttpLog whereHead($value)
 */
class HttpLog extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'start', 'end', 'duration',
        'url', 'method', 'ip', 'status',
        'body', 'response'
    ];

    protected $dates = ['start', 'end'];
}
