<?php

namespace App\Models;

use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

/**
 * App\Models\Message
 *
 * @property int $id
 * @property int $user_id
 * @property int $by_admin
 * @property string $text
 * @property int $read
 * @property int $is_file
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read User $user
 * @method static Builder|Message newModelQuery()
 * @method static Builder|Message newQuery()
 * @method static Builder|Message query()
 * @method static Builder|Message whereByAdmin($value)
 * @method static Builder|Message whereCreatedAt($value)
 * @method static Builder|Message whereId($value)
 * @method static Builder|Message whereIsFile($value)
 * @method static Builder|Message whereRead($value)
 * @method static Builder|Message whereText($value)
 * @method static Builder|Message whereUpdatedAt($value)
 * @method static Builder|Message whereUserId($value)
 * @mixin Eloquent
 * @property-read string $send_date_time
 */
class Message extends Model
{
    use HasFactory;

    const STATUS_READ = 1;
    const STATUS_UNREAD = 0;

    protected $fillable = [
        'user_id',
        'by_admin',
        'text',
        'read',
        'is_file'
    ];

    protected $appends = ['send_date_time'];
    protected $dates = ['created_at', 'updated_at'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getSendDateTimeAttribute(): string
    {
        return $this->updated_at ? $this->updated_at->format('d.m.y H:s') : '';
    }
}
