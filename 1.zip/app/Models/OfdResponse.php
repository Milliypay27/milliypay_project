<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\OfdResponse
 *
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse query()
 * @mixin \Eloquent
 * @property int $id
 * @property int $user_id
 * @property int $transfer_id
 * @property int|null $code
 * @property string|null $message
 * @property string|null $terminal_id
 * @property string|null $receipt_id
 * @property string|null $fiscal_sign
 * @property string|null $qr_code_url
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereFiscalSign($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereMessage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereQrCodeUrl($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereReceiptId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereTerminalId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereTransferId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereUserId($value)
 * @property string|null $datetime
 * @method static \Illuminate\Database\Eloquent\Builder|OfdResponse whereDatetime($value)
 */
class OfdResponse extends Model
{
    use HasFactory;
}
