<?php

namespace App\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Database\Factories\UserFactory;
use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Notifications\DatabaseNotificationCollection;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Carbon;
use Laravel\Passport\Client;
use Laravel\Passport\HasApiTokens;
use Laravel\Sanctum\PersonalAccessToken;
use Modules\Profile\Models\Profile;
use Modules\Unired\Constants\CreditCardState;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Models\CreditCard;
use Modules\Unired\Models\Transfer;

/**
 * App\Models\User
 *
 * @property int $id
 * @property string $name
 * @property string $email
 * @property Carbon|null $email_verified_at
 * @property string $password
 * @property string|null $remember_token
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read DatabaseNotificationCollection|DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @property-read Collection|PersonalAccessToken[] $tokens
 * @property-read int|null $tokens_count
 * @method static UserFactory factory(...$parameters)
 * @method static Builder|User newModelQuery()
 * @method static Builder|User newQuery()
 * @method static Builder|User query()
 * @method static Builder|User whereCreatedAt($value)
 * @method static Builder|User whereEmail($value)
 * @method static Builder|User whereEmailVerifiedAt($value)
 * @method static Builder|User whereId($value)
 * @method static Builder|User whereName($value)
 * @method static Builder|User wherePassword($value)
 * @method static Builder|User whereRememberToken($value)
 * @method static Builder|User whereUpdatedAt($value)
 * @mixin Eloquent
 * @property string $phone
 * @property string|null $phone_verified_at
 * @method static Builder|User wherePhone($value)
 * @method static Builder|User wherePhoneVerifiedAt($value)
 * @property string|null $two_factor_secret
 * @property string|null $two_factor_recovery_codes
 * @property-read Collection|Client[] $clients
 * @property-read int|null $clients_count
 * @method static Builder|User whereTwoFactorRecoveryCodes($value)
 * @method static Builder|User whereTwoFactorSecret($value)
 * @property-read Collection|CreditCard[] $creditCards
 * @property-read int|null $credit_cards_count
 * @property-read Collection|Transfer[] $transferCreditCards
 * @property-read int|null $transfer_credit_cards_count
 * @property-read Collection|Transfer[] $transfers
 * @property-read int|null $transfers_count
 * @property-read Profile|null $profile
 * @property-read Collection|\App\Models\UserDevice[] $devices
 * @property-read int|null $devices_count
 * @property Carbon|string $activity_at
 * @method static Builder|User whereActivityAt($value)
 */
class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, CrudTrait;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'phone',
        'password',
        'activity_at'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'phone_verified_at' => 'datetime',
    ];

    protected $dates = ['activity_at'];

    public function findForPassport($username)
    {
        return $this->where('phone', $username)->first();
    }

    public function creditCards(): HasMany
    {
        return $this->hasMany(CreditCard::class, 'user_id', 'id')
            ->where('state', CreditCardState::SUCCESS);
    }

    public function transfers(): HasMany
    {
        return $this->hasMany(Transfer::class, 'user_id', 'id')
            ->whereIn('debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2])
            ->orderByDesc('id');
    }

    public function transferCreditCards(): HasManyThrough
    {
        return $this->hasManyThrough(Transfer::class, CreditCard::class, 'user_id', 'credit_card_id', 'id', 'id');
    }

    public function devices()
    {
        return $this->hasMany(UserDevice::class);
    }

    public function profile(): HasOne
    {
        return $this->hasOne(Profile::class);
    }
}
