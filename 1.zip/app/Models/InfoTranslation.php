<?php

namespace App\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\InfoTranslation
 *
 * @property int $id
 * @property string $key
 * @property string $label_uz
 * @property string $label_oz
 * @property string $label_en
 * @property string $label_ru
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation query()
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereLabelEn($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereLabelOz($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereLabelRu($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereLabelUz($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InfoTranslation whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class InfoTranslation extends Model
{
    use CrudTrait;

    /*
    |--------------------------------------------------------------------------
    | GLOBAL VARIABLES
    |--------------------------------------------------------------------------
    */

    protected $table = 'info_translations';
    // protected $primaryKey = 'id';
    // public $timestamps = false;
    protected $guarded = ['id'];
    // protected $fillable = [];
    // protected $hidden = [];
    // protected $dates = [];

    /*
    |--------------------------------------------------------------------------
    | FUNCTIONS
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | RELATIONS
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | SCOPES
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | ACCESSORS
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | MUTATORS
    |--------------------------------------------------------------------------
    */
}
