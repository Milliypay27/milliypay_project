<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;

class ServicesSheet
{
    private $transfers;

    public function __construct($transfers)
    {

        $this->transfers = $transfers;
    }

    public function view(): View
    {
        return view('transactions.transfers.exports.services_information_sheet', ['transfers' => $this->transfers]);
    }
}
