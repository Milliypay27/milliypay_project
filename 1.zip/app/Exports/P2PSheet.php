<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;

class P2PSheet
{
    private $transfers;

    public function __construct($transfers)
    {

        $this->transfers = $transfers;
    }

    public function view(): View
    {
        return view('transactions.transfers.exports.p2p_information_sheet', ['transfers' => $this->transfers]);
    }
}
