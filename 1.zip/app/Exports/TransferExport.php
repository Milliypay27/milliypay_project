<?php

namespace App\Exports;

use DB;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Models\Transfer;

class TransferExport
{
    public function sheets(): array
    {
        $sheets = [];

        $transfers = Transfer::query()
            ->select([
                'transfers.*',
                'pg.title_uz as payment_group_title',
                DB::raw('coalesce(service_id, false) as isnull')
            ])
            ->leftJoin('payment_services as ps', 'ps.id', '=', 'transfers.service_id')
            ->leftJoin('payment_groups as pg', 'ps.payment_group_id', '=', 'pg.id')
            ->whereIn('transfers.debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2])
            ->whereBetween('transfers.created_at', [request('from'), request('to')])
            ->orderByDesc('updated_at')->get()->groupBy('isnull');

        $sheets['p2p'] = (new P2PSheet($transfers[0] ?? []))->view()->render();
        $sheets['services'] = (new ServicesSheet($transfers[1] ?? []))->view()->render();

        return $sheets;
    }
}
