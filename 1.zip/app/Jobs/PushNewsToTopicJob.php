<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Kreait\Firebase\Messaging\CloudMessage;
use Illuminate\Contracts\Queue\ShouldBeUnique;

class PushNewsToTopicJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $news;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($news)
    {
        $this->news = $news;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $messaging = app('firebase.messaging');

        foreach(config('app.any_locales') as $lang){
            $message = CloudMessage::fromArray([
                'topic' => 'news_'.$lang,
                'data' => [
                    'event'      => 'news',
                    'id'         => $this->news->id,
                    'title'      => $this->news->{'title_'.$lang},
                    'desc'       => $this->news->{'desc_'.$lang},
                    'image'      => url('/').'/'.$this->news->image,
                    'created_at' => $this->news->created_at,
                    'url'        => url('/').'/news/'.$this->news->id.'/'.$lang
                ],
            ]);
            
            $messaging->send($message);
        }
    }
}
