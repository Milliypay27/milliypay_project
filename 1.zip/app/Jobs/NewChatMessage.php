<?php

namespace App\Jobs;

use App\Models\UserDevice;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Kreait\Firebase\Messaging\CloudMessage;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use WeStacks\TeleBot\Laravel\TeleBot;

class NewChatMessage implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $user_id;
    private $is_admin;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($user_id, $is_admin = false)
    {
        $this->user_id = $user_id;
        $this->is_admin = $is_admin;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $messaging = app('firebase.messaging');

        if  ($this->is_admin) {
            $tokens = UserDevice::where('user_id', $this->user_id)->pluck('device_token')->toArray();

            $message = CloudMessage::fromArray([
                'token' => $tokens,
                'data' => [
                    'event' =>  'new_chat_message'
                ],
            ]);
            
            $messaging->send($message);
        } else {
            TeleBot::sendMessage([
                'chat_id' => env("ONLINE_CHAT_CHANNEL"),
                'text' => "Mijozdan yangi xabar keldi"
            ]);
        }
    }
}
