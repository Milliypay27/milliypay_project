<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class MessageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $text = $this->is_file ? asset('storage/' . $this->text) : $this->text;
        return [
            'id'            =>  $this->id,
            'by_admin'      =>  $this->by_admin,
            'text'          =>  $text,
            'read'          =>  $this->read,
            'is_file'       =>  $this->is_file,
            'created_at'    =>  $this->created_at,
        ];
    }
}
