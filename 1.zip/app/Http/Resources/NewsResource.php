<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class NewsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $title = 'title_'.app()->getLocale();
        $desc = 'desc_'.app()->getLocale();
        return [
            'id'         => $this->id,
            'title'      => $this->$title,
            'desc'       => $this->$desc,
            'image'      => url('/').'/'.$this->image,
            'created_at' => $this->created_at,
            'url'        => url('/').'/news/'.$this->id.'/'.app()->getLocale()
        ];
    }
}
