<?php

namespace App\Http\Middleware;

use App\Models\HttpLog;
use Carbon\Carbon;
use Closure;
use Illuminate\Http\Request;

class HttpLoggerMiddleware
{
    /** @var $start Carbon */
    public $start;

    /** @var $end Carbon */
    public $end;

    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $this->start = now();
        return $next($request);
    }

    public function terminate(Request $request, $response)
    {
        $this->end = now();
        $this->saveToDb($request, $response);
    }

    public function saveToDb(Request $request, $response)
    {
        $model = new HttpLog();

        $model->start = $this->start;
        $model->end = $this->end;
        $model->duration = $this->start->diffInSeconds($this->end);
        $model->url = $request->fullUrl();
        $model->method = $request->getMethod();
        $model->ip = $request->getClientIp();
        $model->head = json_encode($request->header());

        $model->body = $request->getContent();
        $model->response = $response;
        $model->status = $response->getStatusCode();

        $model->save();
    }
}
