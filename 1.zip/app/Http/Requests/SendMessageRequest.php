<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * @property-read string $text
 * @property-read int $user_id
*/
class SendMessageRequest extends FormRequest
{

    public function authorize()
    {
        return backpack_auth()->check();
    }

    public function rules()
    {
        return [
            'text' => ['required'],
            'user_id' => ['required', Rule::exists('users', 'id')]
        ];
    }

    public function attributes()
    {
        return [
            'text' => 'Xabar matni'
        ];
    }
}
