<?php

namespace App\Http\Controllers;

use App\Http\Requests\ChangePhoneRequest;
use App\Models\User;
use Modules\Otp\Models\OtpSms;
use Response;

class ChangePhoneController extends Controller
{
    public function update(ChangePhoneRequest $request)
    {
        $otp = OtpSms::where('key', $request->get('key'))->whereIsUsed(false)->firstOrFail();
        $otp->update(['is_used' => true]);

        /** @var $user User */
        $user = auth('api')->user();
        $user->update(['phone' => $request->get('phone')]);

        return Response::noContent();
    }
}
