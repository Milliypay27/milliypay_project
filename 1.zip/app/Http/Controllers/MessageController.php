<?php

namespace App\Http\Controllers;

use App\Models\Message;
use Illuminate\Http\Request;
use App\Services\MessageService;
use App\Http\Resources\MessageResource;
use App\Jobs\NewChatMessage;
use Illuminate\Support\Facades\Validator;

class MessageController extends Controller
{
    public $limit;
    public $offset;
    private MessageService $service;

    public function __construct(MessageService $service)
    {
        $this->service = $service;
        $this->offset = request()->query('offset', 0);
        $this->limit = request()->query('limit', 10);
    }

    public function index()
    {
        $this->service->setReadStatus(auth()->id(), true);
        $messages = Message::query();
        return [
            'items' => MessageResource::collection($messages
            ->whereUserId(auth()->id())->offset($this->offset)->limit($this->limit)
            ->latest()->get()),

            'metaData' => [
                'limit' => $this->limit,
                'offset' => $this->offset,
                'totalItems' => $messages->count()
            ]
        ];
    }

    public function unread()
    {
        return $this->service->unreadUserMessages(auth()->id());
    }

    public function create()
    {
        //
    }

    public function send(Request $request)
    {
        $data['text'] = $request->text;
        $data['user_id'] = auth()->id();
        $message = $this->service->createMessage($data);

        dispatch(new NewChatMessage(auth()->id()));

        return [
            'success' => true
        ];
    }

    public function sendFile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'image|mimes:jpeg,png,jpg,gif|max:5120'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'code' => '1100',
                'message' => __('File type not allowed')
            ], 400);
        }

            $path = $request->file('file')->store('messages', ['disk' => 'local']);
            $data['text']       = $path;
            $data['is_file']    = true;
            $data['user_id']    = auth()->id();

            $message = $this->service->createMessage($data);

            dispatch(new NewChatMessage(auth()->id()));

            return [
                'success' => true
            ];
    }


    public function show(Message $message)
    {
        //
    }


    public function edit(Message $message)
    {
        //
    }


    public function update(Request $request, Message $message)
    {
        //
    }


    public function destroy(Message $message)
    {
        //
    }
}
