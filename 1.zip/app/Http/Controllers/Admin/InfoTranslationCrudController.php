<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\InfoTranslationRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Modules\Unired\Models\InfoTranslation;


class InfoTranslationCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;
    use ShowOperation;

    public function setup()
    {
        CRUD::setModel(InfoTranslation::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/info-translation');
        CRUD::setEntityNameStrings('info translation', 'info translations');
    }

    protected function setupListOperation()
    {
        CRUD::column('row_number')->type('row_number')->label('#');

        CRUD::column('key');

        CRUD::column('label_uz')->label('Label (Cyril)');
//        CRUD::column('label_oz');
        CRUD::column('label_en')->label('Label (Latin)');
        CRUD::column('label_ru')->label('Label (Ru)');
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    protected function setupCreateOperation()
    {
        CRUD::setValidation(InfoTranslationRequest::class);

        CRUD::field('key');
        CRUD::field('label_uz')->label('Label (Cyril)');
//        CRUD::field('label_oz');
        CRUD::field('label_en')->label('Label (Latin)');
        CRUD::field('label_ru')->label('Label (Ru)');

    }
}
