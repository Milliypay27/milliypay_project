<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\ConfigRequest;
use App\Models\Config;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;

class ConfigCrudController extends CrudController
{
    use ListOperation;
    use UpdateOperation;
    use ShowOperation;

    public function setup()
    {
        CRUD::setModel(Config::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/config');
        $this->crud->setTitle('Sozlamalar');
        $this->crud->setHeading('Ilova sozlamalari');
        CRUD::setEntityNameStrings('sozlama', 'sozlamalar');
    }

    protected function setupListOperation()
    {
//        $this->crud->query = Config::where('visible', true)->latest();

        CRUD::column('name')->type('text');
        CRUD::column('value')->type('text');
//        CRUD::addColumn(['name' => 'description', 'limit' => 120]);
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    protected function setupCreateOperation()
    {
        CRUD::setValidation(ConfigRequest::class);

        CRUD::field('name');
        CRUD::field('value');
        CRUD::field('description');
    }
}
