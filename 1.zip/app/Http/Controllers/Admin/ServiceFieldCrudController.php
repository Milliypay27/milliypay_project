<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\ServiceFieldRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Illuminate\Database\Eloquent\Builder;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Models\ServiceField;


class ServiceFieldCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;
    use ShowOperation;

    public function setup()
    {
        CRUD::setModel(ServiceField::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/service-field');
        CRUD::setEntityNameStrings('service field', 'service fields');
    }

    protected function setupListOperation()
    {
        $this->filters();

        CRUD::column('row_number')->type('row_number')->label('#');

        CRUD::addColumn([
            'name' => 'payment_service_id',
            'type' => 'select',
            'attribute' => 'title_en'
        ]);

        CRUD::column('name');

        CRUD::column('title_en')->label('Title (Latin)');
        CRUD::column('title_ru')->label('Title (Ru)');

        CRUD::addColumn([
            'name' => 'type',
            'type' => 'select_from_array',
            'options' => ServiceField::types()
        ]);

        CRUD::column('pattern');
        CRUD::column('order');

    }

    private function filters()
    {
        CRUD::addFilter([
            'name' => 'provider_id', 'type' => 'select2', 'label' => __('Provider'),
        ], PaymentGroup::pluck('title_en', 'id')->toArray(), function ($value) {
            return $this->crud->query = ServiceField::whereHas('payment_service',
                function (Builder $query) use ($value) {
                    $query->where('payment_group_id', $value);
            });
        });

        CRUD::addFilter([
            'name' => 'field_id', 'type' => 'select2', 'label' => __('Field'),
        ], ServiceField::pluck('title_en', 'id')->toArray(), function ($value) {
            return $this->crud->query = ServiceField::whereHas('payment_service',
                function (Builder $query) use ($value) {
                    $query->where('payment_group_id', $value);
                });
        });
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    protected function setupCreateOperation()
    {
        CRUD::setValidation(ServiceFieldRequest::class);

        CRUD::addField([
            'name' => 'payment_service_id',
            'type' => 'select',
            'attribute' => 'title_en'
        ]);

        CRUD::field('name')->size(6);

        CRUD::field('title_uz')->size(6)->label('Title (Cyril)');
//        CRUD::field('title_oz')->size(6);
        CRUD::field('title_ru')->size(6)->label('Title (Ru)');
        CRUD::field('title_en')->size(6)->label('Title (Latin)');

        CRUD::addField([
            'name' => 'type',
            'type' => 'select2_from_array',
            'options' => ServiceField::types(),
            'allows_null' => false,
            'default' => ServiceField::STRING_TYPE,
        ]);
        CRUD::field('pattern');
        CRUD::field('order');

        CRUD::field('external_id');
        CRUD::field('with_prefix');
        CRUD::field('placeholder');
        CRUD::field('full_pattern');
        CRUD::field('max_length');
    }
}
