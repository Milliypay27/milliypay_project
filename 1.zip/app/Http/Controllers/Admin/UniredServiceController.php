<?php


namespace App\Http\Controllers\Admin;


use Alert;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Client\Request;
use Illuminate\Http\RedirectResponse;
use Modules\Unired\Http\Requests\UniredServiceRequest;
use Modules\Unired\Models\PaymentCategory;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Services\PaymentServiceService;
use Modules\Unired\Services\UniredRequestService;
use Modules\Unired\Services\UniredService;

class UniredServiceController extends Controller
{
    protected UniredRequestService $uniredRequestService;
    private UniredService $uniredService;
    private PaymentServiceService $paymentService;

    public function __construct()
    {
        $this->uniredRequestService = new UniredRequestService();
        $this->uniredService = new UniredService();
        $this->paymentService = new PaymentServiceService();
    }

    /**
     * @param UniredServiceRequest $request
     * @return Application|Factory|View
     */
    public function index(UniredServiceRequest $request)
    {
        $paymentServices = $this->uniredRequestService->getAllPaymentService($request);

        return view('unired.payment.list', compact('paymentServices'));
    }

    public function create()
    {
        $categories = PaymentCategory::all();
        $id = request('id');
        $service = request('service');

        $paymentService = $this->paymentService->getFirst($id, $service);

        return view('unired.payment.create', compact('paymentService', 'categories'));
    }

    public function store(UniredServiceRequest $request): RedirectResponse
    {
        $this->paymentService->createModel($request->validated());
        return redirect()->route('admin.unired-services.index')->with('success', 'Created successfully');
    }

    public function refresh()
    {
        $this->uniredService->getAllPaymentService(auth('admin')->user());
        Alert::success('Successfully refreshed unired payment service!');

        return back();
    }

    public function getPaymentGroup()
    {
        return PaymentGroup::whereCategoryId(request('id'))
            ->get()->map(function (PaymentGroup $paymentGroup) {
                return [
                    'title' => $paymentGroup->title,
                    'id' => $paymentGroup->id
                ];
            });
    }
}
