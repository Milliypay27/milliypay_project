<?php

namespace App\Http\Controllers\Admin;

use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Modules\Unired\Models\UniredRequest;


class UniredRequestCrudController extends CrudController
{
    use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;


    public function setup()
    {
        CRUD::setModel(UniredRequest::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/unired-request');
        CRUD::setEntityNameStrings('unired request', 'unired requests');

        CRUD::setShowView('transactions.unired-requests.show');
    }

    protected function setupListOperation()
    {
        $this->filters();

        CRUD::column('method');
        CRUD::column('status')->type('boolean');
        CRUD::column('created_at');

        CRUD::column('remote_timestamp')->visibleInTable(false);
        CRUD::column('user_id')->visibleInTable(false);
        CRUD::column('admin_id')->visibleInTable(false);
    }

    private function filters()
    {
        CRUD::addFilter([
            'name' => 'method',
            'label' => __('Method'),
            'type' => 'select2',
        ], function () {
            return UniredRequest::pluck('method', 'method')->union('method')->toArray();
        }, function ($value) {
            $this->crud->addClause('where', 'method', $value);
        });

        CRUD::addFilter([
            'name' => 'status',
            'type' => 'dropdown'
        ], [1 => 'Yes', 0 => 'No']);
    }
}
