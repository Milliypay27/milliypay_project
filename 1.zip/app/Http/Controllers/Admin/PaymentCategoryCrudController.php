<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\PaymentCategoryRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanel;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Modules\Unired\Models\PaymentCategory;

/**
 * Class PaymentCategoryCrudController
 * @package App\Http\Controllers\Admin
 * @property-read CrudPanel $crud
 */
class PaymentCategoryCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;
    use ShowOperation;


    public function setup()
    {
        CRUD::setModel(PaymentCategory::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/payment-category');
        CRUD::setEntityNameStrings("kategoriya", "Kategoriyalar");
    }

    protected function setupListOperation()
    {
        $this->crud->query = PaymentCategory::query()->orderByDesc('position');

        CRUD::column('row_number')->type('row_number')->label('#');

        CRUD::column('icon')->type('image')->disk('public')->label("Ikonka");

        CRUD::column('title_en')->label('Sarlavha');
        CRUD::column('title_uz')->label('Сарлавҳа');
        CRUD::column('title_ru')->label('Заголовок');

        CRUD::column('position')->label("Pozitsiyasi");

        CRUD::column('visible')->label("Holati");
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    protected function setupCreateOperation()
    {
        CRUD::setValidation(PaymentCategoryRequest::class);

        CRUD::addField([
            'name' => 'icon',
            'type' => 'upload',
            'upload' => true,
            'disk' => 'public'
        ]);

        CRUD::field('title_uz')->size(6)->label('Title (Cyril)');
//        CRUD::field('title_oz')->size(6);
        CRUD::field('title_ru')->size(6)->label('Title (Ru)');
        CRUD::field('title_en')->size(6)->label('Title (Latin)');

        CRUD::field('position')->size(6);

        CRUD::field('visible')->size(6)->label("Aktiv holatda");
    }
}
