<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\IgnoredFieldRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanel;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Modules\Unired\Models\IgnoredField;


class IgnoredFieldCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;


    public function setup()
    {
        CRUD::setModel(IgnoredField::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/ignored-field');
        CRUD::setEntityNameStrings('', 'ignored fields');
    }


    protected function setupListOperation()
    {
        CRUD::column('row_number')->type('row_number')->label('#');

        CRUD::addColumn([
            'name' => 'payment_group_id',
            'entity' => 'paymentGroup',
            'attribute' => 'title'
        ]);

        CRUD::column('key');
        CRUD::column('created_at');
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }


    protected function setupCreateOperation()
    {
        CRUD::setValidation(IgnoredFieldRequest::class);

        CRUD::addField([
            'name' => 'payment_group_id',
            'type' => 'select2',
            'entity' => 'paymentGroup',
            'attribute' => 'title'
        ]);

        CRUD::field('key');
    }
}
