<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\SendMessageRequest;
use App\Models\Message;
use App\Models\User;
use App\Services\MessageService;
use Illuminate\Database\Eloquent\Builder;

class ChatController extends Controller
{
    private MessageService $service;

    public function __construct(MessageService $service)
    {
        $this->service = $service;
    }

    public function index()
    {
        return view('chat.index', [
            'rooms' => $this->service->getRooms(),
            'message_url' => route('admin.chat.messages', ['user_id' => request('user_id', 0)]),
            'currentPerson' => User::find(request('user_id', 0))
        ]);
    }

    public function messages()
    {
        $messages = $this->service->messages(request('user_id', false));

        return view('chat.messages', compact('messages'));
    }

    public function send(SendMessageRequest $request)
    {
        Message::create(array_merge($request->validated(), [
            'by_admin' => true,
            'read' => 0,
            'is_file' => 0,
        ]));

        return back();
    }
}
