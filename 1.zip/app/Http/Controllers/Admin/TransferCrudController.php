<?php

namespace App\Http\Controllers\Admin;

use App\Exports\TransferExport;
use App\Http\Requests\ExportTransferRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Excel;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Client\Request;
use Modules\Unired\Constants\TransferDTOStatuses;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Services\OfdService;
use Modules\Unired\Services\PaymentService;
use Modules\Unired\Services\TransferService;
use Modules\Unired\Services\UniredMtsService;
use Modules\Unired\Services\UniredService;
use Prologue\Alerts\Facades\Alert;


class TransferCrudController extends CrudController
{
    use ListOperation;
    use ShowOperation;

    public function setup()
    {
        CRUD::setModel(Transfer::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/transfer');
        CRUD::setEntityNameStrings('transfer', 'transfers');

        CRUD::setListView('transactions.transfers.list');
        CRUD::setShowView('transactions.transfers.show');

        CRUD::enableExportButtons();
    }

    public function export(ExportTransferRequest $request)
    {
        return (new TransferExport())->sheets();
    }

    protected function setupListOperation()
    {
        $this->filters();

        CRUD::column('row_number')->type('row_number')->label('#');

        CRUD::addColumn([
            'name' => 'user_id',
            'attribute' => 'phone',
            'searchLogic' => function ($query, $column, $searchTerm) {
                $query->orWhereHas('user', function ($q) use ($column, $searchTerm) {
                    $q->where('phone', 'like', '%'.$searchTerm.'%');
                });
            }
        ]);

        CRUD::addColumn([
            'name' => 'credit_card_id',
            'entity' => 'creditCard',
            'attribute' => 'number',
            'searchLogic' => function ($query, $column, $searchTerm) {
                $query->orWhereHas('creditCard', function ($q) use ($column, $searchTerm) {
                    $q->where('number', 'like', '%'.$searchTerm.'%');
                });
            }
        ]);

        CRUD::addColumn([
            'name' => 'status',
            'type' => 'view',
            'view' => 'admin.transfers.columns.status'
        ]);

        CRUD::column('credit_card_number')->visibleInTable(false);
        CRUD::column('ext_id');
        CRUD::column('credit_description');
        CRUD::column('amount');
        CRUD::column('created_at');
    }

    private function filters()
    {
        CRUD::addFilter([
            'name' => 'user',
            'type' => 'text',
        ], false, function ($value) {
            return $this->crud->query = Transfer::whereHas('user', function (Builder $query) use ($value) {
                return $query->where('phone', 'like', "%{$value}%");
            });
        });

        CRUD::addFilter([
            'name' => 'credit_card',
            'type' => 'text',
        ], false, function ($value) {
            return $this->crud->query = Transfer::whereHas('creditCard', function (Builder $query) use ($value) {
                return $query->where('number', 'like', "%{$value}%");
            });
        });

        CRUD::addFilter([
            'name' => 'status',
            'type' => 'dropdown'
        ], [0 => 'success', 2 => 'error'], function ($value) {
            $function_name = $value ? 'error' : 'success';
            $this->crud->addClause($function_name);
        });

        CRUD::addFilter([
            'type'  => 'date_range',
            'name'  => 'from_to',
            'label' => 'Date range'
        ],
            false,
            function ($value) {
                 $dates = json_decode($value);
                 $this->crud->addClause('where', 'created_at', '>=', $dates->from);
                 $this->crud->addClause('where', 'created_at', '<=', $dates->to . ' 23:59:59');
            });

        CRUD::addFilter([
            'name'       => 'range',
            'type'       => 'range',
            'label'      => 'Range',
            'label_from' => 'min',
            'label_to'   => 'max'
        ],
            false,
            function($value) {
                $range = json_decode($value);
                if ($range->from) {
                    $this->crud->addClause('where', 'amount', '>=', (float) $range->from);
                }
                if ($range->to) {
                    $this->crud->addClause('where', 'amount', '<=', (float) $range->to);
                }
            });

        CRUD::addFilter([
            'name'  => 'type',
            'type'  => 'dropdown',
            'label' => 'Type'
        ], [
            0 => 'P2P',
            1 => 'Payment',
        ], function($value) {
            if ($value) {
                $this->crud->addClause('whereNotNull', 'service_id');
            } else {
                $this->crud->addClause('whereNull', 'service_id');
            }
        });
    }

    public function refreshOfd(Transfer $transfer, OfdService $ofdService)
    {
        $ofdService->run($transfer);

        return back();
    }

    public function editReceiver(Transfer $transfer, \Illuminate\Http\Request $request)
    {
        $data = $request->validate([
            'owner' => 'required',
            'number' => 'required|min:16|max:16'
        ]);

        dd($data, $transfer);

        Alert::success(trans('backpack::crud.update_success'))->flash();

        return back();
    }

    public function state(Transfer $transfer, TransferService $transferService)
    {
        $params = [
            'ext_id' => $transfer->ext_id
        ];

        $uniredService = (new UniredService());
        if ($transfer->id > 48595) {
            $uniredService = new UniredMtsService();
        }

        $response = $transfer->service_id ?
            $uniredService->paymentState($params) :
            $uniredService->transferState($params);

//
//        if (auth('admin')->id() == 5) {
//            dd($response);
//        }

        if ($response->status) {
            if ($transfer->service_id) {
                (new PaymentService)->updateUniredCallbackAttributes($response->response, $transfer);
            } else {
                try {
                    $transferService->updateUniredCallbackAttributes($response->response, $transfer);

                } catch (\Exception $exception) {
                }
            }
        }

        return back();
    }
}
