<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Modules\Unired\Services\UniredService;

class CommissionController extends Controller
{
    private UniredService $uniredService;

    public function __construct()
    {
        $this->uniredService = new UniredService();
    }

    public function index()
    {
        $commissions = $this->uniredService->getCommissionsByColumn('commissions');

        return view('unired.commission.list', compact('commissions'));
    }

    public function sync(): RedirectResponse
    {
        $this->uniredService->syncCommissions();
        return redirect()->back();
    }

    public function paymentCommissions()
    {
        $commissions = $this->uniredService->getCommissionsByColumn('commission_payment');

        return view('unired.commission.list', compact('commissions'));
    }
}
