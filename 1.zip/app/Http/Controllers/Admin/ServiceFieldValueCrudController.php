<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\ServiceFieldValueRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanel;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use DB;
use Illuminate\Database\Eloquent\Builder;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Models\PaymentService;
use Modules\Unired\Models\ServiceField;
use Modules\Unired\Models\ServiceFieldValue;

/**
 * Class ServiceFieldValueCrudController
 * @package App\Http\Controllers\Admin
 * @property-read CrudPanel $crud
 */
class ServiceFieldValueCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;
    use ShowOperation;

    public function setup()
    {
        CRUD::setModel(ServiceFieldValue::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/field-value');
        CRUD::setEntityNameStrings('', __('Service field values'));
    }

    public function serviceOptions()
    {
        return PaymentService::query()
            ->join('payment_groups', 'payment_groups.id', '=', 'payment_services.payment_group_id')
            ->when(request('group_id'), function (Builder $query, $group_id) {
                $query->where('payment_group_id', $group_id);
            })
            ->select([
                'payment_services.*',
                DB::raw('payment_groups.title_en as group_name'),
                DB::raw("concat('(',payment_groups.title_en,') ',payment_services.title_en) as service_name")
            ])
            ->where(function (Builder $query) {
                $term = request('term');
                $query->orWhere('payment_services.title_en', 'like', "%{$term}%");
                $query->orWhere('payment_services.title_ru', 'like', "%{$term}%");
                $query->orWhere('payment_services.title_uz', 'like', "%{$term}%");
                $query->orWhere('payment_services.title_oz', 'like', "%{$term}%");
            })
            ->pluck('service_name', 'id')
            ->toArray();
    }

    protected function setupListOperation()
    {
        $this->crud->query = ServiceFieldValue::query()
            ->join('service_fields', 'service_fields.id', '=', 'service_field_values.service_field_id')
            ->join('payment_services', 'payment_services.id', '=', 'service_fields.payment_service_id')
            ->join('payment_groups', 'payment_groups.id', '=', 'payment_services.payment_group_id')
            ->select([
                'service_field_values.*',
                DB::raw('payment_services.title_en as service_name'),
                DB::raw('payment_services.id as service_id'),
                DB::raw('payment_groups.id as group_id'),
                DB::raw('payment_groups.title_en as group_name'),
            ]);

        $this->filters();

        CRUD::column('id');
        CRUD::column('service_field_id');
        CRUD::column('group_name');
        CRUD::column('service_name');
        CRUD::column('title_uz')->label('Title (Cyril)');
        CRUD::column('title_ru')->label('Title (Ru)');
        CRUD::column('title_en')->label('Title (Latin)');
        CRUD::column('order');
        CRUD::column('external_id');
    }

    private function filters()
    {
        CRUD::addFilter([
            'name' => 'group_id',
            'type' => 'select2',
            'label' => __('Provider')
        ], PaymentGroup::pluck('title_en', 'id')->toArray(), function ($value) {
            $this->crud->addClause('where', 'payment_groups.id', '=', $value);
        });

        CRUD::addFilter([
            'name' => 'service_id',
            'type' => 'select2_ajax',
            'label' => __('Payment service')
        ], url('admin/service-field-value/ajax-service-options'),
            function ($value) {
                $this->crud->addClause('where', 'payment_services.id', '=', $value);
            });
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    protected function setupCreateOperation()
    {
        CRUD::setValidation(ServiceFieldValueRequest::class);

        CRUD::addField([
            'name' => 'service_field_id',
            'type' => 'select2_from_array',
            'options' => ServiceField::query()
                ->join('payment_services', 'payment_services.id', '=', 'service_fields.payment_service_id')
                ->join('payment_groups', 'payment_groups.id', '=', 'payment_services.payment_group_id')
                ->where('type', ServiceField::SELECT_TYPE)
                ->select([
                    'service_fields.*',
                    DB::raw("concat(payment_groups.title_en, ' - ', '(', payment_services.title_en, ') ', service_fields.name) as field_name")
                ])->pluck('field_name', 'id')->toArray(),
            'allows_null' => false,
        ]);

        CRUD::field('title_uz')->label('Title (Cyril)');
        CRUD::field('title_ru')->label('Title (Ru)');
        CRUD::field('title_en')->label('Title (Latin)');
        CRUD::field('order');

        CRUD::field('external_id');
    }
}
