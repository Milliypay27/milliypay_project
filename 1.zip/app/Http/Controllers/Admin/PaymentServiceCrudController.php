<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\PaymentServiceRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Models\PaymentService;


class PaymentServiceCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;
    use ShowOperation;


    public function setup()
    {
        CRUD::setModel(PaymentService::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/payment-service');
        CRUD::setEntityNameStrings('payment service', 'payment services');
    }


    protected function setupListOperation()
    {
        $this->crud->query = PaymentService::query()->orderBy(PaymentService::SORTABLE_FIELD['sortable_column']);

        CRUD::column('row_number')->type('row_number')->label('#');

//        CRUD::column('ext_service_id');
//        CRUD::column('ext_info_id');
//        CRUD::column('ext_provider_id');
//        CRUD::column('min_amount');
//        CRUD::column('max_amount');
//        CRUD::column('amount_field_name');

        CRUD::addColumn(['name' => 'payment_group_id', 'attribute' => 'title_en', 'label' => 'Provider']);

        CRUD::column('title_en')->label('Title (Latin)');
        CRUD::column('title_uz')->label('Title (Cyril)');
        CRUD::column('title_ru')->label('Title (Ru)');

        CRUD::column('order');

        CRUD::addFilter([
            'name' => 'provider_id', 'type' => 'select2', 'label' => __('Provider'),
        ], PaymentGroup::pluck('title_uz', 'id')->toArray(), function ($value) {
            return $this->crud->addClause('where', 'payment_group_id', $value);
        });
    }


    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }


    protected function setupCreateOperation()
    {
        CRUD::setValidation(PaymentServiceRequest::class);

        CRUD::field('ext_service_id')->size(3);
        CRUD::field('ext_info_id')->size(3);
        CRUD::field('ext_provider_id')->size(3);
        CRUD::field('amount_field_name')->size(3);

        CRUD::field('min_amount')->size(6);
        CRUD::field('max_amount')->size(6);

        CRUD::field('title_uz')->size(6)->label('Title (Cyril)');
//        CRUD::field('title_oz')->size(6);
        CRUD::field('title_ru')->size(6)->label('Title (Ru)');
        CRUD::field('title_en')->size(6)->label('Title (Latin)');

        CRUD::field('position')->size(6);

        CRUD::addField([
            'name' => 'payment_group_id',
            'label' => 'Provider',
            'type' => 'select2',
            'model' => PaymentGroup::class,
            'attribute' => 'title_uz'
        ]);
    }
}
