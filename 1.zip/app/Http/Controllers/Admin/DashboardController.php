<?php

namespace App\Http\Controllers\Admin;

use App\Dtos\CommissionDTO;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Modules\Unired\Constants\TransferCreditStatuses;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Constants\TransferDTOStatuses;
use Modules\Unired\Constants\UniredCurrencyCodes;
use Modules\Unired\Models\PaymentCategory;
use Modules\Unired\Models\Transfer;

class DashboardController extends Controller
{
    public function index()
    {
        $begin_date = request('begin_date', date('Y-m-01'));
        $end_date = request('end_date', date('Y-m-d'));

        $categories = PaymentCategory::all();

        $result = [];

        $transfers = Transfer::query()
            ->leftJoin('payment_services', 'payment_services.id', '=', 'transfers.service_id')
            ->leftJoin('payment_groups', 'payment_groups.id', '=', 'payment_services.payment_group_id')
            ->leftJoin('payment_categories', 'payment_categories.id', '=', 'payment_groups.category_id')
            ->whereDate('transfers.created_at', '>=', $begin_date)
            ->whereDate('transfers.created_at', '<=', $end_date)
            ->where(function (Builder $query) {
                $query->whereIn('debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2]);
                $query->orWhereIn('credit_state', [TransferCreditStatuses::SUCCESS, TransferCreditStatuses::PAYMENT_SUCCESS]);
//                $query->where('credit_state', TransferCreditStatuses::TRANSFER_SUCCESS);
            })

            ->get()
            ->map(function (Transfer $transfer) use (&$result) {
                $category_id = $transfer->service_id ? $transfer->category_id : 0;

                $amount = $transfer->amount;
                $rubles = $transfer->debit_amount / 100;
                $commission = $transfer->debit_commission / 100;
                $cost = $rubles - $commission;
                $rate = $transfer->currency_rate;
//                TransferDTOStatuses::status($transfer) == TransferDTOStatuses::SUCCESS

                $check = !$transfer->service_id && $transfer->credit_state == TransferCreditStatuses::PAYMENT_SUCCESS;

                if (!$check) {
                    if (!isset($result[$category_id])) {
                        $result[$category_id]['count'] = 1;
                        $result[$category_id][UniredCurrencyCodes::RUB] = $rubles;
                        $result[$category_id][UniredCurrencyCodes::UZS] = $amount;
                        $result[$category_id]['profit'] = $this->profit($cost, $rate);
                    } else {
                        $result[$category_id]['count']++;
                        $result[$category_id][UniredCurrencyCodes::RUB] += $rubles;
                        $result[$category_id][UniredCurrencyCodes::UZS] += $amount;
                        $result[$category_id]['profit'] += $this->profit($cost, $rate);
                    }
                }
            });

        return view('backpack::base.dashboard', compact('result', 'categories'));
    }

    public function profit($cost, $rate)
    {
        $commissions = $this->commissions();

        foreach ($commissions as $commission) {
            if ($commission->min <= $cost && $cost <= $commission->max) {
                return $cost * $commission->percentage * $rate + $commission->credit * $rate;
            }
        }

        return 0;
    }

    public function commissions()
    {
        return [
            new CommissionDTO(300, 900, 0, 0),
            new CommissionDTO(901, 4333, 0, 20),
            new CommissionDTO(4334, 50000, 0.006, 0)
        ];
    }
}
