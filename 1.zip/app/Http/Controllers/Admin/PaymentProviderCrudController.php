<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\PaymentProviderRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanel;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Modules\Unired\Models\PaymentCategory;
use Modules\Unired\Models\PaymentGroup;

/**
 * Class PaymentProviderCrudController
 * @package App\Http\Controllers\Admin
 * @property-read CrudPanel $crud
 */
class PaymentProviderCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;
    use ShowOperation;


    public function setup()
    {
        CRUD::setModel(PaymentGroup::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/payment-provider');
        CRUD::setEntityNameStrings("provayder", "Provayderlar");
    }


    protected function setupListOperation()
    {
        $this->crud->query = PaymentGroup::query()->orderBy(PaymentGroup::SORTABLE_FIELD['sortable_column']);

        CRUD::column('row_number')->type('row_number')->label('#');

        CRUD::column('image')->type('image')->disk('public')->label("Ikonka");
        CRUD::addColumn(['name' => 'category_id', 'attribute' => 'title_en', 'label' => "Kategoriya"]);

        CRUD::column('title_en')->label('Sarlavha');
        CRUD::column('title_uz')->label('Сарлавҳа');
        CRUD::column('title_ru')->label('Заголовок');

        CRUD::column('order')->label("Pozitsiyasi");

        CRUD::column('visible')->label("Holati");

        CRUD::addFilter([
            'name' => 'category_id', 'type' => 'select2', 'label' => "Kategoriya",
        ], PaymentCategory::pluck('title_uz', 'id')->toArray(), function ($value) {
            return $this->crud->addClause('where', 'category_id', $value);
        });

    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }


    protected function setupCreateOperation()
    {
        CRUD::setValidation(PaymentProviderRequest::class);

        CRUD::addField([
            'name' => 'image',
            'type' => 'upload',
            'upload' => true,
            'disk' => 'public'
        ]);

        CRUD::addField([
            'name' => 'category_id',
            'attribute' => 'title'
        ]);

        CRUD::field('title_uz')->size(6)->label('Title (Cyril)');
//        CRUD::field('title_oz')->size(6);
        CRUD::field('title_ru')->size(6)->label('Title (Ru)');
        CRUD::field('title_en')->size(6)->label('Title (Latin)');

        CRUD::field('order')->size(6);

        CRUD::field('visible')->size(6)->label("Aktiv holatda");
    }
}
