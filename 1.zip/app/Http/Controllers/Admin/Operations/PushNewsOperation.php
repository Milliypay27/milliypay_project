<?php

namespace App\Http\Controllers\Admin\Operations;

use App\Models\News;
use App\Jobs\PushNewsToTopicJob;
use Prologue\Alerts\Facades\Alert;
use Illuminate\Support\Facades\Route;

trait PushNewsOperation
{
    /**
     * Define which routes are needed for this operation.
     *
     * @param string $segment    Name of the current entity (singular). Used as first URL segment.
     * @param string $routeName  Prefix of the route name.
     * @param string $controller Name of the current CrudController.
     */
    protected function setupPushNewsRoutes($segment, $routeName, $controller)
    {
        Route::get($segment.'/{id}/pushnews', [
            'as'        => $routeName.'.pushnews',
            'uses'      => $controller.'@pushnews',
            'operation' => 'pushnews',
        ]);
    }

    /**
     * Add the default settings, buttons, etc that this operation needs.
     */
    protected function setupPushNewsDefaults()
    {
        $this->crud->allowAccess('pushnews');

        $this->crud->operation('pushnews', function () {
            $this->crud->loadDefaultOperationSettingsFromConfig();
        });

        $this->crud->operation('list', function () {
            $this->crud->addButtonFromModelFunction('line', 'activate', 'pushToFirebase', 'beginning');
            // $this->crud->addButton('line', 'pushnews', 'view', 'crud::buttons.pushnews');
        });
    }

    /**
     * Show the view for performing the operation.
     *
     * @return Response
     */
    public function pushnews($id)
    {
        $this->crud->hasAccessOrFail('pushnews');

        dispatch(new PushNewsToTopicJob(News::find($id)));
        Alert::add('success', '<strong>Muvaffaqiyatli!</strong><br>Yangilik barcha qurilmalarga yuborildi.')->flash();
        return redirect('/admin/news');
    }
}
