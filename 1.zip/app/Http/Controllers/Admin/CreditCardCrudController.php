<?php

namespace App\Http\Controllers\Admin;

use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanel;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Modules\Unired\Models\CreditCard;
use Modules\Unired\Repositories\CreditCardRepository;
use Modules\Unired\Services\CreditCardService;
use Modules\Unired\Services\UniredService;

/**
 * Class CreditCardCrudController
 * @package App\Http\Controllers\Admin
 * @property-read CrudPanel $crud
 */
class CreditCardCrudController extends CrudController
{
    use ListOperation;
    use ShowOperation;

    /** @throws Exception */
    public function setup()
    {
        CRUD::setModel(CreditCard::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/credit-card');
        CRUD::setEntityNameStrings('credit card', 'credit cards');

        CRUD::setShowView('admin.card.show');
    }

    public function state($ext_id, UniredService $uniredService, CreditCardRepository $cardRepository, CreditCardService $cardService)
    {
        $input = $uniredService->creditCardState($ext_id, auth()->user());
        $creditCard = $cardRepository->findByExternalIdAndOrderId($input['result']['ext_id'] ?? null, $input['result']['order_id'] ?? null);

        if ($creditCard) {
            $cardService->bindCardCallbackAttributes($creditCard, $input);
        }

        return back();
    }

    protected function setupListOperation()
    {
        $this->crud->query = CreditCard::with('user')->latest();
        $this->filters();

        CRUD::column('row_number')->type('row_number')->label('#');

        CRUD::addColumn([
            'name' => 'user_id',
            'label' => 'Phone',
            'attribute' => 'phone'
        ]);

        CRUD::column('owner');
        CRUD::column('number');
        CRUD::column('provider');
        CRUD::column('bank');
        CRUD::column('created_at');

//        CRUD::column('order_id')->type('text');
//        CRUD::column('ext_id')->type('text');
//        CRUD::column('description')->visibleInTable(false);
//        CRUD::column('state')->visibleInTable(false);
//        CRUD::column('name')->visibleInTable(false);
//        CRUD::column('ref_id')->type('text');
//        CRUD::column('expire')->visibleInTable(false);
    }

    private function filters()
    {
        CRUD::addFilter([
            'name' => 'phone',
            'type' => 'text'
        ], false, function ($value) {
            $this->crud->query = $this->crud->query->whereHas('user', function (Builder $query) use ($value) {
                return $query->where('phone', 'like', "%{$value}%");
            });
        });

        CRUD::addFilter([
            'name' => 'owner',
            'type' => 'text'
        ], false, function ($value) {
            return $this->crud->addClause('where', 'owner', 'like', "%{$value}%");
        });

        CRUD::addFilter([
            'name' => 'card_number',
            'type' => 'text'
        ], false, function ($value) {
            return $this->crud->addClause('where', 'number', 'like', "%{$value}%");
        });

        CRUD::addFilter([
            'name' => 'provider',
            'type' => 'text'
        ], false, function ($value) {
            return $this->crud->addClause('where', 'provider', 'like', "%{$value}%");
        });

        CRUD::addFilter([
            'name' => 'bank',
            'type' => 'text'
        ], false, function ($value) {
            return $this->crud->addClause('where', 'bank', 'like', "%{$value}%");
        });
    }
}
