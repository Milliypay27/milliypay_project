<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\NewsRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;

class NewsCrudController extends CrudController
{
    use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
    use \App\Http\Controllers\Admin\Operations\PushNewsOperation;

    public function setup()
    {
        CRUD::setModel(\App\Models\News::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/news');
        $this->crud->setTitle('Yangiliklar');
        $this->crud->setHeading('Yangiliklar');
        $this->crud->setEntityNameStrings("yangilik", "yangiliklar");
    }

    protected function setupListOperation()
    {
        CRUD::column('row_number')->type('row_number')->label('#');
//        CRUD::column('title_uz')->label("Kirilcha sarlavha");
//        CRUD::column('title_ru')->label("Ruscha sarlavha");
//        CRUD::column('title_en')->label("Lotincha sarlavha");
        CRUD::column('image')->label("Yangilik rasmi")->type('image')->height('100px')->width('auto');
    }

    protected function setupCreateOperation()
    {
        CRUD::setValidation(NewsRequest::class);

        CRUD::field('title_uz')->type('text')->label("Kirilcha sarlavha")->attributes(['autocomplete' => 'off']);
        CRUD::field('title_ru')->type('text')->label("Ruscha sarlavha")->attributes(['autocomplete' => 'off']);
        CRUD::field('title_en')->type('text')->label("Lotincha sarlavha")->attributes(['autocomplete' => 'off']);
        CRUD::field('desc_uz')->type('text')->label("Kirilcha opisaniya")->attributes(['autocomplete' => 'off']);
        CRUD::field('desc_ru')->type('text')->label("Ruscha opisaniya")->attributes(['autocomplete' => 'off']);
        CRUD::field('desc_en')->type('text')->label("Lotincha opisaniya")->attributes(['autocomplete' => 'off']);
        CRUD::field('body_uz')->type('wysiwyg')->label("Kirilcha matn");
        CRUD::field('body_ru')->type('wysiwyg')->label("Ruscha matn");
        CRUD::field('body_en')->type('wysiwyg')->label("Lotincha matn");
        CRUD::field('image')->type('image')->crop(true)->label("Yangilik rasmi");
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    protected function setupShowOperation()
    {
        CRUD::column('title_uz')->label("Kirilcha sarlavha");
        CRUD::column('title_ru')->label("Ruscha sarlavha");
        CRUD::column('title_en')->label("Lotincha sarlavha");
        CRUD::column('desc_uz')->label("Kirilcha opisaniya");
        CRUD::column('desc_ru')->label("Ruscha opisaniya");
        CRUD::column('desc_en')->label("Lotincha opisaniya");
        CRUD::column('body_uz')->type('markdown')->label("Kirilcha matn");
        CRUD::column('body_ru')->type('markdown')->label("Ruscha matn");
        CRUD::column('body_en')->type('markdown')->label("Lotincha matn");
        CRUD::column('image')->label("Yangilik rasmi")->type('image')->width('100%')->height('auto');
    }
}
