<?php

namespace App\Http\Controllers;

use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Transformers\TransferResponse;

class PDFController extends Controller
{
    public function cheque(Transfer $transfer)
    {
        abort_if(auth()->id() != $transfer->user_id, 404);

        $view = $transfer->service_id
            ? 'transactions.transfers.cheque_payment'
            : 'transactions.transfers.cheque_transfer';

        $pdf = Pdf::loadView($view, ['data' => $transfer]);

        return $pdf->download('cheque.pdf');
    }
}
