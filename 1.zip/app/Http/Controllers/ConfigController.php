<?php

namespace App\Http\Controllers;

use App\Models\Config;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class ConfigController extends Controller
{
    public function show()
    {
        $configs = Config::get()->pluck('value', 'name');

        Arr::forget($configs, ['aboutus_uz', 'aboutus_ru', 'aboutus_en']);

        $aboutus = Config::whereName('aboutus_'.app()->getLocale())->first();
        
        Arr::add($configs, 'aboutus', $aboutus->value);
        
        return $configs;
    }
}
