<?php

namespace App\Http\Controllers;

use App\Models\News;
use Illuminate\Http\Request;
use App\Http\Resources\NewsResource;

class NewsController extends Controller
{
    public $limit;
    public $offset;

    public function __construct()
    {
        $this->offset = request()->query('offset', 0);
        $this->limit = request()->query('limit', 10);
    }

    public function show()
    {
        $news = News::query();
        return [
            'items' => NewsResource::collection($news
            ->offset($this->offset)->limit($this->limit)
            ->latest()->get()),

            'metaData' => [
                'limit' => $this->limit,
                'offset' => $this->offset,
                'totalItems' => $news->count()
            ]
        ];
    }
}
