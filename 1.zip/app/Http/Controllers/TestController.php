<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Services\OfdService;

class TestController extends Controller
{
    public function test()
    {
        $transfer = Transfer::find(108429);

        try {
            (new OfdService())->run($transfer);
        } catch (\Exception $e) {
            dd($e->getMessage());
        }

        return ;
    }
}
