<?php

namespace App\Services;

use Exception;
use App\Models\User;
use App\Models\Message;
use Illuminate\Support\Str;
use Illuminate\Http\JsonResponse;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class MessageService
{

    public function createMessage($data)
    {
        return Message::create($data)->toArray();
    }

    public function getRooms()
    {
        return User::query()
            ->select('users.id as user_id', 'users.activity_at as user_activity_at', 'users.phone', 'messages.created_at as last_activity_date', 'messages.text as last_message_text', 'messages.is_file as is_file')
            ->addSelect(['unread_count' => Message::query()
                ->selectRaw('count(messages.id)')
                ->whereColumn('user_id', 'users.id')
                ->where('by_admin', false)
                ->where('read', Message::STATUS_UNREAD)])
            ->join('messages', function ($query) {
                $query->on('users.id', '=', 'messages.user_id')
                    ->whereRaw('messages.id IN (select MAX(m2.id) from messages as m2 join users as u2 on u2.id = m2.user_id group by u2.id)');
            })->orderByDesc('last_activity_date')
            ->paginate(6);
    }

    /**
     * @throws Exception
     */
    public function setReadStatus($user_id, $by_admin = false)
    {
        return Message::query()
            ->where('user_id', $user_id)
            ->where('read', Message::STATUS_UNREAD)
            ->where('by_admin', $by_admin)
            ->update(['read' => Message::STATUS_READ]);
    }

    public function unreadUserMessages($user_id)
    {
        return Message::query()->where('user_id', $user_id)->where('by_admin', true)->where('read', Message::STATUS_UNREAD)->count();
    }

    public function messages($user_id = null)
    {
        if($user_id){
            $this->setReadStatus($user_id);
            return Message::query()
                ->with('user')
                ->where('user_id', $user_id)
                ->latest()
                ->paginate(6);
        }else{
            return [];
        }
    }
}
