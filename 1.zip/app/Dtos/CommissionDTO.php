<?php

namespace App\Dtos;

class CommissionDTO
{
    public $min = 0;
    public $max = 0;
    public $percentage = 0;
    public $credit = 0;

    public function __construct($min, $max, $percentage, $credit)
    {
        $this->min = $min;
        $this->max = $max;
        $this->percentage = $percentage;
        $this->credit = $credit;
    }
}
