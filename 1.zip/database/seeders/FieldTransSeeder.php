<?php

namespace Database\Seeders;

use DB;
use Exception;
use Illuminate\Database\Seeder;
use Throwable;

class FieldTransSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     * @throws Throwable
     */
    public function run()
    {
        try {
            DB::transaction(function () {
                DB::update("update service_fields f set f.title_en = f.title_uz");
                DB::update("update service_fields f set f.title_uz = f.title_oz");
            });
        } catch (Exception $exception) {
            $this->command->info($exception->getMessage());
            DB::rollBack();
        }
    }
}
