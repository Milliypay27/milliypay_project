<?php

namespace Database\Seeders;

use DB;
use Exception;
use Illuminate\Database\Seeder;
use Schema;

class GazSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();

        try {
            DB::transaction(function () {
                DB::insert(file_get_contents(__DIR__ . '/sql/gaz_service.sql'));
                DB::insert(file_get_contents(__DIR__ . '/sql/gaz_service_fields.sql'));
                DB::insert(file_get_contents(__DIR__ . '/sql/gaz_service_field_values.sql'));
            });
        } catch (Exception $exception) {
            DB::rollBack();
            $this->command->info($exception->getMessage());
        }

        Schema::enableForeignKeyConstraints();
    }
}
