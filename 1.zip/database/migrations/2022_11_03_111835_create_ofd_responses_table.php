<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOfdResponsesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ofd_responses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained();
            $table->foreignId('transfer_id')->constrained();
            $table->integer('code')->nullable();
            $table->string('message')->nullable();
            $table->string('terminal_id')->nullable();
            $table->string('receipt_id')->nullable();
            $table->string('datetime')->nullable();
            $table->string('fiscal_sign')->nullable();
            $table->string('qr_code_url')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ofd_responses');
    }
}
