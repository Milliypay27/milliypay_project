<?php

use Illuminate\Database\Migrations\Migration;

class AddVersion extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \App\Models\Config::whereName('version')->existsOr(function () {
            \App\Models\Config::create([
                'name' => 'version',
                'value' => 6,
                'description' => 'version'
            ]);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        \App\Models\Config::whereName('version')->first()->delete();
    }
}
