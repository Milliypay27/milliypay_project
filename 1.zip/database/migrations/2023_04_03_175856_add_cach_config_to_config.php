<?php

use Illuminate\Database\Migrations\Migration;

class AddCachConfigToConfig extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \App\Models\Config::whereName('cash_registers')->existsOr(function () {
            \App\Models\Config::create([
                'name' => 'cash_registers',
                'value' => "mts,tkb",
                'description' => 'kassalar (mts,tkb)'
            ]);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $config = \App\Models\Config::whereName('cash_registers')->first();
        $config?->delete();
    }
}
