<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMinAmountUzsComissions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('configs', function (Blueprint $table) {
            $table->boolean('visible')->default(true);
        });

        \App\Models\Config::whereName('commissions_min')->update([
            'visible' => false
        ]);

        \App\Models\Config::whereName('payment_commissions_min')->update([
            'visible' => false
        ]);

        \App\Models\Config::whereName('commissions_min_uzs')->existsOr(function () {
            \App\Models\Config::create([
                'name' => 'commissions_min_uzs',
                'value' => 5280000,
                'description' => "Kartaga to`lov uchun min qiymat so`mda (tiyinlarda)"
            ]);
        });

        \App\Models\Config::whereName('payment_commissions_min_uzs')->existsOr(function () {
            \App\Models\Config::create([
                'name' => 'payment_commissions_min_uzs',
                'value' => 880000,
                'description' => "To`lovlar uchun min qiymat so`mda (uzs tiyinlarda)"
            ]);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('configs', function (Blueprint $table) {
            $table->dropColumn('visible');
        });

        \App\Models\Config::whereName('commissions_min')->first()->delete();
        \App\Models\Config::whereName('payment_commissions_min')->first()->delete();
    }
}
