<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMinAmountCommissions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \App\Models\Config::whereName('commissions_min')->existsOr(function () {
            \App\Models\Config::create([
                'name' => 'commissions_min',
                'value' => 30000,
                'description' => 'Kartaga to`lov uchun min qiymat (tiyinlarda)'
            ]);
        });

        \App\Models\Config::whereName('payment_commissions_min')->existsOr(function () {
            \App\Models\Config::create([
                'name' => 'payment_commissions_min',
                'value' => 5000,
                'description' => 'To`lovlar uchun min qiymat (tiyinlarda)'
            ]);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        \App\Models\Config::whereName('commissions_min')->first()->delete();
        \App\Models\Config::whereName('payment_commissions_min')->first()->delete();
    }
}
