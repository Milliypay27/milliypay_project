<?php

use App\Models\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConfigsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('configs', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('value');
            $table->string('description');
            $table->timestamps();
        });

        $customs = [
            [
                'name' => 'support_phone',
                'value' => '+998556022727',
                'description' => "Qo'llab-quvvatlash markazi raqami"
            ],
            [
                'name' => 'website',
                'value' => 'https://milliypay.uz',
                'description' => "Ilova rasmiy sayti"
            ],
            [
                'name' => 'telegram',
                'value' => 'https://t.me/milliypay_admin',
                'description' => "Telegram"
            ],
            [
                'name' => 'whatsapp',
                'value' => '+998999999999',
                'description' => "WhatsApp"
            ],
            [
                'name' => 'email',
                'value' => 'support@milliypay.uz',
                'description' => "Elektron pochta"
            ],
            [
                'name' => 'aboutus_en',
                'value' => "MilliyPay ilovasi haqida ma'lumot en",
                'description' => "Ilova haqida (lotincha)"
            ],
            [
                'name' => 'aboutus_ru',
                'value' => "MilliyPay ilovasi haqida ma'lumot ru",
                'description' => "Ilova haqida (ruscha)"
            ],
            [
                'name' => 'aboutus_uz',
                'value' => "MilliyPay ilovasi haqida ma'lumot uz",
                'description' => "Ilova haqida (kirilcha)"
            ],
            [
                'name' => 'status',
                'value' => 1,
                'description' => "Ilova ishlayotganligi 1-ON 0-OFF"
            ]
        ];

        foreach ($customs as $custom){
            $config = new Config();
            $config->name =$custom['name'];
            $config->value =$custom['value'];
            $config->description =$custom['description'];
            $config->save();
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('configs');
    }
}
