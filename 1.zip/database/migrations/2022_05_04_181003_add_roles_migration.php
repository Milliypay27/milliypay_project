<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRolesMigration extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        try {
            \Spatie\Permission\Models\Role::query()->where('name', 'Super Admin')->delete();
            \Spatie\Permission\Models\Role::query()->where('name', 'Operator')->delete();

            $superAdmin = \Spatie\Permission\Models\Role::create(['name' => 'Super Admin', 'guard_name' => 'backpack']);
            $operator = \Spatie\Permission\Models\Role::create(['name' => 'Operator', 'guard_name' => 'backpack']);

            $users = \App\Models\AdminUser::all();

            foreach ($users as $user) {
                $user->assignRole($superAdmin);
            }

        } catch (Exception $exception) {
            dd($exception->getMessage());
        }

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $superAdmin = \Spatie\Permission\Models\Role::query()->where('name', 'Super Admin')->first();
        $operator = \Spatie\Permission\Models\Role::query()->where('name', 'Operator')->first();

        $users = \App\Models\AdminUser::all();

        foreach ($users as $user) {
            $user->removeRole($superAdmin);
        }

        \Spatie\Permission\Models\Role::query()->where('name', 'Super Admin')->delete();
        \Spatie\Permission\Models\Role::query()->where('name', 'Operator')->delete();
    }
}
