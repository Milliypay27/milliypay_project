<?php

namespace Modules\Profile\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;
use Modules\Profile\Models\Profile;

/** @mixin Profile  */
class ProfileResource extends JsonResource
{

    public function toArray($request): array
    {
        return [
            'phone' => auth()->user()->phone,
            'full_name' => $this->full_name,
            'birthday' => $this->birthday,
            'citizenship' => $this->citizenship,
            'passport_serial' => $this->passport_serial,
            'date_of_issue' => $this->date_of_issue,
            'photo' => $this->photo ? asset('storage/' . $this->photo) : null
        ];
    }
}
