<?php

namespace Modules\Profile\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProfileRequest extends FormRequest
{
    public function rules(): array
    {
        $rules = [
            'profile.update' => [
                'full_name' => ['nullable', 'min:3'],
                'birthday' => ['nullable', 'date', 'date_format:Y-m-d'],
                'citizenship' => ['nullable'],
                'passport_serial' => ['nullable'],
                'date_of_issue' => ['nullable', 'date', 'date_format:Y-m-d'],
            ],

            'profile.photo' => [
                'photo' => ['nullable', 'mimes:jpeg,jpg,png,gif', 'max:10000']
            ]
        ];

        return $rules[$this->route()->getName()];
    }


    public function authorize(): bool
    {
        return auth()->check();
    }

    public function attributes(): array
    {
        return [
            'full_name' => __('profile.full_name'),
            'birthday' => __('profile.birthday'),
            'citizenship' => __('profile.citizenship'),
            'passport_serial' => __('profile.passport_serial'),
            'date_of_issue' => __('profile.date_of_issue'),
            'photo' => __('profile.photo')
        ];
    }
}
