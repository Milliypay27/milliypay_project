<?php

namespace Modules\Profile\Http\Controllers;

use App\Models\User;
use Illuminate\Routing\Controller;
use Modules\Profile\Http\Requests\ProfileRequest;
use Modules\Profile\Models\Profile;
use Modules\Profile\Transformers\ProfileResource;

class ProfileController extends Controller
{
    public function store(ProfileRequest $request): ProfileResource
    {
        /** @var User $user */
        $user = auth()->user();

        return ProfileResource::make(
            $user->profile()->create($request->validated())
        );
    }

    public function update(ProfileRequest $request): ProfileResource
    {
        /** @var User $user */
        $user = auth()->user();

        return ProfileResource::make(
            $user->profile()->updateOrCreate(
                ['user_id' => $user->id],
                $request->validated()
            )
        );
    }

    public function show(): ProfileResource
    {
        /** @var User $user */
        $user = auth()->user();

        return ProfileResource::make($user->profile ?? new Profile());
    }
}
