<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

use App\Http\Controllers\ChangePhoneController;
use Modules\Profile\Http\Controllers\ProfileController;

Route::middleware(['auth:api', 'unired.localization'])->group(function () {
    Route::post('profile/update', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('profile/photo', [ProfileController::class, 'update'])->name('profile.photo');

    Route::post('profile/store', [ProfileController::class, 'store'])->name('profile.store');
    Route::get('profile/show', [ProfileController::class, 'show']);

    Route::put('profile/change-phone', [ChangePhoneController::class, 'update']);
});
