<?php

namespace Modules\Profile\Models;

use App\Models\User;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;

/**
 * Modules\Profile\Models\Profile
 *
 * @property int $id
 * @property string $full_name
 * @property string $birthday
 * @property string $citizenship
 * @property string $passport_serial
 * @property string $date_of_issue
 * @property int $user_id
 * @property string $photo
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read User $user
 * @method static Builder|Profile newModelQuery()
 * @method static Builder|Profile newQuery()
 * @method static Builder|Profile query()
 * @method static Builder|Profile whereBirthday($value)
 * @method static Builder|Profile whereCitizenship($value)
 * @method static Builder|Profile whereCreatedAt($value)
 * @method static Builder|Profile whereDateOfIssue($value)
 * @method static Builder|Profile whereFullName($value)
 * @method static Builder|Profile whereId($value)
 * @method static Builder|Profile wherePassportSerial($value)
 * @method static Builder|Profile wherePhoto($value)
 * @method static Builder|Profile whereUpdatedAt($value)
 * @method static Builder|Profile whereUserId($value)
 * @mixin Eloquent
 */
class Profile extends Model
{
    use HasFactory, CrudTrait;

    protected $fillable = [
        'full_name', 'birthday',
        'citizenship', 'passport_serial',
        'date_of_issue', 'user_id',
        'photo'
    ];

    protected $casts = [
        'birthday' => 'date:Y-m-d',
        'date_of_issue' => 'date:Y-m-d'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function setPhotoAttribute($value)
    {
        $attribute_name = "photo";
        $disk = "uploads";
        $destination_path = 'profiles';

        $this->uploadFileToDisk($value, $attribute_name, $disk, $destination_path);
    }
}
