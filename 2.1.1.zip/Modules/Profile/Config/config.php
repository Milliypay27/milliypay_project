<?php

return [
    'name' => 'Profile'
];
