<?php

namespace Modules\Otp\Services;

use Exception;
use Http;
use Illuminate\Support\Str;
use Modules\Otp\Models\OtpSms;

class CallOtpService
{
    /**
     * @throws Exception
     */
    public function call($phone): OtpSms
    {
        $phone = preg_replace('/\D/', '', $phone);

        if ($phone != '79809999999') {
            $response = Http::get(config('services.sms_ru.url'), [
                'phone' => $phone,
                'ip' => request()->ip(),
                'api_id' => config('services.sms_ru.api_id')
            ])->json();

            if (!(isset($response['status']) and $response['status'] == 'OK' and isset($response['code']))) {
                throw new Exception('');
            }
        } else {
            $response['code'] = 1234;
        }

        $otp = new OtpSms();
        $otp->phone = $phone;
        $otp->code = (int)$response['code'];
        $otp->message = 'call otp';
        $otp->secret = Str::uuid()->toString();
        $otp->expire_in = now()->addSeconds(3 * OtpService::RETRY_SECONDS);
        $otp->key = Str::uuid();
        $otp->verified_at = null;

        $otp->save();

        return $otp;
    }
}
