<?php


namespace Modules\Otp\Services;


use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Modules\Otp\Models\OtpSms;

class OtpService
{
    const RETRY_SECONDS = 60;

    const SMS_URL = 'https://smsc.ru/sys/send.php';
    const SMS_LOGIN = 'Milliypay';
    const SMS_PSW = 'Hadicha1129';
    const SMS_FMT = 3;


    /**
     * @param $phone
     * @param int|null $time
     * @return Model|OtpSms
     * @throws Exception
     */
    public function sendCodeToPhone($phone, int $time = null): OtpSms
    {
        $data = $this->preSend($phone, $time);

        // if (OtpSms::wherePhone($phone)->whereDate('created_at', today())->count() > 2) {
        //    return $this->send($data);
        // }

        return $this->sendSmsPilot($data);
    }

    /**
     * @throws Exception
     */
    public function fcm($phone, int $time = null): Model|OtpSms
    {
        $data = $this->preSend($phone, $time, true);
        $data['code'] = '000000';

        $otp = OtpSms::create($data);
        $otp->key = Str::uuid();
        $otp->verified_at = now();
        $otp->save();

        return $otp;
    }

    /**
     * @throws Exception
     */
    private function preSend($phone, $time = null, $fcm = false): array
    {
        $time = $time ?? self::RETRY_SECONDS;
        $code = $this->generateCode();

//        $message = "code: $code \n 6oWe2abXP3w";
        $message = "Ваш код: {$code} \n6oWe2abXP3w";
        $secret = Str::uuid()->toString();
        $expire_in = now()->addSeconds(3 * $time);

        $otpSms = OtpSms::wherePhone($phone)->latest()->first();
        if ($otpSms && $otpSms->expire_in->addSeconds(-1 * $time)->gte(now()) && !$fcm) {
            $seconds = $otpSms->expire_in->diffInSeconds(now());
            throw new Exception(__("You can resend again after :seconds seconds", ['seconds' => $seconds]));
        }

        return compact('phone', 'message', 'secret', 'expire_in', 'code');
    }

    /**
     * @param int $length
     * @return int
     */
    private function generateCode($length = 6): int
    {
        $min = pow(10, $length - 1);
        $max = pow(10, $length);

        return rand($min, $max);
    }

    /**
     * @param array $data
     * @return Model|OtpSms
     * @throws Exception
     */
    private function send(array $data): Model|OtpSms
    {
        if (env('APP_ENV') != 'local' || $data['phone'] != '79809999999') {
            $res = \Http::get(self::SMS_URL, [
                'login' => self::SMS_LOGIN,
                'psw' => self::SMS_PSW,
                'fmt' => self::SMS_FMT,
                'phones' => "+{$data['phone']}",
                'mes' => $data['message']
            ]);

            if (!$res->ok() && $res->json('error')) {
                throw new Exception($res->json('error'));
            }
        } else {
            $data['code'] = '123456';
        }

        return OtpSms::create($data);
    }

    private function sendSmsPilot(array $data)
    {
        if (env('APP_ENV') != 'local' || $data['phone'] != '78909999999') {
            $res = \Http::get('https://smspilot.ru/api.php', [
                'format' => 'v',
                'to' => "{$data['phone']}",
                'send' => $data['message'],
                'from' => 'INFORM',
                'apikey' => '4E8PPM6C38ZE4RB984J41U2T647NN20KC7U8I38VH4Z5W6765508S514GUWF1VC7'
            ]);

            if (!$res->ok() && $res->json('error')) {
                throw new Exception($res->json('error'));
            }
        } else {
            $data['code'] = '123456';
        }

        return OtpSms::create($data);
    }

    /**
     * @throws Exception
     */
    public function getOtp($phone, $time = null): Model|OtpSms
    {
        $data = $this->preSend($phone, $time);

        return OtpSms::create($data);
    }
}
