<?php

namespace Modules\Otp\Models;

use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

/**
 * Modules\Otp\Models\OtpSms
 *
 * @property int $id
 * @property string $phone
 * @property string $message
 * @property int $code
 * @property string $secret
 * @property Carbon|string $expire_in
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @method static Builder|OtpSms newModelQuery()
 * @method static Builder|OtpSms newQuery()
 * @method static Builder|OtpSms query()
 * @method static Builder|OtpSms whereCode($value)
 * @method static Builder|OtpSms whereCreatedAt($value)
 * @method static Builder|OtpSms whereExpireIn($value)
 * @method static Builder|OtpSms whereId($value)
 * @method static Builder|OtpSms whereMessage($value)
 * @method static Builder|OtpSms wherePhone($value)
 * @method static Builder|OtpSms whereSecret($value)
 * @method static Builder|OtpSms whereUpdatedAt($value)
 * @mixin Eloquent
 * @property string|null $verified_at
 * @property string|null $key
 * @method static Builder|OtpSms whereKey($value)
 * @method static Builder|OtpSms whereVerifiedAt($value)
 * @property int $is_used
 * @method static Builder|OtpSms whereIsUsed($value)
 */
class OtpSms extends Model
{
    use HasFactory;

    protected $table = 'otp_sms';
    protected $fillable = ['phone', 'message', 'code', 'secret', 'expire_in', 'verified_at', 'key', 'is_used'];
    protected $dates = ['expire_in'];
}
