<?php

namespace Modules\Otp\Http\Controllers;

use App\Models\Config;
use Exception;
use Firebase\Auth\Token\Exception\InvalidToken;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;
use InvalidArgumentException;
use Modules\Otp\Http\Requests\CheckOtpRequest;
use Modules\Otp\Http\Requests\FcmRequest;
use Modules\Otp\Http\Requests\GetOtpRequest;
use Modules\Otp\Http\Requests\ResendRequest;
use Modules\Otp\Models\OtpSms;
use Modules\Otp\Services\CallOtpService;
use Modules\Otp\Services\OtpService;

class OtpController extends Controller
{
    /**
     * @param CheckOtpRequest $request
     * @return JsonResponse
     */
    public function checkOtp(CheckOtpRequest $request): JsonResponse
    {
        $otp = OtpSms::query()
            ->whereSecret($request->secret)
            ->whereCode($request->code)
            ->whereNull('verified_at')->first();

        if (!$otp) {
            return response()->json([
                'code' => 0,
                'message' => __('The code is not entered correctly'),
            ], 404);
        }

        if ($otp && !$otp->expire_in->gte(now())) {
            return response()->json([
                'code' => 0,
                'message' => __('The code was entered at a delayed time'),
            ], 429);
        }

        $otp->key = Str::uuid();
        $otp->verified_at = now();
        $otp->save();

        return response()->json([
            'key' => $otp->key
        ]);
    }

    /**
     * @param GetOtpRequest $request
     * @param OtpService $service
     * @return JsonResponse
     */
    public function getOtp(GetOtpRequest $request, OtpService $service): JsonResponse
    {
        try {
            $phone = preg_replace('/\D/', '', $request->phone);

            if (Str::startsWith($phone, ['998'])) {
                throw new Exception(__('неправильный номер'));
            }

            $otp = $service->sendCodeToPhone($phone);
        } catch (Exception $e) {
            return response()->json([
                'code' => 0,
                'message' => $e->getMessage(),
            ], 429);
        }

        return response()->json([
            'retrySeconds' => OtpService::RETRY_SECONDS,
            'secret' => $otp->secret
        ], 200);
    }

    /**
     * @param ResendRequest $request
     * @param OtpService $service
     * @return JsonResponse
     */
    public function resend(ResendRequest $request, OtpService $service): JsonResponse
    {
        $phone = OtpSms::whereSecret($request->secret)->valueOrFail('phone');

        try {
            $otp = $service->sendCodeToPhone($phone);
        } catch (Exception $e) {
            return response()->json([
                'code' => 0,
                'message' => $e->getMessage(),
            ], 429);
        }

        return response()->json([
            'retrySeconds' => OtpService::RETRY_SECONDS,
            'secret' => $otp->secret
        ], 200);
    }

    /**
     * @throws Exception
     */
    public function fcm(FcmRequest $request, OtpService $service): JsonResponse
    {

        $auth = app('firebase.auth');

        try {
            $verifiedIdToken = $auth->verifyIdToken($request->token);
        } catch (InvalidToken $e) {
            return response()->json([
                'code' => 0,
                'message' => __('Unauthorized - Token is invalide'),
            ], 401);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'code' => 0,
                'message' => __('Unauthorized - Can\'t parse the token'),
            ], 401);
        }

        $uid = $verifiedIdToken->claims()->get('sub');
        $user_firebase = $auth->getUser($uid);

        $phone = preg_replace('/\D/', '', $user_firebase->phoneNumber);
        $otp = $service->fcm($phone);

        return response()->json([
            'key' => $otp->key
        ], 200);
    }

    public function call(GetOtpRequest $request, CallOtpService $service)
    {
        try {
            $phone = preg_replace('/\D/', '', $request->phone);
            $otp = $service->call($phone);
        } catch (Exception $e) {
            return response()->json([
                'code' => 0,
                'message' => $e->getMessage(),
            ], 429);
        }

        return response()->json([
            'retrySeconds' => OtpService::RETRY_SECONDS,
            'secret' => $otp->secret
        ], 200);
    }

    public function steps()
    {
        $services = Config::whereName('otp_service_order')->value('value');

        return response()->json([
            'steps' => explode(',', $services)
        ]);
    }
}
