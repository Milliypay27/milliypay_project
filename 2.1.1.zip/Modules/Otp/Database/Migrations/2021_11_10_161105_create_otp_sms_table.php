<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOtpSmsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('otp_sms', function (Blueprint $table) {
            $table->id();
            $table->string('phone', 12);
            $table->string('message');
            $table->integer('code');
            $table->string('secret');
            $table->dateTime('expire_in');
            $table->timestamp('verified_at')->nullable();
            $table->string('key')->nullable();
            $table->boolean('is_used')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('otp_sms');
    }
}
