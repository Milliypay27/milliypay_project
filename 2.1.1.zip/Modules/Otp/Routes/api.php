<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

use Modules\Otp\Http\Controllers\OtpController;

Route::prefix('otp')->name('otp.')->group(function () {
    Route::post('', [OtpController::class, 'checkOtp'])->name('check-otp');
    Route::patch('', [OtpController::class, 'getOtp'])->name('get-otp');
    Route::post('resend', [OtpController::class, 'resend'])->name('resend');

    Route::post('fcm', [OtpController::class, 'fcm'])->name('fcm');
    Route::post('call', [OtpController::class, 'call'])->name('call');

    Route::get('steps', [OtpController::class, 'steps'])->name('steps');
});
