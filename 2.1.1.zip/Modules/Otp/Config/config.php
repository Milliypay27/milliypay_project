<?php

return [
    'name' => 'Otp'
];
