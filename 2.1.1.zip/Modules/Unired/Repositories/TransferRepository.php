<?php

namespace Modules\Unired\Repositories;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Contracts\Pagination\Paginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Models\Transfer;

class TransferRepository extends BaseRepository
{
    public function __construct($modelClass = Transfer::class)
    {
        parent::__construct($modelClass);
    }

    public function paginatedList($data = [], $with = null): LengthAwarePaginator
    {
        $query = $this->query()
            ->filter($data)
            ->with('user', 'creditCard');
        if (!isset($data['all']))
            $query->whereIn('debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2]);

        return $query->paginate();
    }

    /**
     * @param string|null $ext_id
     * @return Transfer|Builder|Model|object|null
     */
    public function findOneByExtId(?string $ext_id)
    {
        return Transfer::query()->where('ext_id', '=', $ext_id)->first();
    }


    public function findByUserIdForApi(array $data): Paginator
    {
        return Transfer::filter($data)
            ->with([
                'service.serviceFields.values',
                'service.paymentGroup.ignoredFields',
            ])
            ->whereIn('debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2, TransferDebitStatuses::SUCCESS_3])
            ->paginate(20);
    }

    public function getAllModel($data = [])
    {
        return $this->query()
            ->filter($data)
            ->select('transfers.*', 'pg.category_id as payment_category_id')
            ->leftJoin('payment_services as ps', 'ps.id', '=', 'transfers.service_id')
            ->leftJoin('payment_groups as pg', 'ps.payment_group_id', '=', 'pg.id')
            ->whereIn('transfers.debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2, TransferDebitStatuses::SUCCESS_3])
            ->get()->groupBy('payment_category_id');
    }

}
