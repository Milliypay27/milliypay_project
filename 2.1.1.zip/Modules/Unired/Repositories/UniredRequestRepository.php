<?php


namespace Modules\Unired\Repositories;


use Modules\Unired\Models\UniredRequest;

/**
 * CLASS UniredRequestRepository
 * @author Izzat Madaminov
 */
class UniredRequestRepository extends BaseRepository
{
    public function __construct($modelClass = UniredRequest::class)
    {
        parent::__construct($modelClass);
    }

    public function getLastCommissions()
    {
        /** @var UniredRequest $class */
        $class = $this->getModelClass();
        return $class::query()
            ->where('method', 'transfer.check.service')
            ->whereNotNull('response')
            ->orderByDesc('updated_at')
            ->first();
    }

    public function createWithMethodAndResponse(string $method, array $response)
    {
        /** @var UniredRequest $class */
        $class = $this->getModelClass();
        return $class::query()->create([
            'response' => $response,
            'method' => $method
        ]);
    }

    /**
     * @param string $column_name
     * @return mixed
     */
    public function getLastCommission(string $column_name)
    {
        /** @var UniredRequest $class */
        $class = $this->getModelClass();
        $model = $class::query()
            ->where('method', '=', 'transfer.check.service')
            ->whereNotNull('response')
            ->orderByDesc('created_at')
            ->firstOrFail()
            ->response;

        return $model->{$column_name};
    }
}
