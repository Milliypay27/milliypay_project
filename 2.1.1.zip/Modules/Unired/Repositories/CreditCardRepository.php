<?php

namespace Modules\Unired\Repositories;

use Modules\Unired\Constants\CreditCardState;
use Modules\Unired\Models\CreditCard;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class CreditCardRepository extends BaseRepository
{
    public function __construct($modelClass = CreditCard::class)
    {
        parent::__construct($modelClass);
    }

    public function paginatedList($data = [], $with = null): LengthAwarePaginator
    {
        $query = $this->query()->with('user')->filter($data);
        if (!isset($data['all']))
            $query->where('state', CreditCardState::SUCCESS);
        return $query->paginate();
    }

    public function findByExternalIdAndOrderId(?string $ext_id, ?string $order_id)
    {
        return CreditCard::query()->where('ext_id', '=', $ext_id)->where('order_id', '=', $order_id)->first();
    }

    public function findActiveCardsByUserId(int $user_id)
    {
        return CreditCard::query()->where('state', '=', CreditCardState::SUCCESS)->where('user_id', '=', $user_id)->get();
    }

    public function findActiveCardByRefId(string $refId)
    {
        return CreditCard::query()->where('ref_id', '=', $refId)->where('state', '=', CreditCardState::SUCCESS)->orderBy('id', 'desc')->first();
    }

    public function updateAllByRefId(array $data, string $refId)
    {
        return CreditCard::query()->where('ref_id', $refId)->update($data);
    }
}
