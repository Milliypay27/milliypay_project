<?php

namespace Modules\Unired\Repositories;

use Modules\Unired\Models\{News, SocialLink};
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class InformationRepository
{
    /**
     * @return LengthAwarePaginator
     */
    public function getNews(): LengthAwarePaginator
    {
        return News::query()->orderByDesc('id')->paginate(10);
    }

    public function getSocialLinks()
    {
        return SocialLink::query()->orderByDesc('id')->get();
    }

    public function getUnreadNewsCount($newsId): int
    {
        return News::query()->where('id', '>', $newsId)->count();
    }
}
