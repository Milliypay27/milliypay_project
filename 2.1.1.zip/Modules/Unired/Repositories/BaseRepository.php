<?php

namespace Modules\Unired\Repositories;

use Modules\Unired\Interfaces\IBaseRepository;
use Modules\Unired\Models\BaseModel;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\{Builder, Collection, Model};

class BaseRepository implements IBaseRepository
{
    protected ?string $modelClass = null;

    public function __construct($modelClass = null)
    {
        if ($modelClass) $this->modelClass = $modelClass;
    }

    /**
     * @param array $data
     * @param array|string|null $with
     * @return LengthAwarePaginator
     */
    public function paginatedList($data = [], $with = null): LengthAwarePaginator
    {
        $query = $this->query();
        if (method_exists($this->getModelClass(), 'scopeFilter'))
            $query->filter($data);

        if (!is_null($with))
            $query->with($with);

        return $query->paginate();
    }

    /**
     * @return Builder
     */
    protected function query(): Builder
    {
        /** @var BaseModel $class */
        $class = $this->getModelClass();
        $query = $class::query();
        return $query->orderByDesc('id');
    }

    /**
     * @return string
     */
    protected function getModelClass(): string
    {
        if ($this->modelClass) {
            return $this->modelClass;
        }
        dd(get_class($this) . ' modelClass property not implemented');
    }

    /**
     * @param $data
     * @return BaseModel|BaseModel[]|Builder|Builder[]|Collection|Model|null
     */
    public function create($data)
    {
        $class = $this->getModelClass();
        $model = new $class();
        $model->fill($data);
        $model->save();
        return $model;
    }

    /**
     * @param $data
     * @param $id
     * @return BaseModel|BaseModel[]|Builder|Builder[]|Collection|Model|null
     */
    public function update($data, $id)
    {
        $model = $this->findById($id);
        $model->fill($data);
        $model->save();

        return $model;
    }

    /**
     * @param $id
     * @return BaseModel|BaseModel[]|Builder|Builder[]|Collection|Model|null
     */
    public function findById($id)
    {
        /** @var BaseModel $class */
        $class = $this->getModelClass();
        return $class::query()->find($id);
    }

    /**
     * @param $id
     * @return bool|mixed|null
     */
    public function delete($id): bool
    {
        $model = $this->findById($id);
        return $model->delete();
    }
}
