<?php

namespace Modules\Unired\Repositories;

use Modules\Unired\Models\PaymentCategory;
use Illuminate\Database\Eloquent\{Builder, Collection};

class PaymentCategoryRepository extends BaseRepository
{

    public function __construct($modelClass = PaymentCategory::class)
    {
        parent::__construct($modelClass);
    }

    /**
     * @param array $data
     * @return PaymentCategory[]|Builder[]|Collection
     */
    public function getAllModel(array $data = [])
    {
        /*** @var PaymentCategory $class */
        $class = $this->getModelClass();
        return $class::query()
            ->filter($data)
            ->orderBy(PaymentCategory::SORTABLE_FIELD['sortable_column'])
            ->get();
    }
}
