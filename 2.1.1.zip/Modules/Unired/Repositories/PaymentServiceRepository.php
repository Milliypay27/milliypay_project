<?php

namespace Modules\Unired\Repositories;

use Modules\Unired\Models\PaymentCategory;
use Modules\Unired\Models\PaymentService;

class PaymentServiceRepository
{
    public function allPaymentService()
    {
        return PaymentCategory::with('paymentGroups')->orderBy('position')->get();
    }

    public function findPaymentService(int $id)
    {
        return PaymentService::query()->find($id);
    }

    public function getPaymentServices()
    {
        $title = 'title_' . app()->getLocale();
        return PaymentService::get(["$title as name", 'id'])->pluck('name', 'id');
    }
}
