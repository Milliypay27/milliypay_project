<?php

namespace Modules\Unired\Rules;

use Modules\Unired\Models\CreditCard;
use Modules\Unired\Services\CreditCardService;
use Illuminate\Contracts\Validation\Rule;

class CheckCreditCardOwner implements Rule
{
    private CreditCardService $creditCardService;

    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->creditCardService = new CreditCardService();
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param string $attribute
     * @param mixed $value
     * @return bool
     */
    public function passes($attribute, $value): bool
    {
        if ($value != -1) {
            /** @var CreditCard $card */
            $card = $this->creditCardService->getModelById($value);
            if (!$card || $card->user_id != auth()->user()->id)
                return false;
        }
        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message(): string
    {
        return trans('is_card_not_belongs');
    }
}
