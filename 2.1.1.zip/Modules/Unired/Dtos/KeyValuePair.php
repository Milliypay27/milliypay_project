<?php

namespace Modules\Unired\Dtos;

class KeyValuePair
{
    public string $key;
    public $value;

    /**
     * @param string $key
     * @param mixed $value
     */
    public function __construct(string $key, $value)
    {
        $this->key = $key;
        $this->value = $value;
    }

}
