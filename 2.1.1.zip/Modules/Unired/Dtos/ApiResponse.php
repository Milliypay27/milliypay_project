<?php


namespace Modules\Unired\Dtos;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Response;
use Symfony\Component\HttpFoundation\Response as Status;

class ApiResponse
{
    public static function success($data): JsonResponse
    {
        return Response::json([
            "data" => $data,
            "success" => true
        ], Status::HTTP_OK);
    }

    public static function error($message, $isArray = false, $status = Status::HTTP_OK): JsonResponse
    {
        if ($isArray) {
            $message = reset($message)[0];
        }
        return Response::json([
            "status" => false,
            "message" => $message,
            "code" => 1000
        ], $status);
    }
}
