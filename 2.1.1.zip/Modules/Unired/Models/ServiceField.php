<?php

namespace Modules\Unired\Models;

use Arr;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\{Builder,
    Factories\HasFactory,
    Model,
    Relations\HasMany,
    Relations\HasOne,
    SoftDeletes};
use Illuminate\Support\Carbon;


/**
 * App\Models\ServiceField
 *
 * @property int $id
 * @property int $payment_service_id
 * @property string $name
 * @property string $title_oz
 * @property string $title_uz
 * @property string $title_ru
 * @property string $title_en
 * @property string $type
 * @property string $placeholder
 * @property string $pattern
 * @property string $full_pattern
 * @property int $max_length
 * @property int $order
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property Carbon|null $deleted_at
 * @property-read PaymentService|null $paymentService
 * @property-read ServiceFieldPrefix[]|null $prefixes
 * @property-read ServiceFieldValue[]|null $values
 * @method static Builder|ServiceField newModelQuery()
 * @method static Builder|ServiceField newQuery()
 * @method static \Illuminate\Database\Query\Builder|ServiceField onlyTrashed()
 * @method static Builder|ServiceField query()
 * @method static Builder|ServiceField whereCreatedAt($value)
 * @method static Builder|ServiceField whereDeletedAt($value)
 * @method static Builder|ServiceField whereId($value)
 * @method static Builder|ServiceField whereName($value)
 * @method static Builder|ServiceField whereOrder($value)
 * @method static Builder|ServiceField wherePattern($value)
 * @method static Builder|ServiceField wherePaymentServiceId($value)
 * @method static Builder|ServiceField whereTitleEn($value)
 * @method static Builder|ServiceField whereTitleOz($value)
 * @method static Builder|ServiceField whereTitleRu($value)
 * @method static Builder|ServiceField whereTitleUz($value)
 * @method static Builder|ServiceField whereType($value)
 * @method static Builder|ServiceField whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|ServiceField withTrashed()
 * @method static \Illuminate\Database\Query\Builder|ServiceField withoutTrashed()
 * @property int $external_id
 * @property int $with_prefix
 * @property-read int|null $prefixes_count
 * @property-read int|null $values_count
 * @method static Builder|ServiceField whereExternalId($value)
 * @method static Builder|ServiceField whereFullPattern($value)
 * @method static Builder|ServiceField whereMaxLength($value)
 * @method static Builder|ServiceField wherePlaceholder($value)
 * @method static Builder|ServiceField whereWithPrefix($value)
 * @mixin Eloquent
 * @property-read \Modules\Unired\Models\PaymentService|null $payment_service
 */
class ServiceField extends Model
{
    use HasFactory;
    use CrudTrait;
    use SoftDeletes;

    public const SORTABLE_FIELD = [
        'foreign_key' => 'payment_service_id',
        'sortable_column' => 'order'
    ];
    public const INTEGER_TYPE = 1;
    public const STRING_TYPE = 2;
    public const SELECT_TYPE = 3;
    public const PHONE_TYPE = 5;
    protected static string $sortableField = 'order';
    protected $table = 'service_fields';

    protected $fillable = [
        'payment_service_id',
        'name',
        'title_oz',
        'title_uz',
        'title_en',
        'title_ru',
        'type',
        'pattern',
        'order',
        'external_id',
        'with_prefix',
        'placeholder',
        'full_pattern',
        'max_length'
    ];

    protected $casts = [
        'payment_service_id' => 'integer',
        'name' => 'string',
        'title_oz' => 'string',
        'title_uz' => 'string',
        'title_en' => 'string',
        'title_ru' => 'string',
        'type' => 'string',
        'pattern' => 'string',
        'order' => 'integer',
        'with_prefix' => 'integer'
    ];

    protected static function boot()
    {
        parent::boot();
        self::creating(function(self $model){
            $model->title_oz = $model->title_oz ?? $model->title_en;
        });
    }

    public function getType()
    {
        return Arr::get(self::types(), $this->type);
    }

    public static function types(): array
    {
        return [
            self::INTEGER_TYPE => 'Integer',
            self::STRING_TYPE => 'String',
            self::SELECT_TYPE => 'Select',
            self::PHONE_TYPE => 'Phone Number'
        ];
    }

    public function paymentService(): HasOne
    {
        return $this->hasOne(PaymentService::class, 'id', 'payment_service_id');
    }

    public function payment_service(): HasOne
    {
        return $this->hasOne(PaymentService::class, 'id', 'payment_service_id');
    }

    public function prefixes(): HasMany
    {
        return $this->hasMany(ServiceFieldPrefix::class, 'service_field_id', 'id');
    }

    public function isSelect(): bool
    {

        return $this->type == self::SELECT_TYPE;
    }

    public function getValue(int $id)
    {
        return $this->values()->find($id);
    }

    public function values(): HasMany
    {
        return $this->hasMany(ServiceFieldValue::class, 'service_field_id', 'id')->orderBy('order');
    }
}
