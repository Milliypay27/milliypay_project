<?php

namespace Modules\Unired\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Carbon;

/**
 * Modules\Unired\Models\IgnoredField
 *
 * @property int $id
 * @property int|null $payment_group_id
 * @property string $key
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property-read PaymentGroup|null $paymentGroup
 * @method static Builder|IgnoredField newModelQuery()
 * @method static Builder|IgnoredField newQuery()
 * @method static Builder|IgnoredField query()
 * @method static Builder|IgnoredField whereCreatedAt($value)
 * @method static Builder|IgnoredField whereDeletedAt($value)
 * @method static Builder|IgnoredField whereId($value)
 * @method static Builder|IgnoredField whereKey($value)
 * @method static Builder|IgnoredField wherePaymentGroupId($value)
 * @method static Builder|IgnoredField whereUpdatedAt($value)
 * @mixin Eloquent
 */
class IgnoredField extends Model
{
    use HasFactory, CrudTrait;

    protected $fillable = ['key', 'payment_group_id'];

    public function paymentGroup(): HasOne
    {
        return $this->hasOne(PaymentGroup::class, 'id', 'payment_group_id');
    }

    public function title()
    {
        $title = 'title_' . app()->getLocale();
        return $this->{$title};
    }
}
