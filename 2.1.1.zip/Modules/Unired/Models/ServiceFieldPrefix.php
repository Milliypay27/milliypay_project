<?php

namespace Modules\Unired\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\{Builder, Factories\HasFactory, Model, Relations\HasOne, SoftDeletes};
use Illuminate\Support\Carbon;

/**
 * Modules\Unired\Models\ServiceFieldPrefix
 *
 * @property int $id
 * @property int $service_field_id
 * @property string $value
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property string|null $prefix_value
 * @property-read ServiceField|null $ServiceField
 * @method static Builder|ServiceFieldPrefix newModelQuery()
 * @method static Builder|ServiceFieldPrefix newQuery()
 * @method static Builder|ServiceFieldPrefix query()
 * @method static Builder|ServiceFieldPrefix whereCreatedAt($value)
 * @method static Builder|ServiceFieldPrefix whereDeletedAt($value)
 * @method static Builder|ServiceFieldPrefix whereId($value)
 * @method static Builder|ServiceFieldPrefix wherePrefixValue($value)
 * @method static Builder|ServiceFieldPrefix whereServiceFieldId($value)
 * @method static Builder|ServiceFieldPrefix whereUpdatedAt($value)
 * @method static Builder|ServiceFieldPrefix whereValue($value)
 * @mixin Eloquent
 */
class ServiceFieldPrefix extends Model
{
    use HasFactory;
    use CrudTrait;
    use SoftDeletes;

    protected $table = 'service_field_prefixes';

    protected $guarded = [];

    protected $casts = [
        'service_field_id' => 'integer',
        'value' => 'string',
        'prefix_value' => 'string'
    ];

    public function ServiceField(): HasOne
    {
        return $this->hasOne(ServiceField::class, 'id', 'service_field_id');
    }
}
