<?php

namespace Modules\Unired\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\{Builder,
    Collection,
    Factories\HasFactory,
    Model,
    Relations\HasMany,
    Relations\HasOne,
    SoftDeletes};
use Illuminate\Support\Carbon;


/**
 * App\Models\PaymentServiceForUniredPaymentServices
 *
 * @property int $id
 * @property string $ext_service_id
 * @property string $ext_info_id
 * @property string $ext_provider_id
 * @property int $min_amount
 * @property int $max_amount
 * @property string $title_oz
 * @property string $title_uz
 * @property string $title_ru
 * @property string $title_en
 * @property string $title_short_oz
 * @property string $title_short_uz
 * @property string $title_short_ru
 * @property string $title_short_en
 * @property int $order
 * @property int $payment_group_id
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property Carbon|null $deleted_at
 * @property-read PaymentGroup|null $paymentGroup
 * @property-read Collection|ServiceField[] $serviceFields
 * @property-read int|null $service_fields_count
 * @method static Builder|PaymentService newModelQuery()
 * @method static Builder|PaymentService newQuery()
 * @method static \Illuminate\Database\Query\Builder|PaymentService onlyTrashed()
 * @method static Builder|PaymentService query()
 * @method static Builder|PaymentService whereCreatedAt($value)
 * @method static Builder|PaymentService whereDeletedAt($value)
 * @method static Builder|PaymentService whereExtInfoId($value)
 * @method static Builder|PaymentService whereExtProviderId($value)
 * @method static Builder|PaymentService whereExtServiceId($value)
 * @method static Builder|PaymentService whereId($value)
 * @method static Builder|PaymentService whereMaxAmount($value)
 * @method static Builder|PaymentService whereMinAmount($value)
 * @method static Builder|PaymentService whereOrder($value)
 * @method static Builder|PaymentService wherePaymentGroupId($value)
 * @method static Builder|PaymentService whereTitleEn($value)
 * @method static Builder|PaymentService whereTitleOz($value)
 * @method static Builder|PaymentService whereTitleRu($value)
 * @method static Builder|PaymentService whereTitleShortEn($value)
 * @method static Builder|PaymentService whereTitleShortOz($value)
 * @method static Builder|PaymentService whereTitleShortRu($value)
 * @method static Builder|PaymentService whereTitleShortUz($value)
 * @method static Builder|PaymentService whereTitleUz($value)
 * @method static Builder|PaymentService whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|PaymentService withTrashed()
 * @method static \Illuminate\Database\Query\Builder|PaymentService withoutTrashed()
 * @property string|null $amount_field_name
 * @method static Builder|PaymentService whereAmountFieldName($value)
 * @mixin Eloquent
 * @property-read PaymentGroup|null $payment_group
 */
class PaymentService extends Model
{
    use HasFactory;
    use CrudTrait;
    use SoftDeletes;

    public const SORTABLE_FIELD = [
        'foreign_key' => 'payment_group_id',
        'sortable_column' => 'order'
    ];

    protected static $sortableField = 'order';

    protected $table = 'payment_services';
    protected $fillable = [
        'ext_service_id',
        'ext_info_id',
        'ext_provider_id',
        'min_amount',
        'max_amount',
        'title_oz',
        'title_uz',
        'title_en',
        'title_ru',
        'order',
        'payment_group_id',
        'amount_field_name'
    ];

    protected $casts = [
        'ext_service_id' => 'string',
        'ext_info_id' => 'string',
        'ext_provider_id' => 'string',
        'min_amount' => 'double',
        'max_amount' => 'double',
        'title_oz' => 'string',
        'title_uz' => 'string',
        'title_en' => 'string',
        'title_ru' => 'string',
        'order' => 'integer',
        'payment_group_id' => 'integer',
        'amount_field_name' => 'string'
    ];

    protected static function boot()
    {
        parent::boot();
        self::creating(function (self $model) {
            $model->title_oz = $model->title_oz ?? $model->title_en;
            $model->order = $model->order ?? 0;
        });
    }

    public function paymentGroup(): HasOne
    {
        return $this->hasOne(PaymentGroup::class, 'id', 'payment_group_id');
    }

    public function payment_group(): HasOne
    {
        return $this->hasOne(PaymentGroup::class, 'id', 'payment_group_id');
    }

    public function serviceFields(): HasMany
    {
        return $this->hasMany(ServiceField::class, 'payment_service_id', 'id')->orderBy('order');
    }
}
