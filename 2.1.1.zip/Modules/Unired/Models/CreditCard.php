<?php

namespace Modules\Unired\Models;

use App\Models\User;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Carbon;

/**
 * App\Models\CreditCard
 *
 * @property int $id
 * @property int $user_id
 * @property int $order_id
 * @property int $ext_id
 * @property string $description
 * @property string $state
 * @property string|null $name
 * @property string|null $owner
 * @property int|null $ref_id
 * @property string|null $number
 * @property string|null $expire
 * @property string|null $provider
 * @property string|null $bank
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard query()
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereBank($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereExpire($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereExtId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereNumber($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereOrderId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereOwner($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereProvider($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereRefId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereState($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CreditCard whereUserId($value)
 * @mixin \Eloquent
 * @method static Builder|CreditCard filter(array $filters)
 */
class CreditCard extends Model
{
    use HasFactory, CrudTrait;

    protected $table = 'credit_cards';


    protected $fillable = [
        'user_id',
        'order_id',
        'ext_id',
        'description',
        'state',
        'name',
        'owner',
        'ref_id',
        'number',
        'expire',
        'provider',
        'bank'
    ];

    protected $casts = [
        'user_id' => 'integer',
        'order_id' => 'integer',
        'description' => 'string',
        'state' => 'string',
        'name' => 'string',
        'owner' => 'string',
        'ref_id' => 'integer',
        'number' => 'string',
        'expire' => 'string',
        'provider' => 'string',
        'bank' => 'string'
    ];

    public function user(): HasOne
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function scopeFilter(Builder $query, array $filters)
    {
        return $query
            ->when(
                $filters['owner'] ?? null, function (Builder $query, $owner) {
                return $query
                    ->where('owner', 'ilike', '%' . $owner . '%');
            })
            ->when(
                $filters['bank'] ?? null, function (Builder $query, $bank) {
                return $query
                    ->where('bank', 'ilike', '%' . $bank . '%');
            })
            ->when(
                $filters['number'] ?? null, function (Builder $query, $number) {
                return $query
                    ->where('number', 'like', '%' . $number . '%');
            })
            ->when(
                $filters['provider'] ?? null, function (Builder $query, $provider) {
                return $query
                    ->where('provider', 'ilike', '%' . $provider . '%')
                    ->orWhere('description','ilike', "%$provider%");
            });
    }
}
