<?php

namespace Modules\Unired\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Carbon;

/**
 * Modules\Unired\Models\InfoTranslation
 *
 * @property int $id
 * @property string $key
 * @property string $label_uz
 * @property string $label_oz
 * @property string $label_en
 * @property string $label_ru
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property Carbon|null $deleted_at
 * @method static Builder|InfoTranslation filter(array $filters)
 * @method static Builder|InfoTranslation newModelQuery()
 * @method static Builder|InfoTranslation newQuery()
 * @method static \Illuminate\Database\Query\Builder|InfoTranslation onlyTrashed()
 * @method static Builder|InfoTranslation query()
 * @method static Builder|InfoTranslation whereCreatedAt($value)
 * @method static Builder|InfoTranslation whereDeletedAt($value)
 * @method static Builder|InfoTranslation whereId($value)
 * @method static Builder|InfoTranslation whereKey($value)
 * @method static Builder|InfoTranslation whereLabelEn($value)
 * @method static Builder|InfoTranslation whereLabelOz($value)
 * @method static Builder|InfoTranslation whereLabelRu($value)
 * @method static Builder|InfoTranslation whereLabelUz($value)
 * @method static Builder|InfoTranslation whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|InfoTranslation withTrashed()
 * @method static \Illuminate\Database\Query\Builder|InfoTranslation withoutTrashed()
 * @mixin Eloquent
 */
class InfoTranslation extends Model
{
    use SoftDeletes;
    use CrudTrait;

    protected $table = 'info_translations';

    protected $fillable = [
        'key',
        'label_uz',
        'label_oz',
        'label_en',
        'label_ru'
    ];

    protected static function boot()
    {
        parent::boot();
        self::creating(function (self $model) {
            $model->label_oz = $model->label_oz ?? $model->label_en;
        });
    }

    public function scopeFilter(Builder $query, array $filters)
    {
        return $query->when(
            $filters['key'] ?? null, function (Builder $query, $key) {
            return $query->where('key', 'like', '%' . $key . '%');
        })->when(
            $filters['label'] ?? null, function (Builder $query, $label) {
            return $query
                ->where('label_uz', 'like', '%' . $label . '%')
                ->orWhere('label_oz', 'like', '%' . $label . '%')
                ->orWhere('label_en', 'like', '%' . $label . '%')
                ->orWhere('label_ru', 'like', '%' . $label . '%');
        });
    }

}
