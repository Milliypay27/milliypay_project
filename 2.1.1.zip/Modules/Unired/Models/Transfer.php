<?php

namespace Modules\Unired\Models;

use App\Models\OfdResponse;
use App\Models\User;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Carbon;
use Modules\Unired\Casts\Json;
use Modules\Unired\Constants\TransferCreditStatuses;
use Modules\Unired\Constants\TransferDebitStatuses;

/**
 * App\Models\Transfer
 *
 * @property int $id
 * @property int $user_id
 * @property int|null $credit_card_id
 * @property string $ext_id
 * @property int $debit_order_id
 * @property string $debit_form_url
 * @property int $debit_state
 * @property int $debit_commission
 * @property int $debit_amount
 * @property int $debit_currency
 * @property string $credit_id
 * @property string $credit_callback_url
 * @property int $credit_state
 * @property string $credit_description
 * @property int $credit_amount
 * @property int $credit_currency
 * @property int $currency_rate
 * @property mixed $receiver
 * @property mixed $sender
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read CreditCard|null $creditCard
 * @property-read User|null $user
 * @method static Builder|Transfer newModelQuery()
 * @method static Builder|Transfer newQuery()
 * @method static Builder|Transfer query()
 * @method static Builder|Transfer whereCreatedAt($value)
 * @method static Builder|Transfer whereCreditAmount($value)
 * @method static Builder|Transfer whereCreditCallbackUrl($value)
 * @method static Builder|Transfer whereCreditCardId($value)
 * @method static Builder|Transfer whereCreditCurrency($value)
 * @method static Builder|Transfer whereCreditDescription($value)
 * @method static Builder|Transfer whereCreditId($value)
 * @method static Builder|Transfer whereCreditState($value)
 * @method static Builder|Transfer whereCurrencyRate($value)
 * @method static Builder|Transfer whereDebitAmount($value)
 * @method static Builder|Transfer whereDebitCommission($value)
 * @method static Builder|Transfer whereDebitCurrency($value)
 * @method static Builder|Transfer whereDebitFormUrl($value)
 * @method static Builder|Transfer whereDebitOrderId($value)
 * @method static Builder|Transfer whereDebitState($value)
 * @method static Builder|Transfer whereExtId($value)
 * @method static Builder|Transfer whereId($value)
 * @method static Builder|Transfer whereReceiver($value)
 * @method static Builder|Transfer whereSender($value)
 * @method static Builder|Transfer whereUpdatedAt($value)
 * @method static Builder|Transfer whereUserId($value)
 * @mixin Eloquent
 * @property mixed $commissions
 * @property-read UniredRequest|null $infoRequest
 * @property-read PaymentService|null $service
 * @method static Builder|Transfer filter(array $filters)
 * @property string|null $credit_card_number
 * @property float|null $amount
 * @property int|null $service_id
 * @property int|null $provider_id
 * @property int|null $info_request_id
 * @property int|null $transfer_sender_id
 * @method static Builder|Transfer whereAmount($value)
 * @method static Builder|Transfer whereCommissions($value)
 * @method static Builder|Transfer whereCreditCardNumber($value)
 * @method static Builder|Transfer whereInfoRequestId($value)
 * @method static Builder|Transfer whereProviderId($value)
 * @method static Builder|Transfer whereServiceId($value)
 * @method static Builder|Transfer whereTransferSenderId($value)
 * @property-read TransferSender|null $transferSender
 * @property mixed|null $request
 * @method static Builder|Transfer whereRequest($value)
 */
class Transfer extends Model
{
    use CrudTrait;

    protected $table = 'transfers';

    protected $fillable = [
        'user_id',
        'credit_card_id',
        'ext_id',
        'debit_order_id',
        'debit_form_url',
        'debit_state',
        'debit_commission',
        'debit_amount',
        'debit_currency',
        'credit_id',
        'credit_callback_url',
        'credit_state',
        'credit_description',
        'credit_amount',
        'credit_currency',
        'currency_rate',
        'receiver',
        'sender',
        'credit_card_number',
        'amount',
        'service_id',
        'provider_id',
        'info_request_id',
        'commissions',
        'transfer_sender_id',
        'request'
    ];

    protected $casts = [
        'user_id' => 'integer',
        'credit_card_id' => 'integer',
        'ext_id' => 'string',
        'debit_order_id' => 'integer',
        'debit_form_url' => 'string',
        'debit_state' => 'integer',
        'debit_commission' => 'integer',
        'debit_amount' => 'integer',
        'debit_currency' => 'integer',
        'credit_id' => 'string',
        'credit_callback_url' => 'string',
        'credit_state' => 'integer',
        'credit_description' => 'string',
        'credit_amount' => 'integer',
        'credit_currency' => 'integer',
        'currency_rate' => 'integer',
        'info_request_id' => 'integer',
        'amount' => 'double',
        'receiver' => Json::class,
        'sender' => Json::class,
        'commissions' => Json::class,
        'request' => Json::class,
    ];

    public function user(): HasOne
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function creditCard(): HasOne
    {
        return $this->hasOne(CreditCard::class, 'id', 'credit_card_id');
    }

    public function service(): HasOne
    {
        return $this->hasOne(PaymentService::class, 'id', 'service_id');
    }

    public function provider(): BelongsTo
    {
        return $this->belongsTo(PaymentGroup::class, 'provider_id');
    }

    public function infoRequest(): HasOne
    {
        return $this->hasOne(UniredRequest::class, 'id', 'info_request_id');
    }

    public function transferSender(): BelongsTo
    {
        return $this->belongsTo(TransferSender::class, 'transfer_sender_id');
    }

    public function ofd()
    {
        return $this->hasOne(OfdResponse::class, 'transfer_id');
    }

    public function scopeFilter(Builder $query, array $filters)
    {
        $q = $query
            ->when($filters['user_id'] ?? null, function (Builder $query, $user_id) {
                return $query->where('transfers.user_id', '=', $user_id);
            })
            ->when($filters['date'] ?? null, function (Builder $query, $date) {
                $date_from = $date['from'] ?? Carbon::now()->subMonth()->format('Y-m-d');
                $date_to = $date['to'] ?? Carbon::now()->format('Y-m-d');

                $from = $date_from . ' 00:00:00';
                $to = $date_to . ' 23:59:59';

                return $query->whereBetween('transfers.created_at', [$from, $to]);
            })
            ->when($filters['category_id'] ?? null, function (Builder $query, $category_id) {
                return $query
                    ->select('transfers.*')
                    ->join('payment_services as ps', 'ps.id', '=', 'service_id')
                    ->join('payment_groups as pg', 'pg.id', '=', 'ps.payment_group_id')
                    ->where('pg.category_id', $category_id);
            })
            ->when($filters['card_id'] ?? null, function (Builder $query, $card_id) {
                return $query->where('credit_card_id', $card_id);
            })
            ->when($filters['search'] ?? null, function (Builder $query, $search) {
                return $query->whereHas('user', function (Builder $query) use ($search) {
                    return $query->where('phone', 'ilike', "%$search%");
                })
                    ->orWhere('sender->number', 'ilike', "%$search%")
                    ->orWhere('ext_id', 'ilike', "%$search%")
                    ->orWhere('credit_card_number', 'ilike', "%$search%")
                    ->orWhere('credit_description', 'ilike', "%$search%");
            });

        return $q;
    }

    public function scopeSuccess(Builder $query)
    {
        return $query
            ->where(function (Builder $q) {
                $q->whereNotNull('service_id');
                $q->where('debit_state', TransferDebitStatuses::SUCCESS_3);
                $q->Where('credit_state', TransferCreditStatuses::PAYMENT_SUCCESS);
            })
            ->orWhere(function (Builder $q) {
                $q->whereNull('service_id');
                $q->where('debit_state', TransferDebitStatuses::SUCCESS_3);
                $q->where('credit_state', TransferCreditStatuses::TRANSFER_SUCCESS);
            });
    }

    public function scopeError(Builder $query)
    {
        return $query
            ->where(function (Builder $q) {
                $q->whereNotNull('service_id');
                $q->Where('credit_state', '!=', TransferCreditStatuses::PAYMENT_SUCCESS);
            })->orWhere(function (Builder $q) {
                $q->whereNull('service_id');
                $q->where('credit_state', '!=', TransferCreditStatuses::TRANSFER_SUCCESS);
            });
//            ->orWhereNotIn('credit_state', [TransferCreditStatuses::PAYMENT_SUCCESS, TransferCreditStatuses::TRANSFER_SUCCESS])
//            ->orWhereNotIn('debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2, TransferDebitStatuses::SUCCESS_3]);
    }
}
