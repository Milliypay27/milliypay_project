<?php

namespace Modules\Unired\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Carbon;

/**
 * App\Models\PaymentCategory
 *
 * @property int $id
 * @property int $external_id
 * @property string $title_uz
 * @property string $title_oz
 * @property string $title_en
 * @property string $title_ru
 * @property string $icon
 * @property int $position
 * @property bool $visible
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory query()
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereExternalId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory wherePosition($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereTitleEn($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereTitleOz($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereTitleRu($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereTitleUz($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PaymentCategory filter($value)
 * @mixin \Eloquent
 * @property-read mixed $title
 * @property-read \Illuminate\Database\Eloquent\Collection|\Modules\Unired\Models\PaymentGroup[] $paymentGroups
 * @property-read int|null $payment_groups_count
 * @method static Builder|PaymentCategory whereIcon($value)
 * @property-read \Illuminate\Database\Eloquent\Collection|\Modules\Unired\Models\PaymentGroup[] $groups
 * @property-read int|null $groups_count
 */
class PaymentCategory extends Model
{
    use HasFactory;
    use CrudTrait;

    public const SORTABLE_FIELD = [
        'sortable_column' => 'position'
    ];

    protected static string $sortableField = 'position';
    protected $table = 'payment_categories';
    protected $fillable = [
        'title_uz',
        'title_oz',
        'title_en',
        'title_ru',
        'position',
        'icon',
        'visible'
    ];

    protected $casts = [
        'title_uz' => 'string',
        'title_oz' => 'string',
        'title_en' => 'string',
        'title_ru' => 'string',
        'position' => 'integer',
    ];

    protected $appends = ['title'];

    public function getRouteKeyName()
    {
        return 'paymentCategory';
    }

    public function paymentGroups(): HasMany
    {
        return $this->hasMany(PaymentGroup::class, 'category_id', 'id')
            ->with(['paymentServices', 'paymentServices.serviceFields', 'paymentServices.serviceFields.values'])
            ->orderBy('order');
    }

    public function groups(): HasMany
    {
        return $this->hasMany(PaymentGroup::class, 'category_id')->where('visible', true)->orderBy('order');
    }

    public function getTitleAttribute()
    {
        return $this->attributes['title_' . app()->getLocale()];
    }

    public function scopeFilter(Builder $query, array $filters)
    {
        return $query->when(
            $filters['title'] ?? null, function (Builder $query, $title) {
            return $query
                ->where('title_uz', 'like', '%' . $title . '%')
                ->orWhere('title_oz', 'like', '%' . $title . '%')
                ->orWhere('title_en', 'like', '%' . $title . '%')
                ->orWhere('title_ru', 'like', '%' . $title . '%');
        });
    }

    public function setIconAttribute($value)
    {
        $attribute_name = "icon";
        $disk = "uploads";
        $destination_path = 'payment-categories';

        $this->uploadFileToDisk($value, $attribute_name, $disk, $destination_path);
    }

    protected static function boot()
    {
        parent::boot();
        self::creating(function(self $model){
            $model->title_oz = $model->title_oz ?? $model->title_en;
        });
    }
}
