<?php

namespace Modules\Unired\Models;

use App\Models\User;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Carbon;
use Modules\Unired\Casts\Json;

/**
 * Modules\Unired\Models\UniredRequest
 *
 * @property int $id
 * @property string $method
 * @property mixed|null $params
 * @property mixed|null $response
 * @property mixed|null $error
 * @property bool|null $status
 * @property Carbon|null $remote_timestamp
 * @property int|null $user_id
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read User|null $user
 * @method static Builder|UniredRequest newModelQuery()
 * @method static Builder|UniredRequest newQuery()
 * @method static Builder|UniredRequest query()
 * @method static Builder|UniredRequest whereCreatedAt($value)
 * @method static Builder|UniredRequest whereError($value)
 * @method static Builder|UniredRequest whereId($value)
 * @method static Builder|UniredRequest whereMethod($value)
 * @method static Builder|UniredRequest whereParams($value)
 * @method static Builder|UniredRequest whereRemoteTimestamp($value)
 * @method static Builder|UniredRequest whereResponse($value)
 * @method static Builder|UniredRequest whereStatus($value)
 * @method static Builder|UniredRequest whereUpdatedAt($value)
 * @method static Builder|UniredRequest whereUserId($value)
 * @mixin Eloquent
 * @property int|null $admin_id
 * @method static Builder|UniredRequest whereAdminId($value)
 */
class UniredRequest extends Model
{
    use HasFactory, CrudTrait;

    protected $table = 'unired_requests';

    protected $fillable = [
        'method',
        'params',
        'response',
        'error',
        'status',
        'user_id',
        'admin_id',
        'remote_timestamp'
    ];

    protected $casts = [
        'method' => 'string',
        'params' => Json::class,
        'response' => Json::class,
        'error' => Json::class,
        'status' => 'boolean',
        'user_id' => 'integer',
        'admin_id' => 'integer',
        'remote_timestamp' => 'datetime'
    ];

    public function user(): HasOne
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }
}
