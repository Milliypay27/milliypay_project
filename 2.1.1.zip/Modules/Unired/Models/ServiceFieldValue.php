<?php

namespace Modules\Unired\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\{Builder,
    Factories\HasFactory,
    Model,
    Relations\BelongsTo,
    Relations\HasOne,
    SoftDeletes};
use Illuminate\Support\Carbon;


/**
 * App\Models\ServiceFieldValue
 *
 * @property int $id
 * @property int $service_field_id
 * @property string $title_oz
 * @property string $title_uz
 * @property string $title_ru
 * @property string $title_en
 * @property int $order
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property Carbon|null $deleted_at
 * @method static Builder|ServiceFieldValue newModelQuery()
 * @method static Builder|ServiceFieldValue newQuery()
 * @method static \Illuminate\Database\Query\Builder|ServiceFieldValue onlyTrashed()
 * @method static Builder|ServiceFieldValue query()
 * @method static Builder|ServiceFieldValue whereCreatedAt($value)
 * @method static Builder|ServiceFieldValue whereDeletedAt($value)
 * @method static Builder|ServiceFieldValue whereId($value)
 * @method static Builder|ServiceFieldValue whereOrder($value)
 * @method static Builder|ServiceFieldValue whereServiceFieldId($value)
 * @method static Builder|ServiceFieldValue whereTitleEn($value)
 * @method static Builder|ServiceFieldValue whereTitleOz($value)
 * @method static Builder|ServiceFieldValue whereTitleRu($value)
 * @method static Builder|ServiceFieldValue whereTitleUz($value)
 * @method static Builder|ServiceFieldValue whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|ServiceFieldValue withTrashed()
 * @method static \Illuminate\Database\Query\Builder|ServiceFieldValue withoutTrashed()
 * @property string $external_id
 * @property-read ServiceField|null $serviceField
 * @method static Builder|ServiceFieldValue whereExternalId($value)
 * @mixin Eloquent
 */
class ServiceFieldValue extends Model
{
    use HasFactory;
    use CrudTrait;
    use SoftDeletes;

    public const SORTABLE_FIELD = [
        'foreign_key' => 'service_field_id',
        'sortable_column' => 'order'
    ];

    protected static string $sortableField = 'order';
    protected $table = 'service_field_values';

    protected $fillable = [
        'service_field_id',
        'title_oz',
        'title_uz',
        'title_ru',
        'title_en',
        'order',
        'external_id'
    ];

    protected $casts = [
        'service_field_id' => 'integer',
        'title_oz' => 'string',
        'title_uz' => 'string',
        'title_ru' => 'string',
        'title_en' => 'string',
        'order' => 'integer'
    ];

    protected static function boot()
    {
        parent::boot();
        self::creating(function (self $model) {
            $model->title_oz = $model->title_oz ?? $model->title_en;
            $model->order = $model->order ?? 0;
        });
    }

    public function serviceField(): HasOne
    {
        return $this->hasOne(ServiceField::class, 'id', 'service_field_id');
    }

    public function service_field(): BelongsTo
    {
        return $this->belongsTo(ServiceField::class);
    }
}
