<?php

namespace Modules\Unired\Models;

use Eloquent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Carbon;

/**
 * Modules\Unired\Models\TransferSender
 *
 * @property int $id
 * @property string|null $full_name
 * @property Carbon|null $birthday
 * @property string|null $citizenship
 * @property string|null $passport_serial
 * @property Carbon|null $date_of_issue
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read Transfer|null $transfer
 * @method static Builder|TransferSender newModelQuery()
 * @method static Builder|TransferSender newQuery()
 * @method static Builder|TransferSender query()
 * @method static Builder|TransferSender whereBirthday($value)
 * @method static Builder|TransferSender whereCitizenship($value)
 * @method static Builder|TransferSender whereCreatedAt($value)
 * @method static Builder|TransferSender whereDateOfIssue($value)
 * @method static Builder|TransferSender whereFullName($value)
 * @method static Builder|TransferSender whereId($value)
 * @method static Builder|TransferSender wherePassportSerial($value)
 * @method static Builder|TransferSender whereUpdatedAt($value)
 * @mixin Eloquent
 */
class TransferSender extends Model
{
    use HasFactory;

    protected $fillable = [
        'full_name', 'birthday', 'citizenship', 'passport_serial', 'date_of_issue'
    ];

    protected $dates = ['date_of_issue', 'birthday'];

    protected $casts = [
        'birthday' => 'datetime:Y-m-d',
        'date_of_issue' => 'datetime:Y-m-d'
    ];

    public function transfer(): HasOne
    {
        return $this->hasOne(Transfer::class, 'transfer_sender_id');
    }
}
