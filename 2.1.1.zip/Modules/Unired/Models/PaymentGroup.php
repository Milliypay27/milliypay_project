<?php

namespace Modules\Unired\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Eloquent;
use Illuminate\Database\Eloquent\{Builder,
    Factories\HasFactory,
    Model,
    Relations\BelongsTo,
    Relations\HasMany,
    Relations\HasManyThrough,
    Relations\HasOne,
    SoftDeletes};
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;


/**
 * App\Models\PaymentGroup
 *
 * @property int $id
 * @property string $title_oz
 * @property string $title_uz
 * @property string $title_ru
 * @property string $title_en
 * @property int $category_id
 * @property string $image
 * @property int $order
 * @property bool $visible
 * @property-read mixed $title
 * @property-read IgnoredField[]|Collection $ignoredFields
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property Carbon|null $deleted_at
 * @property-read PaymentCategory|null $paymentCategory
 * @property-read \Illuminate\Database\Eloquent\Collection|PaymentService[] $paymentServices
 * @property-read int|null $payment_services_count
 * @property-read \Illuminate\Database\Eloquent\Collection|PaymentService[] $paymentServicesWithServicesFields
 * @property-read int|null $payment_services_with_services_fields_count
 * @method static Builder|PaymentGroup newModelQuery()
 * @method static Builder|PaymentGroup newQuery()
 * @method static \Illuminate\Database\Query\Builder|PaymentGroup onlyTrashed()
 * @method static Builder|PaymentGroup query()
 * @method static Builder|PaymentGroup whereCreatedAt($value)
 * @method static Builder|PaymentGroup whereDeletedAt($value)
 * @method static Builder|PaymentGroup whereId($value)
 * @method static Builder|PaymentGroup whereName($value)
 * @method static Builder|PaymentGroup whereOrder($value)
 * @method static Builder|PaymentGroup whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|PaymentGroup withTrashed()
 * @method static \Illuminate\Database\Query\Builder|PaymentGroup withoutTrashed()
 * @method static Builder|PaymentGroup sorted()
 * @method static Builder|PaymentGroup whereCategoryId($value)
 * @method static Builder|PaymentGroup whereImage($value)
 * @method static Builder|PaymentGroup whereTitleEn($value)
 * @method static Builder|PaymentGroup whereTitleOz($value)
 * @method static Builder|PaymentGroup whereTitleRu($value)
 * @method static Builder|PaymentGroup whereTitleUz($value)
 * @property-read PaymentCategory $category
 * @mixin Eloquent
 * @property-read int|null $ignored_fields_count
 */
class PaymentGroup extends Model
{
    use HasFactory;
    use CrudTrait;
    use SoftDeletes;

    public const SORTABLE_FIELD = [
        'foreign_key' => 'category_id',
        'sortable_column' => 'order'
    ];

    protected $table = 'payment_groups';
    protected $fillable = [
        'order',
        'image',
        'category_id',
        'title_oz',
        'title_uz',
        'title_ru',
        'title_en',
        'visible'
    ];

    protected $casts = [
        'order' => 'integer',
        'category_id' => 'integer',
        'title_oz' => 'string',
        'title_uz' => 'string',
        'title_ru' => 'string',
        'title_en' => 'string',
    ];

    protected $appends = ['title'];

    public function paymentServices(): HasMany
    {
        return $this->hasMany(PaymentService::class, 'payment_group_id', 'id')->orderBy('order');
    }

    public function paymentServicesWithServicesFields(): HasManyThrough
    {
        return $this->hasManyThrough(PaymentService::class, ServiceField::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(PaymentCategory::class);
    }

    public function paymentCategory(): HasOne
    {
        return $this->hasOne(PaymentCategory::class, 'id', 'category_id');
    }

    public function getTitleAttribute()
    {
        return $this->attributes['title_' . app()->getLocale()];
    }

    public function ignoredFields(): HasMany
    {
        return $this->hasMany(IgnoredField::class, 'payment_group_id', 'id');
    }

    public function setImageAttribute($value)
    {
        $attribute_name = "image";
        $disk = "uploads";
        $destination_path = 'payment-providers';

        $this->uploadFileToDisk($value, $attribute_name, $disk, $destination_path);
    }

    protected static function boot()
    {
        parent::boot();
        self::creating(function(self $model){
            $model->title_oz = $model->title_oz ?? $model->title_en;
        });
    }
}
