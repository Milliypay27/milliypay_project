<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PaymentCategoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules = array(
            'admin.payment-categories.index' => [
                'title' => [
                    'nullable',
                    'string',
                    'min:1'
                ]
            ],

            'admin.payment-categories.store' => [
                'title_oz' => [
                    'required',
                    'string',
                    'min:3'
                ],

                'title_uz' => [
                    'required',
                    'string',
                    'min:3'
                ],

                'title_ru' => [
                    'required',
                    'string',
                    'min:3'
                ],

                'title_en' => [
                    'required',
                    'string',
                    'min:3'
                ],
                'icon' => [
                    'required',
                    'image'
                ]
            ],

            'admin.payment-categories.update' => [
                'title_oz' => [
                    'required',
                    'string',
                    'min:3'
                ],

                'title_uz' => [
                    'required',
                    'string',
                    'min:3'
                ],

                'title_ru' => [
                    'required',
                    'string',
                    'min:3'
                ],

                'title_en' => [
                    'required',
                    'string',
                    'min:3'
                ]
            ],
        );

        return $rules[$this->route()->getName()];
    }
}
