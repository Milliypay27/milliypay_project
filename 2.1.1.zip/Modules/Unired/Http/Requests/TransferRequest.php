<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\HigherOrderBuilderProxy;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\HigherOrderCollectionProxy;
use Illuminate\Validation\Rule;
use Modules\Unired\Constants\UniredCurrencyCodes;
use Modules\Unired\Rules\CheckCreditCardOwner;
use Modules\Unired\Services\UniredRequestService;

/**
 * @property int $info_id
 * @property int $amount
 * @property int $currency
 * @property string $card_number,
 * @property $sender
 * @property int $card_id
 */
class TransferRequest extends FormRequest
{
    /**
     * @var array|Collection|HigherOrderBuilderProxy|HigherOrderBuilderProxy[]|Model|HigherOrderCollectionProxy|HigherOrderCollectionProxy[]|mixed|null
     */
    public $card;
    private UniredRequestService $uniredRequestService;

    public function __construct(array $query = [], array $request = [], array $attributes = [], array $cookies = [], array $files = [], array $server = [], $content = null)
    {
        $this->uniredRequestService = new UniredRequestService();
        parent::__construct($query, $request, $attributes, $cookies, $files, $server, $content);
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules = [
            'transfer.check' => [
                "card_number" => [
                    "required",
                    "string",
                    "min:16"
                ]
            ],

            'transfer.create' => [
                'info_id' => [
                    'nullable',
                    'integer',
                    Rule::exists('unired_requests', 'id')->where('status', true),
                    function ($attribute, $value, $fail) {
                        $req = $this->uniredRequestService->getModelById($value);
                        // TODO check to match card_number (params)
                    }
                ],

                "sender" => ['nullable'],
                "sender.full_name" => ["nullable"],
                "sender.birthday" => ["nullable", "date_format:d.m.Y"],
                "sender.citizenship" => ["nullable"],
                "sender.passport_serial" => ["nullable", 'size:9'],
                "sender.date_of_issue" => ["nullable", 'date_format:d.m.Y'],


                "card_number" => [
                    'required',
                    'string',
                    'min:16'
                ],
                "card_id" => [
                    'required',
                    'integer',
                    new CheckCreditCardOwner()
                ],
                "amount" => [
                    'required',
                    'numeric'
                ]
            ],

            'transfer.get.receiver.owner' => [
                "card_number" => [
                    "required",
                    "string",
                    "min:16"
                ]
            ],

            'transfer.form-url' => [
                'info_id' => [
                    'nullable',
                    'integer',
                    Rule::exists('unired_requests', 'id')->where('status', true),
                    function ($attribute, $value, $fail) {
                        $req = $this->uniredRequestService->getModelById($value);
                        // TODO check to match card_number (params)
                    }
                ],

                "card_number" => [
                    'required',
                    'string',
                    'min:16'
                ],

                'currency' => ['nullable', Rule::in([UniredCurrencyCodes::RUB, UniredCurrencyCodes::UZS])],

                "amount" => [
                    'required',
                    'numeric'
                ]
            ],

            'transfer.myFilter' => [
                'from' => [
                    'required',
                ],
                "to" => [

                ],
                "category_id" => [
                    'nullable',
                    'numeric'
                ]
            ],
            'transfer.my-transfers' => [
                'from' => [
                    'nullable',
                    'date'
                ],
                "to" => [
                    'nullable',
                    'date',
//                    'required_with:from'
                ],
                "category_id" => [
                    'nullable',
                    'numeric'
                ],
                "card_id" => [
                    'nullable',
                    'numeric'
                ],
                'search' => [
                    'nullable',
                    'string'
                ]
            ]
        ];

        return $rules[$this->route()->getName()];
    }
}
