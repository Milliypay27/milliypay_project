<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PaymentGroupRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'title_oz' => [
                'required',
                Rule::unique('payment_groups', 'title_oz')
                    ->ignore($this->route('payment_group'))
                    ->withoutTrashed()
            ],
            'title_uz' => [
                'required',
                Rule::unique('payment_groups', 'title_uz')
                    ->ignore($this->route('payment_group'))
                    ->withoutTrashed()
            ],
            'title_ru' => [
                'required',
                Rule::unique('payment_groups', 'title_ru')
                    ->ignore($this->route('payment_group'))
                    ->withoutTrashed()
            ],
            'title_en' => [
                'required',
                Rule::unique('payment_groups', 'title_en')
                    ->ignore($this->route('payment_group'))
                    ->withoutTrashed()
            ],

            'category_id' => [
                'required',
                'integer'
            ],

            'image' => [
                Rule::requiredIf(!$this->route('payment_group')),
                'image'
            ]

        ];
    }
}
