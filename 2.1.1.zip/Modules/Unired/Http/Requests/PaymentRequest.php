<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Unired\Rules\CheckCreditCardOwner;
use Modules\Unired\Services\UniredRequestService;

/**
 * @property mixed $service_id
 */
class PaymentRequest extends FormRequest
{
    private UniredRequestService $uniredRequestService;

    public function __construct(array $query = [], array $request = [], array $attributes = [], array $cookies = [], array $files = [], array $server = [], $content = null)
    {
        $this->uniredRequestService = new UniredRequestService();
        parent::__construct($query, $request, $attributes, $cookies, $files, $server, $content);
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules = [
            'payment.info' => [
                'service_id' => [
                    'required',
                    'integer',
                    Rule::exists('payment_services', 'id'),
                    Rule::exists('service_fields', 'payment_service_id')
                ],

                'fields' => [
                    'required',
                    'array'
                ],

                'fields.*' => [
                    'field_id' => [
                        'required',
                        'integer'
                    ],

                    'value' => [
                        'required',
                        'string'
                    ]
                ]
            ],

            'payment.create' => [
                'info_id' => [
                    'required',
                    'integer',
                    Rule::exists('unired_requests', 'id')->where('status', true),
                    function ($attribute, $value, $fail) {
                        $req = $this->uniredRequestService->getModelById($value);
                        // TODO check to match service id, provider id and fields
                    }
                ],
                'card_id' => [
                    'nullable',
                    'integer',
                    new CheckCreditCardOwner()
                ],
                'service_id' => [
                    'required',
                    'integer',
                    Rule::exists('payment_services', 'id')->withoutTrashed(),
                    Rule::exists('service_fields', 'payment_service_id')->withoutTrashed()
                ],

                'fields' => [
                    'required',
                    'array'
                ],

                'fields.*.field_id' => [
                    'required',
                    'integer',
                    Rule::exists('service_fields', 'id')->withoutTrashed(),
                ],

                'fields.*.value' => [
                    'required',
                    'string'
                ],

                'amount' => [
                    'required',
                    'numeric'
                ]
            ]

        ];

        return $rules[$this->route()->getName()];
    }
}
