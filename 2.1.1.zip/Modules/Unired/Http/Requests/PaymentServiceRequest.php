<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PaymentServiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'title_oz' => [
                'required',
            ],
            'title_uz' => [
                'required',
            ],
            'title_ru' => [
                'required',
            ],
            'title_en' => [
                'required',
            ],

            'amount_field_name' => [
              'string'
            ],

            'payment_group_id' => [
                Rule::requiredIf(!$this->route('payment_service')),
                'integer'
            ],

            'min_amount' => [
                Rule::requiredIf(!$this->route('payment_service')),
                'numeric'
            ],

            'max_amount' => [
                Rule::requiredIf(!$this->route('payment_service')),
                'numeric'
            ],

            'ext_service_id' => [
                Rule::requiredIf(!$this->route('payment_service')),
                'string'
            ],

            'ext_info_id' => [
                Rule::requiredIf(!$this->route('payment_service')),
                'string'
            ],

            'ext_provider_id' => [
                Rule::requiredIf(!$this->route('payment_service')),
                'string'
            ],

        ];
    }

//    public function attributes(): array
//    {
//        $address = new Admin();
//
//        return $address->getAttributeLabelValuesFromObj();
//    }
}
