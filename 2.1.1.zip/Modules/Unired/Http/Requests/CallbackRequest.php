<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CallbackRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules = [
            'card.callback' => [
                'status' => [
                    'required',
                    'boolean'
                ],
                'origin' => [
                    'required',
                    'string'
                ],
                'result' => [
                    'required',
                    'array'
                ]
            ],
            'transfer.callback' => [
                'status' => [
                    'nullable',
                    'boolean'
                ],
                'origin' => [
                    'nullable',
                    'string'
                ],
                'method' => [
                    'nullable',
                    'string'
                ],
                'result' => [
                    'required',
                    'array'
                ]
            ],
            'transfer.mts.callback' => [
                'status' => [
                    'nullable',
                    'boolean'
                ],
                'origin' => [
                    'nullable',
                    'string'
                ],
                'method' => [
                    'nullable',
                    'string'
                ],
                'result' => [
                    'required',
                    'array'
                ]
            ],

            'payment.mts.callback' => [
                'status' => [
                    'nullable',
                    'boolean'
                ],
                'origin' => [
                    'nullable',
                    'string'
                ],
                'method' => [
                    'nullable',
                    'string'
                ],
                'result' => [
                    'required',
                    'array'
                ]
            ],

            'payment.callback' => [
                'status' => [
                    'required',
                    'boolean'
                ],
                'origin' => [
                    'required',
                    'string'
                ],
                'result' => [
                    'required',
                    'array'
                ]
            ],
        ];

        return $rules[$this->route()->getName()];
    }
}
