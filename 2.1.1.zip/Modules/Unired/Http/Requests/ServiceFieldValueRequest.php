<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ServiceFieldValueRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'service_field_id' => [
                'required',
                'integer'
            ],
            'title_oz' => [
                'required',
                Rule::unique('service_field_values', 'title_oz')
                    ->ignore($this->route('service_field_value'))
                    ->withoutTrashed()
            ],

            'title_uz' => [
                'required',
                Rule::unique('service_field_values', 'title_uz')
                    ->ignore($this->route('service_field_value'))
                    ->withoutTrashed()
            ],

            'title_ru' => [
                'required',
                Rule::unique('service_field_values', 'title_ru')
                    ->ignore($this->route('service_field_value'))
                    ->withoutTrashed()
            ],

            'title_en' => [
                'required',
                Rule::unique('service_field_values', 'title_en')
                    ->ignore($this->route('service_field_value'))
                    ->withoutTrashed()
            ],

            'external_id' => [
                Rule::requiredIf(!$this->route('service_field_value')),
                'string'
            ],
        ];
    }

//    public function attributes(): array
//    {
//        $address = new Admin();
//
//        return $address->getAttributeLabelValuesFromObj();
//    }
}
