<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UniredServiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return backpack_auth()->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        $rules = array(
            'admin.unired-services.index' => [
                'payment_service' => [
                    'nullable',
                    'string'
                ],

                'service' => [
                    'nullable',
                    'string'
                ]
            ],
            'admin.unired-services.create' => [
                'id' => [
                    'required',
                    'integer'
                ],
                'service' => [
                    'required',
                    'string'
                ]
            ],

            'admin.unired-services.store' => [
                'category_id' => [
                    'required',
                    'string'
                ],
                'payment_group' => [
                    'string',
                    'nullable'
                ],
                'ext_provider_id' => [
                    'required',
                    'string'
                ],

                'ext_info_id' => [
                    'required',
                    'string'
                ],
                'ext_service_id' => [
                    'required',
                    'string'
                ],
                'title' => [
                    'required',
                    'string'
                ],
                'title_short' => [
                    'required',
                    'string'
                ],
                'amount_field_name' => [
                    'string'
                ],
                'min_amount' => [
                    'required',
                    'string'
                ],
                'max_amount' => [
                    'required',
                    'string'
                ],
                'image' => [
                    'nullable',
                    'image'
                ]
            ]
        );

        return $rules[$this->route()->getName()];
    }
}
