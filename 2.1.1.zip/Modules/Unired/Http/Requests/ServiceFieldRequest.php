<?php

namespace Modules\Unired\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ServiceFieldRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'title_oz' => [
                'required',
                /*Rule::unique('service_fields', 'title_oz')
                    ->ignore($this->route('service_field'))
                    ->withoutTrashed()*/
            ],

            'title_uz' => [
                'required',
                /*Rule::unique('service_fields', 'title_uz')
                    ->ignore($this->route('service_field'))
                    ->withoutTrashed()*/
            ],

            'title_ru' => [
                'required',
                /*Rule::unique('service_fields', 'title_ru')
                    ->ignore($this->route('service_field'))
                    ->withoutTrashed()*/
            ],

            'title_en' => [
                'required',
                /*Rule::unique('service_fields', 'title_en')
                    ->ignore($this->route('service_field'))
                    ->withoutTrashed()*/
            ],

            'name' => [
                Rule::requiredIf(!$this->route('service_field')),
                /*Rule::unique('service_fields', 'name')
                    ->ignore($this->route('service_field'))
                    ->withoutTrashed()*/
            ],

            'external_id' => [
                Rule::requiredIf(!$this->route('service_field')),
                'integer'
            ],

            'payment_service_id' => [
                Rule::requiredIf(!$this->route('service_fields')),
                'integer'
            ],

            'placeholder' => [
                'string',
                'nullable'
            ],

            'max_length' => [
                'string',
                'nullable'
            ],

            'pattern' => [
                'string',
                'nullable'
            ],

            'full_pattern' => [
                'string',
                'nullable'
            ],

            'with_prefix' => [
                'integer'
            ],

            'type' => [
                Rule::requiredIf(!$this->route('service_field')),
                'integer'
            ],


        ];
    }

//    public function attributes(): array
//    {
//        $address = new Admin();
//
//        return $address->getAttributeLabelValuesFromObj();
//    }
}
