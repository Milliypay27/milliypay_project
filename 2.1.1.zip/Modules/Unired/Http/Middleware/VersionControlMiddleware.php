<?php

namespace Modules\Unired\Http\Middleware;

use App\Models\Config;
use Closure;
use Illuminate\Http\Request;

class VersionControlMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if ($request->is('api/*')) {
            $defaultVersion = Config::whereName('version')->value('value') ?? 6;

            $version = $request->header('version', 0);
            if ($version < $defaultVersion) {
                abort(426, __('Upgrade Required'));
            }
        }

        return $next($request);
    }
}
