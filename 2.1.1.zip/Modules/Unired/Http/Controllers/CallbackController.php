<?php


namespace Modules\Unired\Http\Controllers;


use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\JsonResponse as ReturnResponse;
use Log;
use Modules\Unired\Constants\AppConstant;
use Modules\Unired\Dtos\ApiResponse;
use Modules\Unired\Http\Requests\CallbackRequest;
use Modules\Unired\Models\UniredRequest;
use Modules\Unired\Repositories\CreditCardRepository;
use Modules\Unired\Services\CreditCardService;
use Modules\Unired\Services\OfdService;
use Modules\Unired\Services\TransferService;
use Modules\Unired\Services\UniredRequestService;
use Modules\Unired\Services\UniredService;

class CallbackController extends Controller
{
    protected CreditCardRepository $creditCardRepository;
    protected TransferService $transferService;
    protected CreditCardService $creditCardService;
    protected UniredRequestService $uniredRequestService;
    protected UniredService $uniredService;

    public function __construct()
    {
        $this->creditCardRepository = new CreditCardRepository();
        $this->transferService = new TransferService();
        $this->creditCardService = new CreditCardService();
        $this->uniredRequestService = new UniredRequestService();
        $this->uniredService = new UniredService();
    }

    public function cardCallback(CallbackRequest $request)
    {
        $input = $request->all();
        $uniredRequest = $this->uniredRequestService->createModelWithMethodAndResponse(AppConstant::UNIRED_CALLBACK_CARD, $input);
        $creditCard = $this->creditCardRepository->findByExternalIdAndOrderId($input['result']['ext_id'], $input['result']['order_id']);

        if ($creditCard) {
            $this->creditCardService->bindCardCallbackAttributes($creditCard, $input);
            $uniredRequest->update(['params' => "OK"]);

            return ApiResponse::success($uniredRequest->params);
        }

        $uniredRequest->update(['params' => "CARD NOT FOUND"]);
        return ApiResponse::error($uniredRequest->params);
    }

    public function transferCallback(CallbackRequest $request): ReturnResponse
    {
        $input = $request->all();

        try {
            Log::error('callback transfer: ' . json_encode($input));
        } catch (Exception $exception) {
            Log::error('callback transfer error: ' . json_encode($input));
        }

        $uniredRequest = UniredRequest::query()->create([
            'response' => $input,
            'method' => AppConstant::UNIRED_CALLBACK_TRANSFER
        ]);
        return $this->processTransfer($input, $uniredRequest);
    }

    public function transferMtsCallback(CallbackRequest $request): ReturnResponse
    {
        $input = $request->all();

//        try {
//            Log::error('callback mts transfer: ' . json_encode($input));
//        } catch (Exception $exception) {
//            Log::error('callback mts transfer error: ' . json_encode($input));
//        }

        $uniredRequest = UniredRequest::query()->create([
            'response' => $input,
            'method' => AppConstant::UNIRED_CALLBACK_TRANSFER
        ]);
        return $this->processTransfer($input, $uniredRequest);
    }

    public function paymentMtsCallback(CallbackRequest $request, OfdService $ofdService)
    {
        $input = $request->all();

        $uniredRequest = UniredRequest::query()->create([
            'response' => $input,
            'params' => "OK",
            'method' => AppConstant::UNIRED_DEBIT_FINISH
        ]);

        $transfer = $this->transferService->getTransferByExternalId($input['result']['payment']['ext_id']);

        $data = [
            "ext_id" => $input['result']['payment']['ext_id'],
            'debit_state' => $debit_state = $input['result']['payment']['debit']['state'],
            "credit_description" => $input['result']['payment']['credit']['description'],
            'credit_state' => $credit_state = $input['result']['payment']['credit']['state'],
        ];

        try {
            $ofdService->sendPayment($transfer, $debit_state, $credit_state);
        } catch (Exception $exception) {
            Log::error('ofd payment send error: ' . $exception->getMessage());
        }

        if (!$transfer->update($data)) {
            Log::error('update callback transfer');
        }

        return [];
    }

    private function processTransfer($input, $uniredRequest): ReturnResponse
    {
        try {
            $transfer = $this->transferService->getTransferByExternalId($input['result']['transfer']['ext_id']);
            if ($transfer) {
                $uniredRequest->update([
                    'params' => "OK"
                ]);

                $state = $input['result']['transfer']['debit']['state'] ?? false;
                $debitFinish = false;
                if ($input['method'] == AppConstant::UNIRED_DEBIT_FINISH) {
                    $debitFinish = true;
                    $uniredRequest->update([
                        'method' => AppConstant::UNIRED_DEBIT_FINISH
                    ]);
                }

                $this->transferService->updateUniredCallbackAttributes($uniredRequest->response->result, $transfer, $debitFinish);
                return ApiResponse::success($uniredRequest->params);
            } else {
                $uniredRequest->update([
                    'params' => "Transfer not found"
                ]);
                return ApiResponse::error($uniredRequest->params);
            }
        } catch (Exception $exception) {
            Log::error('callback error: ' . $exception->getMessage());
            return \Response::json([
                "data" => [],
                "success" => false
            ], 200);
        }

    }

    public function paymentCallback(CallbackRequest $request): ReturnResponse
    {
        $input = $request->all();

        $uniredRequest = UniredRequest::query()->create([
            'response' => $input,
            'method' => AppConstant::UNIRED_CALLBACK_PAYMENT
        ]);
        return $this->processTransfer($input, $uniredRequest);
    }

    public function rateCallback(): ReturnResponse
    {
        $commission = $this->uniredService->syncCommissions();

        return ApiResponse::success([]);
    }
}
