<?php

namespace Modules\Unired\Http\Controllers;

use App\Models\Config;
use App\Models\User;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Routing\Controller;
use Illuminate\Support\Carbon;
use Modules\Unired\Constants\TransferCreditStatuses;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Constants\TransferDTOStatuses;
use Modules\Unired\Dtos\ApiResponse;
use Modules\Unired\Http\Requests\TransferRequest;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Services\TransferService;
use Modules\Unired\Services\UniredMtsService;
use Modules\Unired\Services\UniredService;
use Illuminate\Http\JsonResponse as ReturnResponse;
use Modules\Unired\Transformers\TransferHistoryResource;
use Modules\Unired\Transformers\TransferResponse;

class TransferController extends Controller
{
    protected UniredService $uniredService;
    protected TransferService $transferService;

    public function __construct()
    {
        $this->uniredService = new UniredService();
        $this->transferService = new TransferService();
    }

    public function requestCreditCardInfo(TransferRequest $request): ReturnResponse
    {
        $user = User::query()->find(auth()->id());
        $result = $this->uniredService->checkReceipt($request, $user);
        if ($result) {
            return ApiResponse::success($result);
        }
        return ApiResponse::error(trans('invalid_card_number'));
    }

    public function createTransfer(TransferRequest $request): ReturnResponse
    {
        /** @var User $user */
        $user = User::with('creditCards')->find(auth()->id());

        $request->card = $user->creditCards()->find($request->post('card_id'));

        $result = $this->uniredService->createTransfer($request, $user);

        if (is_string($result)) return ApiResponse::error($result);

        return ApiResponse::success($result->transfer->debit->form_url);
    }

    //mts
    public function checkReceiverOwner(TransferRequest $request, UniredMtsService $mtsService)
    {
        $user = User::query()->find(auth()->id());
        $result = $mtsService->checkReceipt($request, $user);
        if ($result['status']) {
            return ApiResponse::success($result);
        }

        return ApiResponse::error(trans($result['message'] ?? 'invalid_card_number'));
    }

    /**
     * @throws \Exception
     */
    public function formUrl(TransferRequest $request, UniredMtsService $mtsService)
    {
        $user_id = auth()->id();

        /** @var User $user */
        $user = User::with('creditCards')->find($user_id);

        $request->card = $user->creditCards()->find($request->post('card_id'));

        $transferService = new UniredMtsService();
        $lastTransferUser = Transfer::latest('id')->whereUserId($user_id)->first();

        $serviceConfig = Config::whereName('cash_registers')->first() ?? "mts";
        $serviceConfigArr = explode(',', $serviceConfig);

        if ($lastTransferUser && $lastTransferUser->cash_type == 'mts' && in_array('tkb', $serviceConfigArr)) {
            $transferService = new UniredService();
        }

        try {
            $result = $transferService->createTransfer($request, $user);
        } catch (\Exception $exception) {
            $result = $mtsService->createTransfer($request, $user);
            \Log::error("form url service error: {$exception->getMessage()}");
        }

        if (is_string($result)) return ApiResponse::error($result);

        return ApiResponse::success($result->transfer->debit->form_url);
    }

    public function my(): AnonymousResourceCollection
    {
        $transfers = $this->transferService->getTransfersHistoryForApi();
        return TransferResponse::collection($transfers)->additional(['success' => true]);
    }

    public function myTransfersFilter(TransferRequest $request): AnonymousResourceCollection
    {
        $transfers = $this->transferService->getTransfersHistoryForApi($request->validated());
        return TransferResponse::collection($transfers)->additional(['success' => true]);
    }

    public function myTransfersHistory(TransferRequest $request): array
    {
        $transfers = $this->transferService->getTransferFilterQuery($request);

//        \Log::error(TransferResponse::collection(
//            $transfers
//                ->offset($request->query('offset', 0))
//                ->limit($request->query('limit', 20))
//                ->latest()
//                ->get()
//        )->toJson());

        return [
            'items' => TransferResponse::collection(
                $transfers
                    ->offset($request->query('offset', 0))
                    ->limit($request->query('limit', 20))
                    ->latest()
                    ->get()
            ),
            'metaData' => [
                'limit' => (int) $request->query('limit', 20),
                'offset' => (int) $request->query('offset', 0),
                'totalItems' => $transfers->count()
            ]
        ];
    }

    public function status(UniredService $uniredService, TransferService $transferService)
    {
        $transfer = Transfer::whereDebitFormUrl(request('url'))->firstOrFail();

        $params = [
            'ext_id' => $transfer->ext_id
        ];

        $response = $transfer->service_id ?
            $uniredService->paymentState($params) :
            $uniredService->transferState($params);

        if ($response->status) {
            $transferService->updateUniredCallbackAttributes($response->response, $transfer);
        }

        return response()->json(['status' => TransferDTOStatuses::status($transfer)]);
    }
}
