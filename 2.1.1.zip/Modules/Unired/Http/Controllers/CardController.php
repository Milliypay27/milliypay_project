<?php

namespace Modules\Unired\Http\Controllers;

use Modules\Unired\Dtos\ApiResponse;
use App\Http\Controllers\Controller;
use Modules\Unired\Http\Requests\RemoveCardRequest;


use Modules\Unired\Models\CreditCard;
use Modules\Unired\Repositories\CreditCardRepository;
use Modules\Unired\Services\CreditCardService;
use Modules\Unired\Services\UniredService;
use Illuminate\Http\JsonResponse as ReturnResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Modules\Unired\Transformers\CardResource;

class CardController extends Controller
{
    protected UniredService $uniredService;
    protected CreditCardService $creditCardService;
    private CreditCardRepository $creditCardRepository;

    public function __construct()
    {
        $this->uniredService = new UniredService();
        $this->creditCardService = new CreditCardService();
        $this->creditCardRepository = new CreditCardRepository();
    }

    public function requestCard(): ReturnResponse
    {
        $link = $this->uniredService->creditCardRequestLink(auth()->user());
        return ApiResponse::success((string)$link);
    }

    public function state($ext_id)
    {
        $input = $this->uniredService->creditCardState($ext_id, auth()->user());
        $creditCard = $this->creditCardRepository->findByExternalIdAndOrderId($input['result']['ext_id'] ?? null, $input['result']['order_id'] ?? null);

        if ($creditCard) {
            $this->creditCardService->bindCardCallbackAttributes($creditCard, $input);

            return ApiResponse::success([]);
        }

        return ApiResponse::error('card not found');
    }

    public function getMyCards(): AnonymousResourceCollection
    {
        return CardResource::collection($this->creditCardService->getActiveCardsByUserId(auth()->id()))->additional(['success' => true]);
    }

    public function removeCard(RemoveCardRequest $request): ReturnResponse
    {
        /** @var CreditCard $creditCard */
        $creditCard = $this->creditCardService->getModelById($request->id);

        if ($creditCard->ref_id) {
            $uniredStatus = $this->uniredService->removeCard($creditCard->ref_id, auth()->user());
            if (!$uniredStatus) {
                return ApiResponse::error(trans('cannot_remove_card'));
            }
        }
        $creditCard->delete();
        return ApiResponse::success(true);
    }
}
