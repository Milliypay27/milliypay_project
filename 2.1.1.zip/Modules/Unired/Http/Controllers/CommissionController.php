<?php


namespace Modules\Unired\Http\Controllers;


use App\Http\Controllers\Controller;
use Modules\Unired\Constants\AppConstant;
use Modules\Unired\Services\UniredMtsService;
use Modules\Unired\Services\UniredService;
use Modules\Unired\Transformers\CommissionCollection;
use Modules\Unired\Transformers\CommissionMtsCollection;
use Modules\Unired\Transformers\PaymentCommissionMtsCollection;


class CommissionController extends Controller
{
    protected UniredService $uniredService;

    public function __construct()
    {
        $this->uniredService = new UniredService();
    }

    public function getCommissions(): CommissionCollection
    {
//        $data = (array)$this->uniredService->getLastCommissions()->response;
//        unset($data['service']);
//        return ApiResponse::success($data);
        return new CommissionCollection((array)$this->uniredService->getLastCommissions()->response);
    }

    // mts
    public function get(UniredMtsService $mtsService)
    {
        cache()->delete(AppConstant::UNIRED_MTS_COMMISSION_CACHE_NAME);
        return new CommissionMtsCollection((array) $mtsService->getCommission());
    }

    public function payment(UniredMtsService $mtsService)
    {
        cache()->delete(AppConstant::UNIRED_MTS_PAYMENT_COMMISSION_CACHE_NAME);

        return new PaymentCommissionMtsCollection((array) $mtsService->getPaymentCommission());
    }
}

