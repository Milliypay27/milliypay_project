<?php


namespace Modules\Unired\Http\Controllers;


use Modules\Unired\Services\UniredService;

class UniredServiceController
{
    public function refresh()
    {
        resolve(UniredService::class)->getAllPaymentService(auth('admin')->user());

        return  response()->json(['success' => 'Successfully refreshed unired payment service!']);
    }
}
