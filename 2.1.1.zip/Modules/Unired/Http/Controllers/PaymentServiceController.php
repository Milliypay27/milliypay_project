<?php

namespace Modules\Unired\Http\Controllers;

use Modules\Unired\Constants\UniredCurrencyCodes;
use Modules\Unired\Dtos\ApiResponse;
use App\Http\Controllers\Controller;

use Modules\Unired\Http\Requests\PaymentRequest;
use Modules\Unired\Models\PaymentCategory;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Models\ServiceField;
use Modules\Unired\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Modules\Unired\Services\UniredMtsService;
use Modules\Unired\Transformers\PaymentCategoryResource;
use Modules\Unired\Transformers\PaymentGroupResource;
use Modules\Unired\Transformers\PaymentInfoCollection;
use Modules\Unired\Transformers\PaymentServiceCollection;
use Modules\Unired\Transformers\PaymentServicesResource;

class PaymentServiceController extends Controller
{
    protected PaymentService $paymentService;

    public function __construct()
    {
        $this->paymentService = new PaymentService();
    }

    public function getPaymentService(): PaymentServiceCollection
    {
        return new PaymentServiceCollection($this->paymentService->getAllPaymentService());
    }

    public function getCategories()
    {
        $categories = PaymentCategory::orderBy(PaymentCategory::SORTABLE_FIELD['sortable_column'])->where('visible', true)->get();

        if (auth()->id() == 21418) {
            $categories = PaymentCategory::orderBy(PaymentCategory::SORTABLE_FIELD['sortable_column'])->get();
        }

        return PaymentCategoryResource::collection($categories);
    }

    public function getProviders($category_id)
    {
        $category = PaymentCategory::findOrFail($category_id);
        $category->load('groups');

        return PaymentGroupResource::collection($category->groups);
    }

    public function getServices($group_id)
    {
        $paymentGroup = PaymentGroup::findOrFail($group_id);
        $paymentGroup->load(['paymentServices', 'paymentServices.serviceFields', 'paymentServices.serviceFields.values']);

        return PaymentServicesResource::make($paymentGroup);
    }

    public function getPaymentInfo(PaymentRequest $request)
    {

        $response = (new UniredMtsService())->getPaymentInfo($request);
//        $response = $this->paymentService->info($request);
//        if (is_string($response)) {

//        }

        if (is_string($response))   return ApiResponse::error($response);
        return new PaymentInfoCollection($response, $request->service_id, $request);
    }

    public function createPayment(PaymentRequest $request, UniredMtsService $service): JsonResponse
    {
        $result = $service->create($request);

        if (is_string($result)) return ApiResponse::error($result);

        return ApiResponse::success($result->debit->form_url);
    }
}
