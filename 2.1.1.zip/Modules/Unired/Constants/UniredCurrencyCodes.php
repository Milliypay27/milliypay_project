<?php

namespace Modules\Unired\Constants;

class UniredCurrencyCodes
{
    public const UZS = 860;
    public const RUB = 643;
}
