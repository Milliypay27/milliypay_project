<?php

namespace Modules\Unired\Constants;

use Modules\Unired\Models\Transfer;

class TransferDTOStatuses
{
    public const SUCCESS = 0;
    public const IN_PROGRESS = 1;
    public const ERROR = 2;

    public static function statuses()
    {
        return [
            self::SUCCESS => 'success',
            self::IN_PROGRESS => 'in progress',
            self::ERROR => 'error'
        ];
    }

    public static function status(Transfer $transfer)
    {
        $credit_status = $transfer->service_id ?
            TransferCreditStatuses::PAYMENT_SUCCESS :
            TransferCreditStatuses::TRANSFER_SUCCESS;

        if ($transfer->id > 48595) {
            if ($transfer->service_id and $transfer->credit_state == TransferCreditStatuses::PAYMENT_SUCCESS)
                return TransferDTOStatuses::SUCCESS;
            
            if ($transfer->credit_state == TransferCreditStatuses::TRANSFER_SUCCESS)
                return TransferDTOStatuses::SUCCESS;
        }

        if (
            $transfer->credit_state == $credit_status &&
            (
                $transfer->debit_state == TransferDebitStatuses::SUCCESS ||
                $transfer->debit_state == TransferDebitStatuses::SUCCESS_2
            )) {
            return TransferDTOStatuses::SUCCESS;
        } elseif (
            $transfer->credit_state == $credit_status ||
            $transfer->debit_state == TransferDebitStatuses::SUCCESS ||
            $transfer->debit_state == TransferDebitStatuses::SUCCESS_2
        ) {
            return TransferDTOStatuses::IN_PROGRESS;
        }

        return TransferDTOStatuses::ERROR;
    }
}
