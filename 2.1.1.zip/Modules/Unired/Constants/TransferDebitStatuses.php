<?php

namespace Modules\Unired\Constants;

class TransferDebitStatuses
{
    public const FORM_CREATED = 0;
    public const IN_PROGRESS = 1;
    public const SUCCESS = 2;
    public const SUCCESS_2 = 3;
    public const SUCCESS_3 = 0;
    public const PARTIAL_RETURN = 4;
    public const FULL_RETURN = 5;
    public const ERROR = 6;
    public const CANCELLED = 8;
}
