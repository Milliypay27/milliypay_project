<?php


namespace Modules\Unired\Constants;


class AppConstant
{
    public const AUTH_ATTEMPT_CALL = 1;
    public const AUTH_ATTEMPT_SMS = 0;

    public const UNIRED_CARD_ADD_METHOD = 'card.add';
    public const UNIRED_CARD_REMOVE_METHOD = 'card.remove';
    public const UNIRED_CARD_STATE_METHOD = 'card.state';
    public const UNIRED_TRANSFER_CHECK_METHOD = 'transfer.check.receipt';
    public const UNIRED_TRANSFER_CHECK_SERVICE_METHOD = 'transfer.check.service';
    public const UNIRED_TRANSFER_CREATE_METHOD = 'transfer.create';
    public const UNIRED_LOGIN_METHOD = 'login';
    public const UNIRED_PAYMENT_SERVICE = 'payment.services';
    public const UNIRED_PAYMENT_SERVICE_INFO = 'payment.info';
    public const UNIRED_PAYMENT_CREATE_WITHOUT_CARD = 'payment.create.unregistered.card';
    public const UNIRED_PAYMENT_CREATE = 'payment.create';

    public const UNIRED_RUBLE_CURRENCY = 643;
    public const UNIRED_UZS_CURRENCY = 860;
    public const UNIRED_CALLBACK_CARD = "callback.card";
    public const UNIRED_CALLBACK_TRANSFER = "callback.transfer";
    public const UNIRED_CALLBACK_PAYMENT = "callback.payment";
    public const UNIRED_DEBIT_FINISH = 'debit.finish';

    public const UNIRED_TRANSFER_STATE = 'transfer.state';
    public const UNIRED_PAYMENT_STATE = 'payment.state';

    // mts
    public const UNIRED_MTS_GET_RECEIVER_OWNER = 'get.receiver.owner';
    public const UNIRED_MTS_GET_COMMISSION = 'get.commission';
    public const UNIRED_MTS_GET_PAYMENT_COMMISSION = 'get.payment.commission';
    public const UNIRED_MTS_GET_PAYMENT_INFO = 'payment.get.receiver.info';

    public const UNIRED_MTS_COMMISSION_CACHE_NAME = 'unired.mts.commissions';
    public const UNIRED_MTS_PAYMENT_COMMISSION_CACHE_NAME = 'unired.mts.get.payment.commission';
}
