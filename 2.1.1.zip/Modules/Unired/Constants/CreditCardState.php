<?php

namespace Modules\Unired\Constants;

class CreditCardState
{
    const FORM_CREATED = 0;
    const IN_PROGRESS = 1;
    const CARD_DELETED = 3;
    const SUCCESS = 5;
    const ERROR = 6;
}
