<?php

namespace Modules\Unired\Constants;

class TransferCreditStatuses
{
    public const CHEQUE_CREATED = 0;
    public const CHEQUE_BLOCKED = 1;
    public const WAITING_FOR_DEBIT = 2;
    public const WAITING_FOR_CONFIRMATION = 3;
    public const SUCCESS = 4;
    public const PAYMENT_SUCCESS = 0;
    public const TRANSFER_SUCCESS = 4;
    public const TRANSFER_SUCCESS_2 = 0;
    public const MANUAL_CANCELLED = 20;
    public const DEBIT_CANCELLED = 21;
    public const WAITING_TRANSACTION_CONFIRMATION = 30;
    public const CANCELLED = 50;
    public const UNKNOWN_ERROR = -99;
}
