<?php

return [
    'name' => 'Unired',

    'login' => env('UNIRED_LOGIN'),
    'password' => env('UNIRED_PASSWORD'),
    'base_url' => env('UNIRED_BASE_URL','https://core.unired.uz/api/v1/transfer/tcb')
];
