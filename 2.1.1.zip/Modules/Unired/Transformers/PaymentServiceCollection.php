<?php

namespace Modules\Unired\Transformers;

use Modules\Unired\Models\ServiceField;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

/**
 * @property Collection serviceFields
 */
class PaymentServiceCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  Request  $request
     * @return array
     */
    public function toArray($request): array
    {
        return [
            'data' => $this->collectionsToArray(),
            'success' => true
        ];
    }

    public function collectionsToArray(): array
    {
        $data = [];
        foreach ($this->collection as $item){
            $data[] = [
                'id' => $item->id,
                'title' => $item->{'title_'.app()->getLocale()},
                'icon' => asset('storage/'.$item->icon),
//                'created_at' => $item->created_at->format('Y-m-d H:m'),
                'groups' => $this->groups($item->paymentGroups)
            ];
        }
        return $data;
    }

    public function groups($items): array
    {
        $group = [];

        foreach ($items as $item) {
            $group[] = [
                'id' => $item->id,
                'title' => $item->{'title_'.app()->getLocale()},
                'image' =>  asset('storage/'.$item->image),
                'services' => $this->services($item->paymentServices)
            ];
        }

        return $group;
    }


    public function services($items): array
    {
        $services = [];
            foreach ($items as $item){
                $services[] = [
                    'id' => $item->id,
                    'title' => $item->{'title_'.app()->getLocale()},
                    'min_amount' => $item->min_amount,
                    'max_amount' => $item->max_amount,
                    'service_fields' => $this->serviceFields($item->serviceFields)
                ];
            }
        return $services;
    }

    public function serviceFields($serviceFields): array
    {
        $data = [];
        /** @var ServiceField[] $serviceFields */
        foreach ($serviceFields as $item){
            $data[] = [
                'id' => $item->id,
                'type' => $item->type,
                'title' => $item->{'title_'.app()->getLocale()},
                'placeholder' => $item->placeholder,
                'pattern' => $item->pattern,
                'with_prefix' => $item->with_prefix,
                'max_length' => $item->max_length,
                'service_field_prefixes' => $this->serviceFieldPrefixes($item->prefixes),
                'service_field_values' => $this->serviceFieldValues($item->values)
            ];
        }
        return $data;
    }

    public function serviceFieldPrefixes($values): array
    {
        $data = [];
        foreach ($values as $item) {
            $data[] = [
              'id' => $item->id,
              'value' => $item->value,
              'prefix_value' => $item->prefix_value ?? ""
            ];
        }
        return $data;
    }

    public function serviceFieldValues($values): array
    {
        $data = [];
        foreach ($values as $item) {
            $data[] = [
              'id' => $item->id,
              'title' => $item->{'title_'.app()->getLocale()},
            ];
        }
        return $data;
    }
}
