<?php

namespace Modules\Unired\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;
use Modules\Unired\Models\ServiceField;

class PaymentServicesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $title = 'title_' . $this->getLocaleLang(app()->getLocale());

        return [
            'id' => $this->id,
            'title' => $this->{$title},
            'image' => asset('storage/' . $this->image),
            'services' => $this->services($this->paymentServices)
        ];
    }

    public function services($items): array
    {
        $services = [];
        foreach ($items as $item){
            $services[] = [
                'id' => $item->id,
                'ext_id' => $item->ext_service_id,
                'ext_info_id' => $item->ext_info_id,
                'title' => $item->{'title_'.$this->getLocaleLang(app()->getLocale())},
                'min_amount' => $item->min_amount,
                'max_amount' => $item->max_amount,
                'amount_name' => $item->amount_field_name,
                'service_fields' => $this->serviceFields($item->serviceFields)
            ];
        }
        return $services;
    }

    public function serviceFields($serviceFields): array
    {
        $data = [];
        /** @var ServiceField[] $serviceFields */
        foreach ($serviceFields as $item) {
            if ($item->name == 'pay_amount') continue;

            $data[] = [
                'id' => $item->id,
                'name' => $item->name,
                'type' => $item->type,
                'title' => $item->{'title_'.$this->getLocaleLang(app()->getLocale())},
                'placeholder' => $item->placeholder,
                'pattern' => $item->pattern,
                'with_prefix' => $item->with_prefix,
                'max_length' => $item->max_length,
                'service_field_prefixes' => $this->serviceFieldPrefixes($item->prefixes),
                'service_field_values' => $this->serviceFieldValues($item->values)
            ];
        }
        return $data;
    }

    public function serviceFieldPrefixes($values): array
    {
        $data = [];
        foreach ($values as $item) {
            $data[] = [
                'id' => $item->id,
                'value' => $item->value,
                'prefix_value' => $item->prefix_value ?? ""
            ];
        }
        return $data;
    }

    public function serviceFieldValues($values): array
    {
        $data = [];
        foreach ($values as $item) {
            $data[] = [
                'id' => $item->id,
                'ext_id' => $item->external_id,
                'title' => $item->{'title_'.$this->getLocaleLang(app()->getLocale())},
            ];
        }
        return $data;
    }

    public function getLocaleLang($lang)
    {
        return $lang;

//        if ($lang == 'en') return 'uz';
//        if ($lang == 'ru') return 'ru';
//        if ($lang == 'uz') return 'oz';
//
//        return 'uz';
    }
}
