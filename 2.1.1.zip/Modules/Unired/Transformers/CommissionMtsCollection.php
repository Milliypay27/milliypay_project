<?php

namespace Modules\Unired\Transformers;

use App\Models\Config;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Modules\Unired\Constants\AppConstant;

/**
 * @property Collection serviceFields
 */
class CommissionMtsCollection extends ResourceCollection
{

    public function toArray($request): array
    {
        return [
            'data' => $this->collectionsToArray(),
            'success' => true
        ];
    }

    public function collectionsToArray(): array
    {
        $data = [];

        $commissions = (array)$this->collection['commissions'] ?? [];
        $rate = $this->collection['rate'] ?? 0;

        foreach ($commissions as $commission) {
            $percentage = $credit = $min = $max = 0;

            foreach ($commission as $key => $value) {
                if ($key == 'min') $min = $value;
                if ($key == 'max') $max = $value;
                if (str_ends_with($key, '_p')) $percentage += $value;
                if (str_ends_with($key, '_c')) $credit += $value;
            }

            $data['commissions'][] = compact('min', 'max', 'percentage', 'credit');
        }

        $data['rate'] = $rate;
        $_min = collect($data['commissions'])->min('min');
        $_max = collect($data['commissions'])->max('max');

        $data['commissions_min'] = (int) Config::whereName('commissions_min')->value('value') ?? $_min;
        $data['commissions_max'] = $_max;

        $data['commissions_min_uzs'] = (int) Config::whereName('commissions_min_uzs')->value('value') ?? $_min * $rate;
        $data['commissions_max_uzs'] = $_max * $rate;

        return $data;
    }
}
