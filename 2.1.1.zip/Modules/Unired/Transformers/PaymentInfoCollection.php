<?php

namespace Modules\Unired\Transformers;

use Modules\Unired\Models\InfoTranslation;
use Modules\Unired\Services\PaymentGroupService;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

/**
 * @property Collection serviceFields
 */
class PaymentInfoCollection extends ResourceCollection
{
    private $ignoredFields;
    private $request;
    private $phone_number_null_services = [5, 4, 64];

    public function __construct($resource, $service_id, $request)
    {
        $this->request = $request;
        $this->ignoredFields = (new PaymentGroupService())->getModelByServiceId($service_id)->ignoredFields;
        $this->ignoredFields = \Modules\Unired\Models\IgnoredField::all();

        parent::__construct($resource);
    }

    /**
     * Transform the resource collection into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request): array
    {
        return [
            'data' => [
                'info_id' => $this->collection['info_id'],
                'items' => $this->collectionsToArray(),
            ],
            'success' => true
        ];
    }

    private function tofloat($num) {
        $dotPos = strrpos($num, '.');
        $commaPos = strrpos($num, ',');
        $sep = (($dotPos > $commaPos) && $dotPos) ? $dotPos :
            ((($commaPos > $dotPos) && $commaPos) ? $commaPos : false);

        if (!$sep) {
            return floatval(preg_replace("/[^0-9]/", "", $num));
        }

        return floatval(
            preg_replace("/[^0-9]/", "", substr($num, 0, $sep)) . '.' .
            preg_replace("/[^0-9]/", "", substr($num, $sep+1, strlen($num)))
        );
    }

    public function collectionsToArray(): array
    {
        $items = $this->collection['items'] ?? [];
        foreach ($items as $key => $response)
            foreach ($this->ignoredFields as $ignoredField) {
                if ($ignoredField->key === $response->key)
                    unset($items[$key]);
            }

        $data = [];
        $infoTranslations = InfoTranslation::query()->get();

        $label = '';

        foreach ($items as $item) {
            $itemKey = $item->key;
            $infoTranslation = $infoTranslations->first(function ($item) use ($itemKey) {
                return $item->key == $itemKey;
            });

            $value = $item->value;

            if (in_array($itemKey, ['saldo_k', 'saldo', 'saldo_n', 'p_saldo_k'])) {
                $k = (strpos($value, '-')) ? -1 : 1;
                $value = $k * $this->tofloat($value);
                $value = number_format($value);
            }

            if (!is_null($infoTranslation)) {
                $data[] = [
                    'label' => $label = $infoTranslation->getAttribute('label_' . app()->getLocale()),
                    'value' => $value
                ];
            } else {
                $label_ru = $item->labelRu ?? $item->label_ru ?? '';
                $label_uz = $item->labelUz ?? $item->label_uz ?? '';
                $label = (app()->getLocale() == 'ru' || app()->getLocale() == 'en') ? $label_ru : $label_uz;

                $data[] = [
                    'label' => $label,
                    'value' => $value
                ];
            }
        }

        if (in_array($this->request->service_id, $this->phone_number_null_services)) {
            $data[] = [
                'label' => $label,
                'value' => $this->request->fields[0]['value'] ?? ''
            ];
        }

        return $data;
    }
}
