<?php

namespace Modules\Unired\Transformers;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Modules\Unired\Constants\TransferCreditStatuses;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Constants\TransferDTOStatuses;
use Modules\Unired\Constants\UniredCurrencyCodes;
use Modules\Unired\Models\InfoTranslation;
use Modules\Unired\Models\PaymentService;
use Modules\Unired\Models\ServiceField;
use Modules\Unired\Models\UniredRequest;

/**
 * @package TransferResponse
 * @property int $id
 * @property int $amount
 * @property string $credit_card_number
 * @property int $credit_state
 * @property int $debit_state
 * @property int $debit_amount
 * @property int $credit_amount
 * @property int $debit_currency
 * @property int $credit_currency
 * @property Carbon $created_at
 * @property object $creditCard
 * @property UniredRequest $infoRequest
 * @property PaymentService $service
 * @property mixed $receiver
 * @property mixed $currency_rate
 * @property mixed $commissions
 * @property mixed $sender
 * @property mixed $request
 */
class TransferResponse extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request): array
    {
        $info = [];
        $receiver = [];
        $service_id = null;
        $provider_id = null;
        $credit_status = TransferCreditStatuses::PAYMENT_SUCCESS;
        // if transfer is p2p
        if ($this->credit_card_number) {
            $credit_status = TransferCreditStatuses::TRANSFER_SUCCESS;
            $service = trans('api.transfer');
            $info[] = ["key" => trans('api.owner'), 'value' => $this->receiver->owner];
            $info[] = ["key" => trans('api.card_number'), 'value' => $this->receiver->number];
            if ($infoRequest = $this->infoRequest) {
                $info[] = ["key" => trans('api.bank'), 'value' => $infoRequest->response->bank];
            }

            $receiver = $this->formatReceiver((array)$this->receiver);

            if (strpos($this->credit_card_number, '8600') == 0)
                $image = asset('img/card/uzcard.png');
            else
                $image = asset('img/card/humo.png');
        } // if it's payment
        else {
            $service = $this->service->{'title_' . app()->getLocale()};

//            $info[] = ["key" => trans('api.service_name'), 'value' => $this->service->{'title_' . app()->getLocale()}];
            $info[] = ["key" => trans('api.service_provider'), 'value' => $this->service->paymentGroup->category->{'title_' . app()->getLocale()}];

            $info = array_merge($info, $this->getInfo($this->infoRequest));

            $fields = $this->receiver->fields ?? [];
            $service_id = $this->service->id;
            $provider_id = $this->service->payment_group_id;
            $receiver = $this->formatReceiver((array)$fields, $this->service);

            $image = asset('storage/' . $this->service->paymentGroup->image);
        }

        if (
            $this->credit_state == $credit_status &&
            (
                $this->debit_state == TransferDebitStatuses::SUCCESS ||
                $this->debit_state == TransferDebitStatuses::SUCCESS_2 ||
                $this->debit_state == TransferDebitStatuses::SUCCESS_3
            )) {
            $status = TransferDTOStatuses::SUCCESS;
        } elseif (
            $this->credit_state == $credit_status ||
            $this->debit_state == TransferDebitStatuses::SUCCESS ||
            $this->debit_state == TransferDebitStatuses::SUCCESS_2
        ) {
            $status = TransferDTOStatuses::IN_PROGRESS;
        } else {
            $status = TransferDTOStatuses::ERROR;
        }

        $oRequest = $this->request;
        $sender = $this->sender;

        if ($this->id > 48595) {
            if ($this->credit_state == TransferCreditStatuses::TRANSFER_SUCCESS)
                $status = TransferDTOStatuses::SUCCESS;

            if (!$service_id) {
                $oRequest = [
                    'card_number' => $this->request->card_number ?? '',
                    'card_id' => 1,
                    'amount' => $this->request->amount ?? 0
                ];
            } else {
                $oRequest = (array) $this->request;
                $oRequest['card_id'] = 1;
                $oRequest['provider_id'] = $provider_id;
            }

            $sender = ["owner" => ' ', "number" => ' ', "bank" => ' ', "provider" => ' ', 'expire' => ' '];
        }

        if ($this->id > 48595) {
            if ($this->credit_state == TransferCreditStatuses::TRANSFER_SUCCESS)
                $status = TransferDTOStatuses::SUCCESS;
        }

        $co = (array) $this->commissions;

        if (isset($co['commissions'])) {
            $commissions = (new CommissionMtsCollection($co))->collectionsToArray();
        } else {
            $commissions = null;
        }

        return [
            'id' => $this->id,
            'service' => $service,
            'service_id' => $service_id,
            'provider_id' => $provider_id,
            'image' => $image,
            'status' => $status,
            "debit" => $this->debit_amount,
            "debit_currency" => $this->debit_currency == UniredCurrencyCodes::RUB ? "RUB" : "UZS",
            "credit" => $this->credit_amount,
            "credit_currency" => $this->credit_currency == UniredCurrencyCodes::RUB ? "RUB" : "UZS",
            "info" => $info,
            'receiver' => $receiver,
            'commissions' => $commissions,
            'request' => $oRequest,
            "created_at" => $this->created_at,
            "sender" => $sender
        ];
    }

    public function getInfo($infoRequest)
    {
        $info = [];

        if ($infoRequest) {
            $fields = $infoRequest->params->receiver->fields ?? $infoRequest->params->fields;
            $info = array_merge($info, $this->getParamFields($fields));


//            Info larni checkka qo'shish
//            if (auth()->id() == 21418) {
                try {
                    $items = $infoRequest->response->response ?? $infoRequest->response->cheque->response;
                } catch (\Exception $exception) {
                    $items = [];
                }

                $items = collect($items)->whereIn('key', ['fio', 'fio_abonent', 'adres']);

                foreach ($items as $item) {
                    if ($item and isset($item->value)) {
                        $label_ru = $item->labelRu ?? $item->label_ru ?? '';
                        $label_uz = $item->labelUz ?? $item->label_uz ?? '';
                        $label = (app()->getLocale() == 'ru' || app()->getLocale() == 'en') ? $label_ru : $label_uz;

                        $info[] = [
                            'key' => $label,
                            'value' => $item->value ?? ''
                        ];
                    }
                }



//                try {
//                    $items = $infoRequest->response->response ?? $infoRequest->response->cheque->response;
//                } catch (\Exception $exception) {
//                    $items = [];
//                }
//                $ignoredFields = \Modules\Unired\Models\IgnoredField::all();;
//                $infoTranslations = InfoTranslation::query()->get();
//                foreach ($items as $item) {
//                    $itemKey = $item->key;
//                    $ignoredField = $ignoredFields->first(function ($ignoredField) use ($itemKey) {
//                        return $ignoredField->key == $itemKey;
//                    });
//                    if (!is_null($ignoredField))
//                        continue;
//
//                    $infoTranslation = $infoTranslations->first(function ($item) use ($itemKey) {
//                        return $item->key == $itemKey;
//                    });
//                    if (!is_null($infoTranslation))
//                        $info[] = [
//                            'key' => $infoTranslation->getAttribute('label_' . app()->getLocale()),
//                            'value' => $item->value
//                        ];
//                    else
//                        $label_ru = $item->labelRu ?? $item->label_ru ?? '';
//                        $label_uz = $item->labelUz ?? $item->label_uz ?? '';
//                        $label = (app()->getLocale() == 'ru' || app()->getLocale() == 'en') ? $label_ru : $label_uz;
//
//                        $info[] = [
//                            'key' => $label,
//                            'value' => $item->value
//                        ];
//                }
            }
//        }

        return $info;
    }

    private function formatReceiver(array $array, PaymentService $service = null): array
    {
        $result = [];

        foreach ($array as $key => $value) {
            $result[] = [
                'name' => $key,
                'value' => $value
            ];
        }

        return $result;
    }

    /**
     * @param $fields
     * @return array
     */
    private function getParamFields($fields): array
    {
        $info = [];
        /*** @var ServiceField $serviceField */
        $serviceFields = $this->service->serviceFields;

        foreach ($fields as $ext_id => $value) {
            $serviceField = $serviceFields->first(function ($serviceField) use ($ext_id) {
                return $serviceField->name == $ext_id;
            });
            if ($serviceField->type == ServiceField::SELECT_TYPE) {
                $value = $serviceField->values->first(function ($serviceFieldValue) use ($value) {
                    return $serviceFieldValue->external_id == $value;
                });

                $value = $value->{'title_' . app()->getLocale()} ?? '';

                $label_ru = $item->labelRu ?? $item->label_ru ?? '';
                $label_uz = $item->labelUz ?? $item->label_uz ?? '';
            }
            $info[] = [
                'key' => $serviceField->{'title_' . app()->getLocale()},
                'value' => $value,
            ];
        }
        return $info;
    }

    private function ccMasking($number): string
    {
        return implode(" ", str_split(substr($number, 0, 6) . str_repeat('*', strlen($number) - 6) . substr($number, -4), 4));
    }
}
