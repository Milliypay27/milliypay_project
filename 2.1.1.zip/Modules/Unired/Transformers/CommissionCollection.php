<?php

namespace Modules\Unired\Transformers;

use App\Models\Config;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Resources\Json\ResourceCollection;

/**
 * @property Collection serviceFields
 */
class CommissionCollection extends ResourceCollection
{

    public function toArray($request): array
    {
        return [
            'data' => $this->collectionsToArray(),
            'success' => true
        ];
    }

    public function collectionsToArray(): array
    {
        $data = [];
        foreach ((array)$this->collection as $item) {
            if (is_bool($item) or !$item['commissions'] or !$item['commission_payment'] or !$item['rate'])
                continue;

            $commissions_min = collect($item['commissions'])->min('min');
            $commissions_max = collect($item['commissions'])->max('max');

            $commissions_payment_min = collect($item['commission_payment'])->min('min');
            $commissions_payment_max = collect($item['commission_payment'])->max('max');

            $rate = (int)$item['rate']->price ?? 0;

            $data = [
                'commissions' => $item['commissions'],
                'payment_commissions' => $item['commission_payment'],
                'rate' => $rate
            ];

            $data['commissions_min'] = (int) Config::whereName('commissions_min')->value('value') ?? $commissions_min;
            $data['commissions_max'] = $commissions_max;

            $data['payment_commissions_min'] = (int) Config::whereName('payment_commissions_min')->value('value') ?? $commissions_payment_min;
            $data['payment_commissions_max'] = $commissions_payment_max;

            $data['commissions_min_uzs'] = (int) Config::whereName('commissions_min_uzs')->value('value') ?? $commissions_min * $rate;
            $data['commissions_max_uzs'] = $commissions_max * $rate;

            $data['payment_commissions_min_uzs'] = (int) Config::whereName('payment_commissions_min_uzs')->value('value') ?? $commissions_payment_min * $rate;
            $data['payment_commissions_max_uzs'] = $commissions_payment_max * $rate;
        }

        return $data;
    }
}
