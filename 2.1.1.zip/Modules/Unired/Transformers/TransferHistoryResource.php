<?php

namespace Modules\Unired\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Modules\Unired\Constants\TransferCreditStatuses;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Constants\TransferDTOStatuses;
use Modules\Unired\Constants\UniredCurrencyCodes;
use Modules\Unired\Models\InfoTranslation;
use Modules\Unired\Models\ServiceField;
use Modules\Unired\Models\Transfer;

class TransferHistoryResource extends ResourceCollection
{

    public function toArray($request): array
    {
        return [
            'data' => $this->collection->map(function (Transfer $transfer) {
                return $this->customResponse($transfer);
            }),
            'metaData' => [
                'totalCount' => $this->total(),
                'count' => $this->count(),
                'limit' => $this->perPage(),
                'current_page' => $this->currentPage(),
                'total_pages' => $this->lastPage()
            ],
            'success' => true
        ];
    }

    private function customResponse(Transfer $transfer)
    {
        $info = [];
        // if transfer is p2p
        if ($transfer->credit_card_number) {
            $service = trans('api.transfer');
            $info[] = ["key" => trans('api.owner'), 'value' => $transfer->receiver->owner];
            $info[] = ["key" => trans('api.card_number'), 'value' => $this->ccMasking($transfer->receiver->number)];
            if ($infoRequest = $transfer->infoRequest) {
                $info[] = ["key" => trans('api.bank'), 'value' => $infoRequest->response->bank];
            }
            if (strpos($transfer->credit_card_number, '8600') == 0)
                $image = asset('img/card/uzcard.png');
            else
                $image = asset('img/card/humo.png');
        } // if it's payment
        else {
            $service = $transfer->service->{'title_' . app()->getLocale()};
            $info[] = ["key" => trans('api.service_name'), 'value' => $transfer->service->{'title_' . app()->getLocale()}];
            $info[] = ["key" => trans('api.service_provider'), 'value' => $transfer->service->paymentGroup->{'title_' . app()->getLocale()}];

            if ($infoRequest = $transfer->infoRequest) {
                $info = array_merge($info, $this->getParamFields($infoRequest->params->receiver->fields, $transfer));
                $items = $infoRequest->response->response;
                $ignoredFields = $transfer->service->paymentGroup->ignoredFields;
                $infoTranslations = InfoTranslation::query()->get();
                foreach ($items as $item) {
                    $itemKey = $item->key;
                    $ignoredField = $ignoredFields->first(function ($ignoredField) use ($itemKey) {
                        return $ignoredField->key == $itemKey;
                    });
                    if (!is_null($ignoredField))
                        continue;

                    $infoTranslation = $infoTranslations->first(function ($item) use ($itemKey) {
                        return $item->key == $itemKey;
                    });

                    if (!is_null($infoTranslation))
                        $info[] = [
                            'key' => $infoTranslation->getAttribute('label_' . app()->getLocale()),
                            'value' => $item->value
                        ];
                    else
                        $info[] = [
                            'key' => (app()->getLocale() == 'ru' || app()->getLocale() == 'en') ? $item->labelRu : $item->labelUz,
                            'value' => $item->value
                        ];
                }
            }
            $image = asset('storage/' . $transfer->service->paymentGroup->image);
        }
        if (
            $transfer->credit_state == TransferCreditStatuses::SUCCESS &&
            (
                $transfer->debit_state == TransferDebitStatuses::SUCCESS ||
                $transfer->debit_state == TransferDebitStatuses::SUCCESS_2
            )) {
            $status = TransferDTOStatuses::SUCCESS;
        } elseif (
            $transfer->credit_state == TransferCreditStatuses::SUCCESS ||
            $transfer->debit_state == TransferDebitStatuses::SUCCESS ||
            $transfer->debit_state == TransferDebitStatuses::SUCCESS_2
        ) {
            $status = TransferDTOStatuses::IN_PROGRESS;
        } else {
            $status = TransferDTOStatuses::ERROR;
        }

        return [
            'id' => $transfer->id,
            'service' => $service,
            'image' => $image,
            'status' => $status,
            "debit" => $transfer->debit_amount,
            "debit_currency" => $transfer->debit_currency == UniredCurrencyCodes::RUB ? "RUB" : "UZS",
            "credit" => $transfer->credit_amount,
            "credit_currency" => $transfer->credit_currency == UniredCurrencyCodes::RUB ? "RUB" : "UZS",
            "info" => $info,
            "created_at" => $transfer->created_at,
            "sender" => $transfer->sender
        ];
    }

    public function withResponse($request, $response)
    {
        $jsonResponse = json_decode($response->getContent(), true);
        unset($jsonResponse['links'],$jsonResponse['meta']);
        $response->setContent(json_encode($jsonResponse));
    }

    private function ccMasking($number): string
    {
        return implode(" ", str_split(substr($number, 0, 6) . str_repeat('*', strlen($number) - 6) . substr($number, -4), 4));
    }

    /**
     * @param $fields
     * @param Transfer $transfer
     * @return array
     */
    private function getParamFields($fields, Transfer $transfer): array
    {
        $info = [];
        /*** @var ServiceField $serviceField */
        $serviceFields = $transfer->service->serviceFields;

        foreach ($fields as $ext_id => $value) {
            $serviceField = $serviceFields->first(function ($serviceField) use ($ext_id) {
                return $serviceField->name == $ext_id;
            });
            if ($serviceField->type == ServiceField::SELECT_TYPE) {
                $value = $serviceField->values->first(function ($serviceFieldValue) use ($value) {
                    return $serviceFieldValue->external_id == $value;
                })->{'title_' . app()->getLocale()};
            }
            $info[] = [
                'key' => $serviceField->{'title_' . app()->getLocale()},
                'value' => $value,
            ];
        }
        return $info;
    }
}
