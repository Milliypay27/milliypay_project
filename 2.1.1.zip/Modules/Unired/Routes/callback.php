<?php

use Illuminate\Support\Facades\Route;
use Modules\Unired\Http\Controllers\CallbackController;

Route::post(env('UNIRED_CARD_CALLBACK'), [CallbackController::class, 'cardCallback'])->name('card.callback');
Route::post(env('UNIRED_TRANSFER_CALLBACK'), [CallbackController::class, 'transferCallback'])->name('transfer.callback');
Route::post(env('UNIRED_PAYMENT_CALLBACK'), [CallbackController::class, 'paymentCallback'])->name('payment.callback');
Route::post(env('UNIRED_RATE_CALLBACK'), [CallbackController::class, 'rateCallback'])->name('rate.callback');

Route::post(env('UNIRED_MTS_TRANSFER_CALLBACK'), [CallbackController::class, 'transferMtsCallback'])->name('transfer.mts.callback');
Route::post(env('UNIRED_MTS_PAYMENT_CALLBACK'), [CallbackController::class, 'paymentMtsCallback'])->name('payment.mts.callback');
