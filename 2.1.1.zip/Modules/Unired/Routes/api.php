<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

use Modules\Unired\Http\Controllers\CallbackController;
use Modules\Unired\Http\Controllers\CardController;
use Modules\Unired\Http\Controllers\CommissionController;
use Modules\Unired\Http\Controllers\PaymentServiceController;
use Modules\Unired\Http\Controllers\TransferController;
use Modules\Unired\Http\Controllers\UniredServiceController;

Route::middleware(['auth:api', 'unired.localization', 'user_activity_at'])
    ->group(function () {

        Route::post('card', [CallbackController::class, 'cardCallback'])->name('card.callback');
        Route::prefix('card')->as('card.')->group(function () {
            Route::get('all', [CardController::class, 'getMyCards'])->name('all');
            Route::get('request', [CardController::class, 'requestCard'])->name('request');
            Route::get('state/{ext_id}', [CardController::class, 'state'])->name('state');
            Route::post('remove', [CardController::class, 'removeCard'])->name('remove');
        });

        Route::prefix('payment')->as('payment.')->group(function () {
            Route::get('services', [PaymentServiceController::class, 'getPaymentService'])->name('services');

            Route::get('categories', [PaymentServiceController::class, 'getCategories'])->name('categories');
            Route::get('providers/{category_id}', [PaymentServiceController::class, 'getProviders'])->name('providers');
            Route::get('services/{group_id}', [PaymentServiceController::class, 'getServices'])->name('provider.show');

            Route::post('info', [PaymentServiceController::class, 'getPaymentInfo'])->name('info');
            Route::post('create', [PaymentServiceController::class, 'createPayment'])->name('create');

            Route::post('refresh', [UniredServiceController::class, 'refresh'])->name('refresh');
        });

        Route::prefix('transfer')->as('transfer.')->group(function () {
            Route::post('check', [TransferController::class, 'requestCreditCardInfo'])->name('check');
            Route::post('create', [TransferController::class, 'createTransfer'])->name('create');

            // mts bank p2p
            Route::post('get-receiver-owner', [TransferController::class, 'checkReceiverOwner'])->name('get.receiver.owner');
            Route::post('form-url', [TransferController::class, 'formUrl'])->name('form-url');

            Route::get('my', [TransferController::class, 'my'])->name('my');
            Route::get('my-transfers-filter', [TransferController::class, 'myTransfersFilter'])->name('myFilter');
            Route::get('my-transfers', [TransferController::class, 'myTransfersHistory'])->name('my-transfers');

            Route::get('status', [TransferController::class, 'status'])->name('status');
        });

        Route::prefix('commission')->as('commission.')->group(function () {
            Route::get('all', [CommissionController::class, 'getCommissions'])->name('all');
            Route::get('', [CommissionController::class, 'get'])->name('get');
            Route::get('payment', [CommissionController::class, 'payment'])->name('get');
        });
    });
