<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transfers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('user_id')
                ->references('id')
                ->on('users')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();
            $table->foreignId('credit_card_id')
                ->nullable()
                ->references('id')
                ->on('credit_cards')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();
            $table->string('ext_id')->nullable();
            $table->integer('debit_order_id')->nullable();
            $table->string('debit_form_url')->nullable();
            $table->integer('debit_state')->nullable();
            $table->bigInteger('debit_commission')->nullable();
            $table->bigInteger('debit_amount')->nullable();
            $table->integer('debit_currency')->nullable();
            $table->string('credit_id')->nullable();
            $table->string('credit_callback_url')->nullable();
            $table->integer('credit_state')->nullable();
            $table->string('credit_description')->nullable();
            $table->bigInteger('credit_amount')->nullable();
            $table->integer('credit_currency')->nullable();
            $table->integer('currency_rate')->nullable();
            $table->jsonb('receiver')->nullable();
            $table->jsonb('sender')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transfers');
    }
};
