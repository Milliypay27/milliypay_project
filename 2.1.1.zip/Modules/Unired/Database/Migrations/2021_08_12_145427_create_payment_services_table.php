<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_services', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('ext_service_id');
            $table->string('ext_info_id');
            $table->string('ext_provider_id');
            $table->integer('min_amount');
            $table->integer('max_amount');
            $table->string('title_oz');
            $table->string('title_uz');
            $table->string('title_ru');
            $table->string('title_en');
            $table->string('image');
            $table->integer('order');
            $table->foreignId('payment_group_id')->constrained()->cascadeOnUpdate()->cascadeOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payment_services');
    }
};
