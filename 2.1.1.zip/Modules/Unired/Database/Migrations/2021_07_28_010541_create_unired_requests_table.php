<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUniredRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('unired_requests', function (Blueprint $table) {
            $table->id();

            $table->string('method');
            $table->jsonb('params')->nullable();
            $table->jsonb('response')->nullable();
            $table->jsonb('error')->nullable();
            $table->boolean('status')->nullable();
            $table->dateTime('remote_timestamp')->nullable();

            $table->foreignId('user_id')->nullable()
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->foreignId('admin_id')
                ->nullable()->index();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('unired_requests');
    }
}
