<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('transfers', function (Blueprint $table) {
            $table->string('ext_id')->nullable()->change();
            $table->integer('debit_order_id')->nullable()->change();
            $table->string('debit_form_url')->nullable()->change();
            $table->integer('debit_state')->nullable()->change();
            $table->bigInteger('debit_commission')->nullable()->change();
            $table->bigInteger('debit_amount')->nullable()->change();
            $table->integer('debit_currency')->nullable()->change();
            $table->string('credit_id')->nullable()->change();
            $table->string('credit_callback_url')->nullable()->change();
            $table->integer('credit_state')->nullable()->change();
            $table->string('credit_description')->nullable()->change();
            $table->bigInteger('credit_amount')->nullable()->change();
            $table->integer('credit_currency')->nullable()->change();
            $table->integer('currency_rate')->nullable()->change();
            $table->json('receiver')->nullable()->change();
            $table->json('sender')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('transfers', function (Blueprint $table) {
            $table->string('ext_id')->change();
            $table->integer('debit_order_id')->change();
            $table->string('debit_form_url')->change();
            $table->integer('debit_state')->change();
            $table->bigInteger('debit_commission')->change();
            $table->bigInteger('debit_amount')->change();
            $table->integer('debit_currency')->change();
            $table->string('credit_id')->change();
            $table->string('credit_callback_url')->change();
            $table->integer('credit_state')->change();
            $table->string('credit_description')->change();
            $table->bigInteger('credit_amount')->change();
            $table->integer('credit_currency')->change();
            $table->integer('currency_rate')->change();
//            $table->jsonb('receiver')->change();
//            $table->jsonb('sender')->change();
        });
    }
};
