<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTransferSendersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transfer_senders', function (Blueprint $table) {
            $table->id();
            $table->string("full_name")->nullable();
            $table->date('birthday')->nullable();
            $table->string('citizenship')->nullable();
            $table->string('passport_serial')->nullable();
            $table->date('date_of_issue')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transfer_senders');
    }
}
