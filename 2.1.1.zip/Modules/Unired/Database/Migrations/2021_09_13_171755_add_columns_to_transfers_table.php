<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('transfers', function (Blueprint $table) {
            $table->string('credit_card_number')->nullable()->after('credit_card_id');
            $table->double('amount')->nullable()->after('credit_card_number');
            $table->integer('service_id')->nullable()->after('amount');
            $table->integer('provider_id')->nullable()->after('service_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('transfers', function (Blueprint $table) {
            $table->dropColumn(['credit_card_number', 'amount', 'service_id', 'provider_id']);
        });
    }
};
