<?php

namespace Modules\Unired\Database\Seeders;

use DB;
use Exception;
use Illuminate\Database\Seeder;
use Schema;
use Throwable;

class UniredDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     * @throws Throwable
     */
    public function run()
    {

        Schema::disableForeignKeyConstraints();

        try {
            DB::transaction(function () {
                DB::insert(file_get_contents(__DIR__ . '/sql/payment_categories.sql'));
                DB::insert(file_get_contents(__DIR__ . '/sql/payment_groups.sql'));
                DB::insert(file_get_contents(__DIR__ . '/sql/service_field_prefixes.sql'));
                DB::insert(file_get_contents(__DIR__ . '/sql/service_field_values.sql'));
                DB::insert(file_get_contents(__DIR__ . '/sql/service_fields.sql'));
                DB::insert(file_get_contents(__DIR__ . '/sql/payment_services.sql'));
            });
        } catch (Exception $exception) {
            DB::rollBack();
            $this->command->info($exception->getMessage());
        }

        Schema::enableForeignKeyConstraints();

        $this->call(IgnoreFieldsSeederTableSeeder::class);
    }
}
