INSERT INTO payment_categories (id, title_uz, title_oz, title_en, title_ru, position, created_at, updated_at, icon)
VALUES (3, 'Kommunal xizmatlari', 'Коммунал хизматлар', 'Communal services', 'Коммунальные услуги', 2,
        '2021-09-18 13:38:07', '2021-09-26 01:09:40', 'payment-category/1631954287.svg'),
       (4, 'Televideniya va IPTV', 'Телевидения ва IPTV', 'Television and IPTV', 'Телевидение и IPTV', 3,
        '2021-09-18 13:42:46', '2021-09-26 01:09:40', 'payment-category/1631954566.svg'),
       (2, 'Internet provayderlar', 'Интернет провайдерлар', 'Internet providers', 'Интернет провайдеры', 1,
        '2021-09-16 16:45:50', '2021-09-26 01:09:40', 'payment-category/1631792750.svg'),
       (5, 'Davlat xizmatlari va DYHXB jarimalari', 'Давлат хизматлари ва ДЙХХБ жарималари',
        'State services and traffic police fines', 'Государственные услуги и штрафы ГАИ', 4, '2021-09-30 19:24:48',
        '2021-11-11 14:28:59', 'payment-category/1633011888.svg'),
       (6, 'Xayriya', 'Хайрия', 'Donate', 'Благотворительность', 4, '2021-11-20 16:59:04', '2021-11-20 17:17:14',
        'payment-category/1637409544.png'),
       (1, 'Mobil operatorlar', 'Мобил операторлар', 'Mobile payments', 'Мобильные операторы', 0, '2021-09-16 16:43:50',
        '2021-09-26 01:09:35', 'payment-category/1631792630.svg');
