<?php

namespace Modules\Unired\Services;

use Modules\Unired\Models\IgnoredField;
use Modules\Unired\Repositories\BaseRepository;

class IgnoredFieldService extends BaseService
{
    public function __construct()
    {
        $this->repository = new BaseRepository(IgnoredField::class);
    }

    public function paginatedList($data = [])
    {
        return $this->repository->paginatedList([], 'paymentGroup');
    }
}
