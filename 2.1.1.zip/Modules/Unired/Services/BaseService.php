<?php

namespace Modules\Unired\Services;

use Modules\Unired\Interfaces\IBaseService;
use Modules\Unired\Models\BaseModel;
use Modules\Unired\Repositories\BaseRepository;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

abstract class BaseService implements IBaseService
{
    protected ?BaseRepository $repository = null;

    /**
     * @param array $data
     * @return mixed
     */
    public function paginatedList($data = [])
    {
        return $this->repository->paginatedList($data);
    }

    /**
     * @param $data
     * @return BaseModel|BaseModel[]|Builder|Builder[]|Collection|Model|null
     */
    public function createModel($data)
    {
        return $this->getRepository()->create($data);
    }

    /**
     * @return BaseRepository
     */
    protected function getRepository(): BaseRepository
    {
        if ($this->repository) {
            return $this->repository;
        }
        dd(get_class($this) . ' repository property not implemented');
    }

    /**
     * @param $data
     * @param $id
     * @return Builder|Builder[]|Collection|Model|null
     */
    public function updateModel($data, $id)
    {
        return $this->getRepository()->update($data, $id);
    }

    /**
     * @param $id
     * @return bool|mixed|null
     */
    public function deleteModel($id)
    {
        return $this->getRepository()->delete($id);
    }

    /**
     * @param $id
     * @return Builder|Builder[]|Collection|Model|null
     */
    public function getModelById($id)
    {
        return $this->getRepository()->findById($id);
    }
}
