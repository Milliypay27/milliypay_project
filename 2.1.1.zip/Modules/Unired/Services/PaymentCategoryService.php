<?php

namespace Modules\Unired\Services;

use Modules\Unired\Helpers\PathHelper;
use Modules\Unired\Models\BaseModel;
use Modules\Unired\Models\PaymentCategory;
use Modules\Unired\Repositories\PaymentCategoryRepository;
use Exception;
use Illuminate\Database\Eloquent\{Builder, Collection, Model};

class PaymentCategoryService extends BaseService
{
    public function __construct()
    {
        $this->repository = new PaymentCategoryRepository();
    }

    /**
     * @param array $data
     * @return Builder[]|Collection
     * @throws Exception
     */
    public function getAllModel(array $data = [])
    {
        return $this->repository->getAllModel($data);
    }

    public function createModel($data)
    {
        $data['icon'] = PathHelper::createPath('payment-category', $data['icon']);
        return $this->repository->create($data);
    }

    /**
     * @param $data
     * @param $id
     * @return BaseModel|BaseModel[]|Builder|Builder[]|Collection|Model|null
     */
    public function updateModel($data, $id)
    {
        /*** @var PaymentCategory $model */
        if (array_key_exists('icon', $data)) {
            $model = $this->repository->findById($id);
            PathHelper::deletePath($model->icon);
            $data['icon'] = PathHelper::createPath('payment-category', $data['icon']);
        }
        return $this->repository->update($data, $id);
    }

    /**
     * @param $id
     * @return bool|null
     * @throws Exception
     */
    public function deleteModel($id): ?bool
    {
        /*** @var PaymentCategory $model */
        $model = $this->repository->findById($id);
        PathHelper::deletePath($model->icon);
        return $this->repository->delete($id);
    }
}
