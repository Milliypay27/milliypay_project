<?php

namespace Modules\Unired\Services;

use Modules\Unired\Constants\UniredCurrencyCodes;
use Modules\Unired\Http\Requests\PaymentRequest;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Models\ServiceField;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Models\UniredRequest;
use Modules\Unired\Repositories\PaymentServiceRepository;
use Modules\Unired\Repositories\UniredRequestRepository;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;

/**
 * @property PaymentGroup $paymentGroup
 */
class PaymentService
{
    private PaymentServiceRepository $paymentServiceRepository;
    private UniredService $uniredRequest;
    private CreditCardService $creditCardService;
    private ServiceFieldService $serviceFieldService;
    protected TransferService $transferService;
    private UniredRequestRepository $uniredRequestRepository;

    public function __construct()
    {
        $this->paymentServiceRepository = new PaymentServiceRepository();
        $this->uniredRequest = resolve(UniredService::class);
        $this->creditCardService = new CreditCardService();
        $this->serviceFieldService = new ServiceFieldService();
        $this->transferService = new TransferService();
        $this->uniredRequestRepository = new UniredRequestRepository();
    }

    public function getAllPaymentService()
    {
        return $this->paymentServiceRepository->allPaymentService();
    }

    public function info(PaymentRequest $request)
    {
        $data = $request->all();
        $service = $this->paymentServiceRepository->findPaymentService($data['service_id']);
        $fields = [];
        foreach ($data['fields'] as $field) {
            $service_field = ServiceField::query()->find($field['field_id']);
            $fields[$service_field->name] = !$service_field->isSelect() ? $field['value'] :
                $service_field->getValue($field['value'])->external_id;
        }
        if (is_null($service->ext_info_id)) {
            return $fields;
        }

        $input = [
            "id" => $service->ext_provider_id,
            "service_id" => $service->ext_info_id,
            "time" => time(),
            "fields" => $fields
        ];

        $req = $this->uniredRequest->paymentInfo(['receiver' => $input]);
        if (!is_null($req->error))
            return $this->getTranslatedMessage($req->error->message);

        return ['items' => $req->response->response ?? [], 'info_id' => $req->id];
    }

    public function create(PaymentRequest $request)
    {
        $data = $request->validated();
        $service = $this->paymentServiceRepository->findPaymentService($data['service_id']);

        $params = [
            'currency_code' => UniredCurrencyCodes::UZS,
            'receiver' => [
                'id' => $service->ext_provider_id,
                'service_id' => $service->ext_service_id,
                'time' => time(),
                'fields' => $this->prepareRequestFields($data, $service->amount_field_name)
            ]
        ];

        // if card attached
        if ($data['card_id'] != -1) {
            $params['ref_id'] = $this->creditCardService->getModelById($data['card_id'])->ref_id;
            $request = $this->uniredRequest->paymentCreate($params);
        } // if payment without card
        else
            $request = $this->uniredRequest->paymentCreateWithoutCard($params);

        if ($request->status) {
            $transfer = Transfer::query()->create([
                "user_id" => auth()->user()->id,
                "credit_card_id" => $data['card_id'] == -1 ? null : $data['card_id'],
                "service_id" => $service->id,
                "provider_id" => $service->ext_provider_id,
                "info_request_id" => $data['info_id'],
                "amount" => $data['amount'],
                "request" => $this->makeRequest($data, $service),
                "commissions" => $this->uniredRequestRepository->getLastCommission('commission_payment')
            ]);

            $this->transferService->updateUniredCallbackAttributes($request->response, $transfer);
            return $request->response;
        }

        return $this->getTranslatedMessage($request->error->message);
    }

    private function makeRequest(array $data, \Modules\Unired\Models\PaymentService $service): array
    {
        $data['provider_id'] = $service->payment_group_id;

        return $data;
    }

    public function prepareRequestFields($data, $amount_field_name): array
    {
        $fields = [];
        foreach ($data['fields'] as $field) {
            /** @var ServiceField $service_field */
            $service_field = $this->serviceFieldService->getModelById($field['field_id']);
            $fields[$service_field->name] = !$service_field->isSelect() ? $field['value'] :
                $service_field->getValue($field['value'])->external_id;
        }
        $fields[$amount_field_name] = (int) $data['amount'];
        return $fields;
    }

    public function updateUniredCallbackAttributes($response, Transfer $transfer)
    {
        $data = [
            "ext_id" => $response->payment->ext_id,
            'debit_state' => $response->payment->debit->state,
            "credit_description" => $response->payment->credit->description,
            'credit_state' => $response->payment->credit->state,
        ];

        if (!$transfer->update($data)) {
            \Log::error('update callback transfer');
        };
    }

    private function getTranslatedMessage($message): string
    {
        return trans($message->en ?? $message);
    }
}
