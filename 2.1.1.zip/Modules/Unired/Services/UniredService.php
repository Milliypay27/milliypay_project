<?php

namespace Modules\Unired\Services;

use App\Models\AdminUser;
use App\Models\User;
use Modules\Unired\Constants\AppConstant;
use Modules\Unired\Http\Requests\TransferRequest;

use Modules\Unired\Models\CreditCard;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Models\TransferSender;
use Modules\Unired\Models\UniredRequest;

use Modules\Unired\Repositories\CreditCardRepository;
use Modules\Unired\Repositories\UniredRequestRepository;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class UniredService
{
    protected TransferService $transferService;
    protected UniredRequestRepository $uniredRequestRepository;
    protected CreditCardRepository $creditCardRepository;

    public function __construct()
    {
        $this->transferService = new TransferService();
        $this->uniredRequestRepository = new UniredRequestRepository();
        $this->creditCardRepository = new CreditCardRepository();
    }

    public function getLastCommissions()
    {
        return $this->uniredRequestRepository->getLastCommissions();
    }

    public function getCommissionsByColumn($column_name)
    {
        if (is_null($this->uniredRequestRepository->getLastCommissions()))
            return [];
        $data = (array)$this->uniredRequestRepository->getLastCommissions()->response;
        $commissions = [];
        if (array_key_exists($column_name, $data)) {
            $commissions = $data[$column_name];
        }
        return $commissions;
    }


    public function syncCommissions()
    {
        return $this->makeRequest(AppConstant::UNIRED_TRANSFER_CHECK_SERVICE_METHOD, [], auth()->user());
    }

    public function makeRequest($method, array $params, ?object $user, bool $paymentInfo = false, bool $cardState = false)
    {
        $request = $this->logUniredRequest($method, $params, $user);
        $access_token =  cache()->remember('unired_access_token', 60*60*24, function () use ($user) {
            return $this->getAccessToken($user);
        });

        $token = $paymentInfo ? env('UNIRED_PAYMENT_INFO_TOKEN') : $access_token->response->access_token;
        $url = $paymentInfo ? env('UNIRED_API_PAYMENT_INFO') : env('UNIRED_API_SERVER');

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->acceptJson()->post($url, [
            'jsonrpc' => "2.0",
            'id' => $request->id,
            'method' => $method,
            'params' => $params
        ]);

        $res = $response->json();

        if (is_null($res)) {
            Log::log('error', UniredService::class . '->makeRequest() Response status '.$response->status()??'' .$response->toException() ? $response->toException()->getMessage() : '');
            return $request;
        }

        if (array_key_exists('status', $res) and array_key_exists('error', $res)) {
            if (!$res['status'] && isset($res['error']['message']) && isset($res['error']['message']['en']) && $res['error']['message']['en'] === 'Invalid token') {
                $this->getAccessToken($user, false);
                return $this->makeRequest($method, $params, $user, $paymentInfo);
            }
        }

        $request->update([
            'response' => $res['result'] ?? null,
            'error' => $res['error'] ?? null,
            'status' => $res['status'] ?? null,
            'remote_timestamp' => array_key_exists('host', $res) ? $res['host']['time_stamp'] : null
        ]);

        if ($cardState) {
            return $res;
        }

        return $request;
    }

    public function logUniredRequest($method, $params, $user)
    {
        if ($user instanceof User) {
            $user_id = $user->id;
        } elseif ($user instanceof AdminUser) {
            $admin_id = $user->id;
        }
        return UniredRequest::query()->create([
            'method' => $method,
            'params' => $params,
            'user_id' => $user_id ?? null,
            'admin_id' => $admin_id ?? null
        ]);
    }

    public function getAccessToken($user, bool $true = true)
    {
        $params = [
            "login" => env('UNIRED_LOGIN'),
            "password" => env('UNIRED_PASSWORD')
        ];
        $method = AppConstant::UNIRED_LOGIN_METHOD;

        $request = null;
        if ($true) {
            $request = UniredRequest::query()->where('method', '=', $method)->orderByDesc('created_at')->first();
        }

        if (!$request || !$request->response || !$request->response->access_token) {
            $request = $this->logUniredRequest($method, $params, $user);

            $response = Http::acceptJson()->post(env('UNIRED_API_SERVER'), [
                "id" => $request->id,
                "method" => $method,
                "params" => $params
            ]);
            $res = $response->json();

            $request->update([
                'response' => $res['result'] ?? null,
                'error' => $res['error'] ?? null,
                'status' => $res['status'] ?? null,
                'remote_timestamp' => $res['host']['time_stamp']
            ]);
        }
        return $request;
    }

    public function paymentInfo(array $params)
    {
        return $this->makeRequest(AppConstant::UNIRED_PAYMENT_SERVICE_INFO, $params, auth()->user(), true);
    }

    public function paymentCreate(array $params)
    {
        return $this->makeRequest(AppConstant::UNIRED_PAYMENT_CREATE, $params, auth()->user());
    }

    public function paymentCreateWithoutCard(array $params)
    {
        return $this->makeRequest(AppConstant::UNIRED_PAYMENT_CREATE_WITHOUT_CARD, $params, auth()->user());
    }

    public function getAllPaymentService($user)
    {
        return $this->makeRequest(AppConstant::UNIRED_PAYMENT_SERVICE, [], $user);
    }

    public function checkReceipt(TransferRequest $transferRequest, $user): ?array
    {
        $request = $this->makeRequest(
            AppConstant::UNIRED_TRANSFER_CHECK_METHOD,
            [
                "card_number" => $transferRequest->post('card_number'),
                "currency_code" => AppConstant::UNIRED_RUBLE_CURRENCY
            ],
            $user
        );

        if ($request->status) {
            $request->response->amount->origin = (string) $request->response->amount->origin;
            $response = (array)($request->response);
            $response['info_id'] = $request->id;
            return $response;
        }
        return null;
    }

    public function checkService($user)
    {
        $request = $this->makeRequest(
            AppConstant::UNIRED_TRANSFER_CHECK_SERVICE_METHOD,
            [],
            $user
        );

        if ($request->status) {
            return $request->response;
        }
        return null;
    }

    public function creditCardRequestLink($user)
    {
        $request = $this->makeRequest(AppConstant::UNIRED_CARD_ADD_METHOD, [], $user);

        if ($request->status) {
            CreditCard::query()->create([
                'user_id' => $user->id,
                'order_id' => $request->response->order_id,
                'ext_id' => $request->response->ext_id,
                'description' => $request->response->description,
                'state' => $request->response->state
            ]);

            return $request->response->form_url;
        }

        return $request;
    }

    public function creditCardState(string $ext_id, $user)
    {

        return $this->makeRequest(
            AppConstant::UNIRED_CARD_STATE_METHOD, [
                'ext_id' => $ext_id
            ],
            $user, false, true
        );
    }

    public function removeCard(string $refId, $user)
    {
        $request = $this->makeRequest(AppConstant::UNIRED_CARD_REMOVE_METHOD, ['ref_id' => $refId], $user);
        if ($request->status) {
            $this->creditCardRepository->updateAllByRefId(['state' => $request->response->state], $refId);
        }
        return $request->status;
    }

    public function createTransfer(TransferRequest $transferRequest, $user)
    {
        $request = $this->makeRequest(
            AppConstant::UNIRED_TRANSFER_CREATE_METHOD,
            [
                "ref_id" => intval($transferRequest->card->ref_id) ?? -1,
                "amount" => $transferRequest->amount * 100,
                "currency_code" => AppConstant::UNIRED_UZS_CURRENCY,
                "receiver" => [
                    "card_number" => $transferRequest->card_number
                ]
            ],
            $user
        );

        if ($request->status) {
//            $transferSender = TransferSender::create($transferRequest->sender);

            $transfer = Transfer::query()->create([
                "user_id" => $user->id,
                "credit_card_id" => $transferRequest->card_id,
                "credit_card_number" => $transferRequest->card_number,
                "amount" => $transferRequest->amount,
                "info_request_id" => $transferRequest->info_id,
                "request" => $transferRequest->validated(),
                "commissions" => $this->uniredRequestRepository->getLastCommission('commissions'),
                "sender" => $transferRequest->sender,
//                'transfer_sender_id' => $transferSender->id,
                "cash_type" => "tkb"
            ]);

            $this->transferService->updateUniredCallbackAttributes($request->response, $transfer);
            return $request->response;
        }

        return $this->getTranslatedMessage($request->error->message);
    }

    public function transferState(array $params)
    {
        return $this->makeRequest(AppConstant::UNIRED_TRANSFER_STATE, $params, auth()->user());
    }

    public function paymentState(array $params)
    {
        return $this->makeRequest(AppConstant::UNIRED_PAYMENT_STATE, $params, auth()->user());
    }

    protected function getTranslatedMessage($message)
    {
        if (is_string($message))
            return trans($message);

        return trans($message->en);
    }
}
