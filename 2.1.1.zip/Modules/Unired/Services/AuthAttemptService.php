<?php

namespace Modules\Unired\Services;

use Modules\Unired\Models\AuthAttempt;
use Modules\Unired\Repositories\BaseRepository;

class AuthAttemptService extends BaseService
{
    public function __construct()
    {
        $this->repository = new BaseRepository(AuthAttempt::class);
    }
}
