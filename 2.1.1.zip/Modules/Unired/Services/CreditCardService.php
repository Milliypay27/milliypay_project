<?php

namespace Modules\Unired\Services;

use Modules\Unired\Constants\CreditCardState;
use Modules\Unired\Models\CreditCard;
use Modules\Unired\Repositories\CreditCardRepository;

class CreditCardService extends BaseService
{
    private UniredService $uniredService;

    public function __construct()
    {
        $this->repository = new CreditCardRepository();
        $this->uniredService = new UniredService();
    }

    public function bindCardCallbackAttributes(CreditCard $creditCard, array $input)
    {
        $creditCard->state = $input['result']['state'];
        $creditCard->description = $input['result']['description'];

        if ($input['result']['card']) {
            $card = $input['result']['card'];
            $creditCard->name = $card['owner'];
            $creditCard->bank = $card['bank'];
            $creditCard->number = $card['number'];
            $creditCard->expire = $card['expire'];
            $creditCard->ref_id = $card['ref_id'];
            $creditCard->owner = $card['owner'];
            $creditCard->provider= $card['provider'];
        }
        $creditCard->save();
        if ($creditCard->state == CreditCardState::ERROR && $refIdPos = strpos($creditCard->description, "CardRefId")) {
            $refId = substr($creditCard->description, $refIdPos + strlen('CardRefId='));
            $this->uniredService->removeCard($refId, null);
        }
    }

    public function getActiveCardsByUserId(int $user_id)
    {
        return $this->repository->findActiveCardsByUserId($user_id);
    }
}
