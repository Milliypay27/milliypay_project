<?php


namespace Modules\Unired\Services;


use Modules\Unired\Models\ServiceField;
use Modules\Unired\Models\ServiceFieldPrefix;
use Modules\Unired\Models\ServiceFieldValue;
use Modules\Unired\Repositories\BaseRepository;

/**
 * CLASS ServiceFieldService
 * @author Izzat Madaminov
 */
class ServiceFieldService extends BaseService
{
    private BaseRepository $serviceFieldPrefixRepository;
    private BaseRepository $serviceFieldValueRepository;

    public function __construct()
    {
        $this->repository = new BaseRepository(ServiceField::class);
        $this->serviceFieldPrefixRepository = new BaseRepository(ServiceFieldPrefix::class);
        $this->serviceFieldValueRepository = new BaseRepository(ServiceFieldValue::class);
    }

    public function paginatedList($data = [])
    {
        return $this->repository->paginatedList($data,'paymentService');
    }

    public function getPrefixesByFieldId($service_field_id)
    {
        return $this->repository->findById($service_field_id)->prefixes;
    }

    public function createPrefix(array $data)
    {
        return $this->serviceFieldPrefixRepository->create($data);
    }

    public function updatePrefix(array $data, $service_field_prefix_id)
    {
        return $this->serviceFieldPrefixRepository->update($data, $service_field_prefix_id);
    }

    public function deletePrefix($service_field_prefix_id)
    {
        return $this->serviceFieldPrefixRepository->delete($service_field_prefix_id);
    }

    public function getValuesByFieldId($service_field_id)
    {
        return $this->repository->findById($service_field_id)->values;
    }

    public function createServiceFieldValue(array $data)
    {
        return $this->serviceFieldValueRepository->create($data);
    }

    public function updateServiceFieldValue(array $data, $service_field_value_id)
    {
        return $this->serviceFieldValueRepository->update($data, $service_field_value_id);
    }

    public function deleteServiceFieldValue($service_field_value_id)
    {
        return $this->serviceFieldValueRepository->delete($service_field_value_id);
    }


}
