<?php

namespace Modules\Unired\Services;

use App\Models\OfdResponse;
use Exception;
use Log;
use Modules\Unired\Constants\TransferCreditStatuses;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Models\Transfer;

/**
 * @property string $base_uri
 * @property string $spic
 * @property int $units
 * @property int $VATPercent
 * @property string $dateFormat
 * @property string $crt
 * @property string $key
 */
class OfdService
{
    public function __construct()
    {
        $this->base_uri = config('services.ofd.prod.url');
        $this->spic = config('services.ofd.prod.spic');
        $this->units = config('services.ofd.prod.units');
        $this->VATPercent = config('services.ofd.prod.VATPercent');

        $this->crt = config('services.ofd.prod.crt');
        $this->key = config('services.ofd.prod.key');
        $this->dateFormat = 'Y-m-d H:i:s';
    }

    public function run(Transfer $transfer)
    {
        try {
            $file = $this->createJsonFile($transfer);
            if ($file) {
                $outFile = $this->openSSLSing();
                if ($outFile) {
                    if ($response = $this->sendFileToOfd()) {
                        $this->save($response, $transfer);
                    }

                    return false;
                }
            }
        } catch (Exception $exception) {
            Log::error('ofd error: ' . $exception->getMessage());
        }

        return false;
    }

    public function createJsonFile(Transfer $transfer)
    {
        $receipt_id = (int)(microtime(true) * 100);

        $amount = $transfer->credit_amount;
        $name = $transfer->service->payment_group->title_en;
        $category_id = $transfer->service->payment_group->category_id;
        $spic = $this->getSpicByCategoryId($category_id);


        $path = storage_path('ofd/files');
        $file = "{$path}/receipt.json";

        $receipt = [
            "Items" => [
                [
                    "Name" => $name,
                    "SPIC" => $spic,
                    "Units" => $this->units,
                    "GoodPrice" => $amount,
                    "Amount" => 1,
                    "Price" => $amount,
                    "VAT" => (int)$this->calcVat($amount),
                    "VATPercent" => $this->VATPercent,
                    "CommissionInfo" => [
                        "TIN" => "203556638",
                        "PINFL" => ""
                    ]
                ]
            ],
            "ReceiptId" => $receipt_id,
            "ReceivedCard" => $amount,
            "ReceivedCash" => 0,
            "IsRefund" => 0,
            "Time" => date($this->dateFormat),
            "ReceiptType" => 0,
            "TotalVAT" => (int)$this->calcVat($amount),
//            "ExtraInfo" => [
//                "PhoneNumber" => auth('api')->user()->phone ?? '',
//                "Other" => ""
//            ]
        ];

        $content = json_encode($receipt, true);

        if (!is_dir($path)) {
            mkdir($path);
        }

        if (file_put_contents($file, $content))
            return $file;

        return false;
    }

    public function getSpicByCategoryId($category_id): string
    {
        if (!empty($this->spicList()[$category_id])) {
            return $this->spicList()[$category_id];
        }

        return '10403999007000000';
    }

    public function spicList()
    {
        // TODO bazaga ko'chirish kerak

        return [
            1 => '10304008002000000', // Мобильные операторы
            2 => '10304003005000000', // Интернет провайдеры
            3 => '10713007006000000', // Коммунальные услуги
            4 => '10304017004000000', // Телевидение
            5 => '11199008005000011', // Гос. услуги
            6 => '11199001111000000', // Благотворительность
//            6 => '11199008010000000', // Телефония
//            7 => '10403999007000000', // Интернет ресурсы aniqlik kiritish kk
//            8 => '03926999260000000', // Транспорт
//            9 => '10403999007000000', // Развлечение aniqlik kiritish kk
//            14 => '10403999007000000', // Прочее
        ];
    }

    public function calcVat($price)
    {
        return $price * $this->VATPercent / (100 + $this->VATPercent);
    }

    public function openSSLSing(): string
    {
        $path = storage_path('ofd/files');
        $inFile = "{$path}/receipt.json";
        $outFile = "{$path}/receipt.p7b";
        $crtFile = $this->crt;
        $keyFile = $this->key;

//        shell_exec("openssl cms -sign -nodetach -binary -in {$inFile} -text -outform der -out {$outFile} -nocerts -signer {$crtFile} -inkey {$keyFile}");

        openssl_cms_sign(
            $inFile,
            $outFile,
            'file://' . $crtFile,
            'file://' . $keyFile,
            null,
            OPENSSL_CMS_NOCERTS,
            OPENSSL_ENCODING_DER
        );

        return $outFile;
    }

    public function sendFileToOfd()
    {
        $path = storage_path('ofd/files');
        $outFile = "{$path}/receipt.p7b";

        try {
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => $this->base_uri,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 5,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => file_get_contents($outFile),
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/octet-stream'
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);

//            Log::error('ofd curl error: ' . $response);

            return json_decode($response, true);
        } catch (Exception $e) {
//            Log::error('ofd curl error: ' . $e->getMessage());
            return false;
        }
    }

    public function save($response, Transfer $transfer): bool
    {
        $model = new OfdResponse();
        $model->code = $response["Code"] ?? null;
        $model->transfer_id = $transfer->id;
        $model->user_id = auth('api')->id() ?? 26;
        $model->message = $response["Message"] ?? null;
        $model->terminal_id = $response["TerminalID"] ?? null;
        $model->receipt_id = $response["ReceiptId"] ?? null;
        $model->datetime = $response["DateTime"] ?? null;
        $model->fiscal_sign = $response["FiscalSign"] ?? null;
        $model->qr_code_url = $response["QRCodeURL"] ?? null;

        return $model->save();
    }

    public function sendPayment(Transfer $transfer, int $debit_state, int $credit_state)
    {
        if ($this->checkPaymentSuccess($debit_state, $credit_state)) {
            $this->run($transfer);
        }
    }

    public function checkPaymentSuccess(int $debit_state, int $credit_state): bool
    {
        return
            ($debit_state == TransferDebitStatuses::SUCCESS_3) and
            ($credit_state == TransferCreditStatuses::PAYMENT_SUCCESS);
    }
}
