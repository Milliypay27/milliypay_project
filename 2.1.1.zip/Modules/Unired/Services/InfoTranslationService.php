<?php

namespace Modules\Unired\Services;

use Modules\Unired\Models\InfoTranslation;
use Modules\Unired\Repositories\BaseRepository;

class InfoTranslationService extends BaseService
{
    public function __construct()
    {
        $this->repository = new BaseRepository(InfoTranslation::class);
    }

}
