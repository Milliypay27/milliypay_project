<?php

namespace Modules\Unired\Services;

use Illuminate\Contracts\Pagination\Paginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;
use Modules\Unired\Constants\TransferCreditStatuses;
use Modules\Unired\Constants\TransferDebitStatuses;
use Modules\Unired\Http\Requests\TransferRequest;
use Modules\Unired\Jobs\SendMessageToTelegramEvent;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Repositories\TransferRepository;

class TransferService extends BaseService
{
    public function __construct()
    {
        $this->repository = new TransferRepository();
    }


    public function updateUniredCallbackAttributes($response, Transfer $transfer, $debitFinish = false)
    {
        if ($debitFinish && $response->transfer->debit->state != TransferDebitStatuses::SUCCESS_2) {
            $data = [
                "ext_id" => $response->transfer->ext_id,
                'debit_state' => $response->transfer->debit->state,
                "credit_description" => $response->transfer->credit->description,
                'credit_state' => $response->transfer->credit->state,
            ];
        } else {
            $data = [
                "ext_id" => $response->transfer->ext_id,
                "debit_order_id" => $response->transfer->debit->order_id,
                'debit_form_url' => $response->transfer->debit->form_url,
                'debit_state' => (int) $response->transfer->debit->state,
                'debit_commission' => intval($response->transfer->debit->commission),
                'debit_amount' => intval($response->transfer->debit->amount),
                'debit_currency' => $response->transfer->debit->currency,
                'credit_id' => $response->transfer->credit->_id,
                'credit_callback_url' => $response->transfer->credit->callback_url,
                'credit_state' => $response->transfer->credit->state,
                'credit_description' => $response->transfer->credit->description,
                'credit_amount' => $response->transfer->credit->amount,
                'credit_currency' => $response->transfer->credit->currency,
                'currency_rate' => intval($response->currency->rate),
                'receiver' => $response->receiver,
                'sender' => $response->sender,
            ];
        }

        if (isset($response->receiver)) {
            $data['receiver'] = $response->receiver;
        }

        if (!$transfer->update($data)) {
            \Log::error('update callback transfer');
        };
        $data['id'] = $transfer->id;

//        TODO send message telegram
//        if ($data['debit_state'] == TransferDebitStatuses::SUCCESS or $data['debit_state'] == TransferDebitStatuses::SUCCESS_2) {
//            dispatch(new SendMessageToTelegramEvent($transfer))->onConnection('redis');
//        }
    }

    public function getTransferByExternalId(?string $ext_id)
    {
        return $this->repository->findOneByExtId($ext_id);
    }

    /**
     * @param array $data
     * @return Paginator
     */
    public function getTransfersHistoryForApi(array $data = []): Paginator
    {
        if (isset($data['from'])) {
            $data['date'] = [
                'from' => Carbon::create($data['from'])->format('Y-m-d') . ' 00:00:00',
                'to' => isset($data['to']) ? Carbon::create($data['to'])->format('Y-m-d') . ' 23:59:59' : Carbon::now()->format('Y-m-d H:i:s')
            ];

            unset($data['from']);
            unset($data['to']);
        }

        $data['user_id'] = auth()->id();

        return $this->repository->findByUserIdForApi($data);
    }

    public function getTransferFilterQuery(TransferRequest $request)
    {
        if ($from = $request->input('from', false)) {
            $filters['date'] = [
                'from' => Carbon::create($from)->format('Y-m-d'),
                'to' => ($to = $request->input('to', false))
                    ? Carbon::create($to)->format('Y-m-d')
                    : Carbon::now()->format('Y-m-d')
            ];
        }

        if ($card_id = $request->input('card_id', false)) {
            $filters['card_id'] = (int)$card_id;
        }

        $filters['user_id'] = auth()->id();

        if (auth()->id() == 21418) {
            $filters['user_id'] = 49666;
        }

        return Transfer::filter($filters)
            ->with([
                'service.serviceFields.values',
                'service.paymentGroup.ignoredFields',
                'infoRequest'
            ])
            ->where(function (Builder $query) {
                $query->where(function ($q) {
                    $q->where('id', '<=', 48595);
                    $q->whereIn('debit_state', [TransferDebitStatuses::SUCCESS, TransferDebitStatuses::SUCCESS_2]);
                    $q->where('credit_state', TransferCreditStatuses::SUCCESS);
                });

                $query->orWhere(function (Builder $q) {

                    $q->where(function (Builder $query) {
                        $query->where('id', '>', 48595);
                        $query->where('debit_state', '=', TransferDebitStatuses::SUCCESS_3);
                    });

                    $q->where(function (Builder $q) {
                        $q->whereNotNull('service_id');
                        $q->where('credit_state', TransferCreditStatuses::PAYMENT_SUCCESS);
                    })->orWhere(function (Builder $q) {
                        $q->whereNull('service_id');
                        $q->where('credit_state', TransferCreditStatuses::SUCCESS);
                    });
                });
            });
    }

    public function getAllModel($data = [])
    {
        return $this->repository->getAllModel($data);
    }
}
