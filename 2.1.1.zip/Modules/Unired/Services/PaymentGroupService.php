<?php

namespace Modules\Unired\Services;

use Modules\Unired\Helpers\PathHelper;
use Modules\Unired\Models\BaseModel;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Repositories\BaseRepository;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;


class PaymentGroupService extends BaseService
{
    public function __construct()
    {
        $this->repository = new BaseRepository(PaymentGroup::class);
    }


    /**
     * @throws Exception
     */
    public function paginatedList($data = [])
    {
        return $this->repository->paginatedList($data,'paymentCategory');
    }

    /**
     * @param $data
     * @return BaseModel|BaseModel[]|Builder|Builder[]|Collection|Model|null
     * @throws Exception
     */
    public function createModel($data)
    {
        $data['image'] = PathHelper::createPath('payment_groups', $data['image']);
        return $this->repository->create($data);
    }

    public function updateModel($data, $id)
    {
        /*** @var PaymentGroup $model */
        $model = $this->repository->findById($id);
        if (isset($data['image'])) {
            PathHelper::deletePath($model->image);
            $data['image'] = PathHelper::createPath('payment_groups', $data['image']);
        }
        return $this->repository->update($data, $id);
    }

    public function deleteModel($id)
    {
        /*** @var PaymentGroup $model */
        $model = $this->repository->findById($id);
        PathHelper::deletePath($model->image);
        return $this->repository->delete($id);
    }

    public function getModelByServiceId($serviceId)
    {
        return PaymentGroup::query()->whereHas('paymentServices', function ($q) use ($serviceId) {
            return $q->where('id', $serviceId);
        })->first();
    }
}
