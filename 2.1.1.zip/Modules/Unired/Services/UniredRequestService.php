<?php

namespace Modules\Unired\Services;

use Illuminate\Support\Collection;
use Modules\Unired\Constants\AppConstant;
use Modules\Unired\Http\Requests\UniredServiceRequest;
use Modules\Unired\Models\UniredRequest;
use Modules\Unired\Repositories\UniredRequestRepository;

class UniredRequestService extends BaseService
{
    private UniredService $uniredService;

    public function __construct()
    {
        $this->repository = new UniredRequestRepository();
        $this->uniredService = new UniredService();
    }

    public function createModelWithMethodAndResponse(string $method, array $response)
    {
        return $this->repository->createWithMethodAndResponse($method, $response);
    }

    public function getServiceField(int $provider, int $service)
    {
        $uniredRequest = UniredRequest::query()->where('method', '=', AppConstant::UNIRED_PAYMENT_SERVICE)
            ->whereNotNull('response')->orderByDesc('created_at')->first();

        $fields = collect();
        foreach ((array)$uniredRequest->response->categories as $item) {
            foreach ((array)$item->providers as $provid) {
                if ($provid->id === $provider) {
                    foreach ((array)$provid->services as $servic) {
                        if ($servic->id === $service) {
                            $fields->push($servic->fields);
                        }
                        if (!empty($servic->services))
                            foreach ($servic->services as $childService) {
                                if ($childService->id === $service) {
                                    $fields->push($childService->fields);
                                    break;
                                }
                            }
                        if ($fields->count() > 0)
                            break;
                    }
                    break;
                }
            }
        }
        return $fields[0];
    }

    public function getAllPaymentService(UniredServiceRequest $request)
    {
        $uniredRequest = UniredRequest::query()->where('method', '=', AppConstant::UNIRED_PAYMENT_SERVICE)->whereStatus(null)->whereNotNull('response')->orderByDesc('created_at')->first();

        if (!$uniredRequest) {
            $uniredRequest = $this->uniredService->getAllPaymentService(auth('admin')->user());
        }

        $services = collect();
        if (!is_null($uniredRequest->response)) {
            foreach ((array)$uniredRequest->response->categories as $provider) {
                foreach ((array)$provider->providers as $item) {
                    $services->push($item);
                }
            }
        }

        if ($title = $request->query('payment_service')) {
            return $services->filter(function ($item) use ($title) {
                return stristr($item->title, $title);
            });
        }

        return $services;
    }
}
