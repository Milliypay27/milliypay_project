<?php

namespace Modules\Unired\Services;

use Illuminate\Support\Collection;
use Modules\Unired\Constants\AppConstant;
use Modules\Unired\Models\PaymentGroup;
use Modules\Unired\Models\UniredRequest;
use Modules\Unired\Repositories\BaseRepository;
use Modules\Unired\Repositories\PaymentServiceRepository;


class PaymentServiceService extends BaseService
{
    private BaseRepository $paymentGroupRepository;

    public function __construct()
    {
        $this->repository = new BaseRepository(\Modules\Unired\Models\PaymentService::class);
        $this->paymentGroupRepository = new BaseRepository(PaymentGroup::class);
    }

    public function paginatedList($data = [])
    {
        return $this->repository->paginatedList($data, 'paymentGroup');
    }

    public function createModel($data)
    {
        if (!array_key_exists('payment_group', $data) or is_null($data['payment_group'])) {

            $paymentGroup = $this->paymentGroupRepository->create([
                'title_uz' => $data['title_short'],
                'title_oz' => $data['title_short'],
                'title_ru' => $data['title_short'],
                'title_en' => $data['title_short'],
                'image' => $data['image'] ?? 'no-image.jpg',
                'category_id' => $data['category_id'],
                'order' => 0
            ]);
        } else {
            /** @var PaymentGroup $paymentGroup */
            $paymentGroup = $this->paymentGroupRepository->findById($data['payment_group']);
            if (isset($data['image']))
                $this->paymentGroupRepository->update(['image' => $data['image']], $paymentGroup->id);
        }

        $data['order'] = $paymentGroup->count('order') ?? 0;

        return $this->repository->create([
            'ext_service_id' => $data['ext_service_id'],
            'ext_info_id' => $data['ext_info_id'],
            'ext_provider_id' => $data['ext_provider_id'],
            'amount_field_name' => $data['amount_field_name'],
            'min_amount' => $data['min_amount'],
            'max_amount' => $data['max_amount'],
            'title_oz' => $data['title'],
            'title_uz' => $data['title'],
            'title_en' => $data['title'],
            'title_ru' => $data['title'],
            'payment_group_id' => $paymentGroup->id,
            'order' => $data['order']
        ]);
    }

    public function getFirst(int $id, int $service): Collection
    {
        $uniredRequest = UniredRequest::query()->where('method', '=', AppConstant::UNIRED_PAYMENT_SERVICE)->whereNotNull('response')->orderByDesc('created_at')->first();
        $paymentService = collect();
        foreach ((array)$uniredRequest->response->categories as $provider) {
            foreach ((array)$provider->providers as $item) {
                if ($item->id == $id) {
                    $paymentService->put('provider', $item);
                    foreach ((array)$item->services as $ser) {
                        if ($service == $ser->id) {
                            $paymentService->put('service', $ser);
                            foreach ($ser->fields as $field) {
                                if ($field->fieldType == 'MONEY')
                                    $paymentService->put('amountFieldName', $field->name);
                            }
                        } else {
                            $paymentService->put('probablyInfoService', $ser);
                        }
                        if (!empty($ser->services))
                            foreach ($ser->services as $childService) {
                                if ($service == $childService->id) {
                                    $paymentService->put('service', $childService);
                                    foreach ($childService->fields as $field) {
                                        if ($field->fieldType == 'MONEY')
                                            $paymentService->put('amountFieldName', $field->name);
                                    }
                                } else {
                                    $paymentService->put('probablyInfoService', $childService);
                                }
                            }
                    }
                }
            }
        }

        return $paymentService;
    }

    public function getPaymentServices()
    {
        return (new PaymentServiceRepository())->getPaymentServices();
    }
}
