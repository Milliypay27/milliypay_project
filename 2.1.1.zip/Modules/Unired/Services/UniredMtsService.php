<?php

namespace Modules\Unired\Services;

use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Modules\Unired\Constants\AppConstant;
use Modules\Unired\Constants\UniredCurrencyCodes;
use Modules\Unired\Http\Requests\PaymentRequest;
use Modules\Unired\Http\Requests\TransferRequest;
use Modules\Unired\Models\ServiceField;
use Modules\Unired\Models\Transfer;
use Modules\Unired\Models\UniredRequest;
use Modules\Unired\Repositories\PaymentServiceRepository;
use Str;

class UniredMtsService extends UniredService
{
    /**
     * @throws Exception
     */
    public function checkReceipt(TransferRequest $transferRequest, $user): ?array
    {
        $request = $this->makeRequest(
            AppConstant::UNIRED_MTS_GET_RECEIVER_OWNER,
            [
                "number" => $transferRequest->post('card_number'),
            ],
            $user
        );

        if ($request->status) {
//            $request->response->amount->origin = (string) $request->response->amount->origin;

            $response['owner'] = $request->response->owner ?? null;
            $response['bank'] = $request->response->bank ?? "";
            $response['state'] = $request->response->state ?? null;
            $response['info_id'] = $request->id;
            $response['status'] = true;

            return $response;
        } else {
            $response['status'] = false;
            $response['message'] = __($request->error->message ?: 'Servis vaqtincha ishlamayabdi');

            return $response;
        }

        if (isset($request->error->code) && $request->error->code == 301) {
            return null;
        }

        if (isset($request->error->message)) throw new Exception(__($request->error->message));

        throw new Exception(__('Servis vaqtincha ishlamayabdi'));
    }

    public function makeRequest($method, array $params, ?object $user, bool $paymentInfo = false, bool $cardState = false)
    {
        $request = $this->logUniredRequest($method, $params, $user);
        $access_token = cache()->remember('unired_mts_access_token', 60*60*24, function () use ($user) {
            return $this->getAccessToken($user);
        });

        $token = $access_token->response->access_token;
        $url = config('services.unired-mts.base_url');

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->acceptJson()->post($url, [
            'jsonrpc' => "2.0",
            'id' => $request->id,
            'method' => $method,
            'params' => $params
        ]);

        $res = $response->json();

        if (is_null($res)) {
            Log::log('error', UniredService::class . '->makeRequest() Response status ' . $response->status() ?? '' . $response->toException() ? $response->toException()->getMessage() : '');
            return $request;
        }

        if (array_key_exists('status', $res) and array_key_exists('error', $res)) {
            if (!$res['status'] && isset($res['error']['message']) && isset($res['error']['message']['en']) && $res['error']['message']['en'] === 'Invalid token') {
                $this->getAccessToken($user, false);
                return $this->makeRequest($method, $params, $user, $paymentInfo);
            }
        }

        $request->update([
            'response' => $res['result'] ?? null,
            'error' => $res['error'] ?? null,
            'status' => $res['status'] ?? null,
            'remote_timestamp' => array_key_exists('host', $res) ? $res['host']['timestamp'] : null
        ]);

        if ($cardState) {
            return $res;
        }

        return $request;
    }

    public function getAccessToken($user, bool $true = true)
    {
        $params = [
            "username" => config('services.unired-mts.login'),
            "password" => config('services.unired-mts.password')
        ];

        $request = null;
        if ($true) {
            $request = UniredRequest::query()
                ->where('method', 'mts.login')
                ->where('status', true)
                ->orderByDesc('created_at')
                ->first();
        }

        if (!$request || !$request->response || !$request->response->access_token) {
            $request = $this->logUniredRequest('mts.login', $params, $user);

            $response = Http::withHeaders([
                'Accept' => 'Application/json',
                'Content-type' => 'Application/json'
            ])->post(config('services.unired-mts.base_url'), [
                "jsonrpc" => "2.0",
                "id" => $request->id,
                "method" => AppConstant::UNIRED_LOGIN_METHOD,
                "params" => $params
            ]);

            $res = $response->json();

            $request->update([
                'response' => $res['result'] ?? null,
                'error' => $res['error'] ?? null,
                'status' => $res['status'] ?? null,
                'remote_timestamp' => $res['host']['timestamp'] ?? now()->toString()
            ]);
        }
        return $request;
    }

    public function getPaymentInfo(PaymentRequest $request)
    {
        $data = $request->all();
        $service = (new PaymentServiceRepository)->findPaymentService($data['service_id']);
        $fields = [];
        foreach ($data['fields'] as $field) {
            $service_field = ServiceField::query()->find($field['field_id']);
            $fields[$service_field->name] = !$service_field->isSelect() ? $field['value'] :
                $service_field->getValue($field['value'])->external_id;
        }
        if (is_null($service->ext_info_id)) {
            return $fields;
        }

        $input = [
//            "id" => $service->ext_provider_id,
            "service" => $service->ext_info_id,
            "fields" => $fields
        ];

        $req = $this->makeRequest(AppConstant::UNIRED_MTS_GET_PAYMENT_INFO, $input, auth()->user());
        if (!is_null($req->error))
            return $this->getTranslatedMessage($req->error->message);

        $res_cheque = false;
        if (isset($req->response)) {
            $res_cheque = $req->response->cheque ?? false;
        }

        if ($res_cheque and !isset($res_cheque->response) and isset($res_cheque->status) and (int)$res_cheque->status != 0) {
            return __($res_cheque->status_text);
        }

        return ['items' => $res_cheque->response, 'info_id' => $req->id];
    }

    /** @throws Exception */
    public function createTransfer(TransferRequest $transferRequest, $user)
    {
        try {
            $commissions = $this->getCommission();
            $rate = $commissions->rate;
        } catch (Exception $exception) {
            Log::error("unired mts get commission: " . $exception->getMessage());
            throw new Exception('Rubl kursini olishda xatolik');
        }

        $amount = $transferRequest->amount * 100;
        if (!$transferRequest->currency || $transferRequest->currency == AppConstant::UNIRED_UZS_CURRENCY) {
            $amount = $amount / $rate;
        }

        $request = $this->makeRequest(
            AppConstant::UNIRED_TRANSFER_CREATE_METHOD,
            [
                "ext_id" => $this->generateExtId('transfer'),
                "amount" => $amount,
                "currency" => AppConstant::UNIRED_RUBLE_CURRENCY,
                "number" => $transferRequest->card_number,
                "ip" => $transferRequest->ip()
            ],
            $user
        );

        if ($request->status) {
            $transfer = Transfer::query()->create([
                "user_id" => $user->id,
                "credit_card_id" => $transferRequest->card_id,
                "credit_card_number" => $transferRequest->card_number,
                "amount" => $amount * $rate / 100,
                "info_request_id" => $transferRequest->info_id,
                "request" => $transferRequest->validated(),
                "commissions" => $commissions,
                "sender" => $transferRequest->sender,
                "cash_type" => "mts"
            ]);

            $this->transferService->updateUniredCallbackAttributes($request->response, $transfer);
            return $request->response;
        }

        return $this->getTranslatedMessage($request->error->message ?? '');
    }

    public function getCommission()
    {
        return cache()->remember(AppConstant::UNIRED_MTS_COMMISSION_CACHE_NAME, 60 * 60 * 24, function () {
            $request = $this->makeRequest(AppConstant::UNIRED_MTS_GET_COMMISSION, [], auth()->user());

            return $request->response;
        });
    }

    private function generateExtId($text = null): string
    {
        /** @var $user User */
        $user = auth()->user();
        $user_id = $user->id;
        $time = time();
        $last_transfer_id = Transfer::whereUserId($user->id)->count() + 1;

        return "milliypay_{$text}_" . $time . Str::random(6);
    }

    public function getAllPaymentService($user)
    {
        return $this->makeRequest(AppConstant::UNIRED_PAYMENT_SERVICE, [], $user);
    }

    public function create(PaymentRequest $request)
    {
        $data = $request->validated();
        $service = \Modules\Unired\Models\PaymentService::query()->find($data['service_id']);
        $ext_id = $this->generateExtId('payment');
        $params = [
            "ext_id" => $ext_id,
            'currency' => UniredCurrencyCodes::UZS,
            'service_id' => (int)$service->ext_service_id,
            'fields' => (new PaymentService())->prepareRequestFields($data, $service->amount_field_name),
            'ip' => $request->ip()
        ];

        $request = (new UniredMtsService())->paymentCreate($params);

        if ($request->status) {
            $transfer = Transfer::query()->create([
                "user_id" => auth()->user()->id,
                "credit_card_id" => $data['card_id'] ?? null,
                "service_id" => $service->id,
                "provider_id" => $service->ext_provider_id,
                "info_request_id" => $data['info_id'],
                "amount" => $data['amount'],
                "request" => $data,
                "commissions" => $this->getPaymentCommission(),
                'ext_id' => $ext_id,
                'debit_order_id' => $request->response->payment->debit->order_id,
                'debit_form_url' => $request->response->payment->debit->form_url,
                'debit_state' => (int)$request->response->payment->debit->state,
                'debit_commission' => intval($request->response->payment->debit->commission),
                'debit_amount' => intval($request->response->payment->debit->amount),
                'debit_currency' => $request->response->payment->debit->currency,
                'credit_id' => $request->response->payment->credit->_id,
                'credit_callback_url' => $request->response->payment->credit->callback_url,
                'credit_state' => $request->response->payment->credit->state,
                'credit_description' => $request->response->payment->credit->description,
                'credit_amount' => $request->response->payment->credit->amount,
                'credit_currency' => $request->response->payment->credit->currency,
                'currency_rate' => intval($request->response->payment->currency->rate),
                'receiver' => $request->response->payment->receiver,
                'sender' => $request->response->payment->sender,
            ]);

            return $request->response->payment;
        }

        return $this->getTranslatedMessage($request->error->message);
    }

    public function paymentCreate(array $params)
    {
        return $this->makeRequest(AppConstant::UNIRED_PAYMENT_CREATE, $params, auth()->user());
    }

    public function getPaymentCommission()
    {
        return cache()->remember(AppConstant::UNIRED_MTS_PAYMENT_COMMISSION_CACHE_NAME, 60 * 60 * 24, function () {
            $request = $this->makeRequest(AppConstant::UNIRED_MTS_GET_PAYMENT_COMMISSION, [], auth()->user());

            return $request->response;
        });
    }
}
