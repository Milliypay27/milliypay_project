<?php

return [
    'name' => 'Auth',
    'default_password' => '123456Aa'
];
