<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

use Modules\Auth\Http\Controllers\AuthController;

Route::prefix('auth')->name('auth.')->middleware(['unired.localization'])->group(function () {
    Route::post('check', [AuthController::class, 'check'])->name('check');

    Route::post('login', [AuthController::class, 'login'])->name('login');

    Route::post('register', [AuthController::class, 'register'])->name('register');
    Route::post('password/reset', [AuthController::class, 'passwordReset'])->name('password.reset');

    Route::post('refresh', [AuthController::class, 'refresh'])->name('refresh');
});
