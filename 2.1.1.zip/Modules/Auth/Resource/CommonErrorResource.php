<?php

namespace Modules\Auth\Resource;

use Illuminate\Http\Resources\Json\JsonResource;

class CommonErrorResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
