<?php


namespace Modules\Auth\Services;


use Defuse\Crypto\Crypto;
use Http;
use Laravel\Passport\Client as OClient;
use Laravel\Passport\RefreshToken;
use Lcobucci\JWT\Token\Parser;


class AuthService
{
    public function getToken($username, $password)
    {
        $oClient = OClient::query()->where('password_client', 1)->first();

        return Http::asForm()->post(env('APP_URL') . '/oauth/token', [
            'grant_type' => 'password',
            'client_id' => $oClient->id,
            'client_secret' => $oClient->secret,
            'username' => $username,
            'password' => $password,
            'scope' => '*',
        ])->json();
    }

    public function refreshToken($refresh_token)
    {
        $oClient = OClient::query()->where('password_client', 1)->first();

        $response = Http::asForm()->post(env('APP_URL') . '/oauth/token', [
            'grant_type' => 'refresh_token',
            'refresh_token' => $refresh_token,
            'client_id' => $oClient->id,
            'client_secret' => $oClient->secret,
            'scope' => '',
        ])->json();

        $app_key = env('APP_KEY');
        $enc_key = base64_decode(substr($app_key, 7));
        try {
            $crypto = Crypto::decryptWithPassword($refresh_token, $enc_key);
            $arr = json_decode($crypto, true);
            if (isset($arr['refresh_token_id'])) {
                $id = $arr['refresh_token_id'];
                $refresh = RefreshToken::query()->find($id);
                if ($refresh) {
                    $refresh->revoked = 0;
                    $refresh->expires_at = now()->addSeconds(5*60);
                    $refresh->save();
                }
            }
        } catch (\Exception $exception){
        }

        return $response;
    }
}
