<?php

namespace Modules\Auth\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * @property-read $phone
 * @property-read $password
 * @property-read $key
*/

class AuthRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
//        $hasPassword = request()->has('password');
        $hasPassword = false;

        return [
//            'phone' => [Rule::requiredIf($hasPassword)],
//            'password' => ['nullable'],
            'key' => [Rule::requiredIf(!$hasPassword)]
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
}
