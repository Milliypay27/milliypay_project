<?php

namespace Modules\Auth\Http\Controllers;

use App\Models\User;
use Illuminate\Routing\Controller;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Modules\Auth\Http\Requests\AuthRequest;
use Modules\Auth\Http\Requests\AuthWithOutPasswordRequest;
use Modules\Auth\Http\Requests\CheckPhoneRequest;
use Modules\Auth\Http\Requests\PasswordRequest;
use Modules\Auth\Http\Requests\RefreshTokenRequest;
use Modules\Auth\Services\AuthService;
use Modules\Otp\Models\OtpSms;
use Throwable;
use Validator;

class AuthController extends Controller
{
    public function check(CheckPhoneRequest $request)
    {
        if (User::wherePhone($request->phone)->exists()) {
            return response(null, 204);
        }

        return response(null, 404);
    }

    public function login(AuthRequest $request, AuthService $service)
    {
//        if ($request->has('password') && $request->password != config('auth.default_password')) {
//            $response = $service->getToken($request->phone, $request->password);
//            return $this->returnWithToken($response);
//        } auth with password

        $otp = OtpSms::where('key', $request->key)->whereIsUsed(false)->firstOrFail();
        $otp->update(['is_used' => true]);

        $response = $service->getToken($otp->phone, config('auth.default_password'));
        return $this->returnWithToken($response);
    }

    private function returnWithToken($response)
    {
        if (isset($response['access_token'], $response['refresh_token'], $response['expires_in'])) {
            return response()->json([
                'accessToken' => $response['access_token'],
                'refreshToken' => $response['refresh_token'],
                'lifeTime' => $response['expires_in']
            ]);
        }

        return response($response, 404);
    }

    /** @throws Throwable */
    public function register(PasswordRequest $request, AuthService $service)
    {

        $otp = OtpSms::where('key', $request->key)->whereIsUsed(false)->firstOrFail();

        $validator = Validator::make(['phone' => $otp->phone], [
            'phone' => Rule::unique('users', 'phone')
        ]);

        throw_if($validator->fails(), ValidationException::withMessages($validator->errors()->toArray()));

        $otp->update(['is_used' => true]);

        $user = User::create(['phone' => $otp->phone, 'password' => bcrypt($request->password ?? config('auth.default_password'))]);
        $response = $service->getToken($user->phone, $request->password ?? config('auth.default_password'));

        return $this->returnWithToken($response);
    }

    public function refresh(RefreshTokenRequest $request, AuthService $service)
    {
        $response = $service->refreshToken($request->refreshToken);

        if (isset($response['access_token'], $response['refresh_token'], $response['expires_in'])) {
            return response()->json([
                'accessToken' => $response['access_token'],
                'refreshToken' => $response['refresh_token'],
                'lifeTime' => $response['expires_in']
            ]);
        }

        \Log::error('refresh error: ' . $request->refreshToken);

        return response()->json([
            'code' => 0,
            'message' =>  __($response['message'] ?? 'Xatolik !')
        ], 400);
    }

    public function passwordReset(PasswordRequest $request, AuthService $service)
    {
        $otp = OtpSms::where('key', $request->key)->whereIsUsed(false)->firstOrFail();
        $otp->update(['is_used' => true]);

        $user = User::wherePhone($otp->phone)->firstOrFail();
        $user->update(['password' => bcrypt($request->password)]);

        $response = $service->getToken($otp->phone, $request->password);

        return $this->returnWithToken($response);
    }
}
