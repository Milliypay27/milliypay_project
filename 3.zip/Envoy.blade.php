@servers(['web' => 'milliypay@dev-api.milliypay.uz'])

@setup
    $repository = 'git@gitlab.com:axrorovaxbor/milliypay-backend.git';
    $build = date('YmdHis');

    $releases_dir = '/home/milliypay/backend/releases';
    $new_release_dir = $releases_dir .'/'. $build;
    $app_dir = '/home/milliypay/backend/app';

    $devs_dir = '/home/milliypay/backend/development';
    $new_dev_dir = $devs_dir .'/'. $build;
    $app_dev_dir = '/home/milliypay/backend/dev-app';
@endsetup

@story('deploy')
    clone_repository
    update_symlinks
    run_composer
@endstory

@story('devdeploy')
    clone_repository_dev
    update_symlinks_dev
    run_composer_dev
@endstory

@task('clone_repository')
    echo 'Cloning repository'
    [ -d {{ $releases_dir }} ] || mkdir {{ $releases_dir }}
    git clone --depth 1 {{ $repository }} {{ $new_release_dir }}
@endtask

@task('run_composer')
    echo "Starting deployment ({{ $build }})"
    cd {{ $new_release_dir }}
    composer update
    echo "Composer install successful"
    php artisan migrate --force
    echo "migrate successful"
    php artisan storage:link
    echo "storage linked successful"
@endtask

@task('update_symlinks')
    echo "Linking storage directory"
    rm -rf {{ $new_release_dir }}/storage
    ln -nfs {{ $app_dir }}/storage {{ $new_release_dir }}/storage

    echo 'Linking .env file'
    ln -nfs {{ $app_dir }}/.env {{ $new_release_dir }}/.env

    echo 'Linking current release'
    ln -nfs {{ $new_release_dir }} {{ $app_dir }}/release
@endtask

@task('clone_repository_dev')
    echo 'Cloning repository'
    [ -d {{ $devs_dir }} ] || mkdir {{ $devs_dir }}
    git clone --branch development {{ $repository }} {{ $new_dev_dir }}
@endtask

@task('run_composer_dev')
    echo "Starting deployment ({{ $build }})"
    cd {{ $new_dev_dir }}
    composer update
    echo "Composer update successful"
    php artisan migrate
    echo "migrate successful"
    php artisan storage:link
    echo "storage linked successful"
@endtask

@task('update_symlinks_dev')
    echo "Linking storage directory"
    rm -rf {{ $new_dev_dir }}/storage
    ln -nfs {{ $app_dev_dir }}/storage {{ $new_dev_dir }}/storage

    echo 'Linking .env file'
    ln -nfs {{ $app_dev_dir }}/.env {{ $new_dev_dir }}/.env

    echo 'Linking current release'
    ln -nfs {{ $new_dev_dir }} {{ $app_dev_dir }}/current
@endtask
